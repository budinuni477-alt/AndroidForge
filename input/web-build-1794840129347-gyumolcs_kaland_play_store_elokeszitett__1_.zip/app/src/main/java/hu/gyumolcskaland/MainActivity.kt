package hu.gyumolcskaland

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import android.content.Context
import kotlinx.coroutines.delay
import kotlin.random.Random

private val fruit = listOf("🍓", "🍋", "🍇", "🍊", "🍏", "🫐")
private const val N = 8

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FruitGame() }
    }
}

private fun makeBoard(level: Int): List<Int> {
    val kinds = (4 + level / 80).coerceAtMost(6)
    val b = MutableList(N * N) { 0 }
    for (r in 0 until N) for (c in 0 until N) {
        var v: Int
        do {
            v = Random.nextInt(kinds)
        } while ((c >= 2 && b[r*N+c-1] == v && b[r*N+c-2] == v) ||
                 (r >= 2 && b[(r-1)*N+c] == v && b[(r-2)*N+c] == v))
        b[r*N+c] = v
    }
    return b
}

private fun matches(b: List<Int>): Set<Int> {
    val out = mutableSetOf<Int>()
    for (r in 0 until N) for (c in 0 until N) {
        val v = b[r*N+c]
        if (v < 0) continue
        if (c <= N-3 && b[r*N+c+1] == v && b[r*N+c+2] == v) {
            var k = c
            while (k < N && b[r*N+k] == v) { out.add(r*N+k); k++ }
        }
        if (r <= N-3 && b[(r+1)*N+c] == v && b[(r+2)*N+c] == v) {
            var k = r
            while (k < N && b[k*N+c] == v) { out.add(k*N+c); k++ }
        }
    }
    return out
}

@Composable
fun FruitGame() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("progress", Context.MODE_PRIVATE) }
    var level by remember { mutableIntStateOf(prefs.getInt("level", 1).coerceIn(1, 1000)) }
    var board by remember(level) { mutableStateOf(makeBoard(level)) }
    var selected by remember { mutableIntStateOf(-1) }
    var moves by remember(level) { mutableIntStateOf((level / 8 + 20).coerceAtMost(35)) }
    var score by remember(level) { mutableIntStateOf(0) }
    var goal by remember(level) { mutableIntStateOf(350 + level * 18) }
    var notice by remember { mutableStateOf("Cserélj fel két szomszédos gyümölcsöt!") }
    var busy by remember { mutableStateOf(false) }

    fun restart() {
        board = makeBoard(level); selected = -1
        moves = (level / 8 + 20).coerceAtMost(35); score = 0
        goal = 350 + level * 18; notice = "Próbáld elérni a célt!"
    }

    fun tap(index: Int) {
        if (busy || moves <= 0 || score >= goal) return
        if (selected == -1) { selected = index; return }
        val a = selected
        selected = -1
        val adjacent = (a / N == index / N && kotlin.math.abs(a % N - index % N) == 1) ||
                       (a % N == index % N && kotlin.math.abs(a / N - index / N) == 1)
        if (!adjacent) { selected = index; return }
        val swapped = board.toMutableList()
        val temp = swapped[a]; swapped[a] = swapped[index]; swapped[index] = temp
        if (matches(swapped).isEmpty()) {
            notice = "Itt nincs egyezés — próbálj másik cserét!"
            return
        }
        moves--
        board = swapped
        busy = true
    }

    LaunchedEffect(board, busy) {
        if (!busy) return@LaunchedEffect
        delay(180)
        var b = board.toMutableList()
        var chain = 0
        while (true) {
            val hit = matches(b)
            if (hit.isEmpty()) break
            chain++
            score += hit.size * 10 * chain
            hit.forEach { b[it] = -1 }
            for (c in 0 until N) {
                val vals = (N-1 downTo 0).mapNotNull { r -> b[r*N+c].takeIf { it >= 0 } }
                val missing = N - vals.size
                for (r in N-1 downTo 0) {
                    val pos = r*N+c
                    b[pos] = if (r < missing) Random.nextInt((4 + level / 80).coerceAtMost(6)) else vals[N-1-r]
                }
            }
            board = b.toList()
            delay(180)
        }
        busy = false
        if (score >= goal) notice = "Szint teljesítve! 🎉"
        else if (moves == 0) notice = "Elfogytak a lépések. Próbáld újra!"
        else notice = "Szép! Folytasd a kombinációkat."
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFFFD166), background = Color(0xFF21133D),
        surface = Color(0xFF34205F), onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFF21133D)).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("🍓 GYÜMÖLCS KALAND 🍋", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color(0xFFFFD166))
            Text("1000 pálya • 1. szinttől a mesterig", color = Color.White.copy(alpha=.8f), fontSize = 13.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Stat("SZINT", "$level / 1000")
                Stat("PONT", "$score / $goal")
                Stat("LÉPÉS", "$moves")
            }
            LinearProgressIndicator(
                progress = { (score.toFloat() / goal).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = Color(0xFFFFD166), trackColor = Color.White.copy(alpha=.18f)
            )
            Column(Modifier.fillMaxWidth().background(Color(0xFF493477), RoundedCornerShape(18.dp)).padding(7.dp)) {
                for (r in 0 until N) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        for (c in 0 until N) {
                            val i = r*N+c
                            val isSelected = selected == i
                            Box(
                                Modifier.weight(1f).aspectRatio(1f)
                                    .background(if (isSelected) Color(0xFFFFD166) else Color(0xFF60468D), RoundedCornerShape(8.dp))
                                    .border(if (isSelected) 3.dp else 1.dp, if (isSelected) Color.White else Color.White.copy(alpha=.10f), RoundedCornerShape(8.dp))
                                    .clickable { tap(i) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(if (board[i] >= 0) fruit[board[i]] else "", fontSize = 25.sp)
                            }
                        }
                    }
                    if (r != N-1) Spacer(Modifier.height(3.dp))
                }
            }
            Text(notice, color = Color(0xFFFFE6A6), fontWeight = FontWeight.SemiBold)
            if (score >= goal) {
                Button(onClick = {
                    if (level < 1000) level++
                    prefs.edit().putInt("level", level).apply()
                    restart()
                }, modifier = Modifier.fillMaxWidth()) { Text(if (level == 1000) "ÚJRAJÁTSZÁS" else "KÖVETKEZŐ SZINT  ➜") }
            } else if (moves == 0) {
                Button(onClick = { restart() }, modifier = Modifier.fillMaxWidth()) { Text("ÚJRA  ↻") }
            }
            OutlinedButton(onClick = { restart() }, modifier = Modifier.fillMaxWidth()) { Text("PÁLYA ÚJRAINDÍTÁSA") }
            Spacer(Modifier.weight(1f))
            Text("Tipp: legalább 3 egyforma gyümölcsöt rendezz sorba!", color = Color.White.copy(alpha=.65f), fontSize = 12.sp)
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Color(0xFFFFD166), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}
