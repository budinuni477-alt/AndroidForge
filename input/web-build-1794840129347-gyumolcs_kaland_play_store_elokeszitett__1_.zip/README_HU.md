# Gyümölcs Kaland – Android match-3 játék

Ez egy saját grafikájú és nevű, Candy Crush által inspirált, de nem annak másolata match-3 alapjáték.

## Mit tartalmaz?
- 8×8-as játéktábla, gyümölcs ikonokkal
- két szomszédos elem felcserélése
- 3 vagy több egyező elem eltüntetése, gravitáció és láncreakció
- pontcél és korlátozott lépésszám
- 1000 fokozatosan nehezedő szint
- a teljesített szint mentése a telefonon

## APK készítése Android Studióval
1. Telepítsd az Android Studio-t.
2. Nyisd meg benne ezt a projektmappát.
3. Várd meg a Gradle szinkronizálást.
4. Válaszd: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Az elkészült APK-t Android telefonra másolva telepítheted (engedélyezni kell az adott forrásból történő telepítést).

A projekt Android Studio + internetkapcsolat mellett tölti le a szükséges Gradle/Android függőségeket.


## Google Play előkészítés
- A projekt `compileSdk` és `targetSdk` értéke 36.
- Áruházi adatlap tervezet: `PLAY_STORE_ADATLAP_HU.txt`.
- Kitöltendő adatvédelmi tájékoztató minta: `ADATVEDELMI_TAJEKOZTATO_MINTA.txt`.
- Feltöltés előtti ellenőrzőlista: `PLAY_STORE_KIADASI_ELLENORZOLISTA.txt`.
- A projektből még aláírt AAB-t kell készíteni és valódi készülékeken tesztelni.
