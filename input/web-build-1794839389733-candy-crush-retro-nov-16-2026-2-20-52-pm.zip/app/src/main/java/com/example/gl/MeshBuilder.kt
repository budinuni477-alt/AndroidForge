package com.example.gl

import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

class GpuMesh(
    val vboId: Int,
    val iboId: Int,
    val indexCount: Int
) {
    fun bindAndDraw(posLoc: Int, normLoc: Int, colLoc: Int, uvLoc: Int) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboId)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, iboId)

        val stride = 11 * 4
        GLES20.glEnableVertexAttribArray(posLoc)
        GLES20.glVertexAttribPointer(posLoc, 3, GLES20.GL_FLOAT, false, stride, 0)

        GLES20.glEnableVertexAttribArray(normLoc)
        GLES20.glVertexAttribPointer(normLoc, 3, GLES20.GL_FLOAT, false, stride, 3 * 4)

        GLES20.glEnableVertexAttribArray(colLoc)
        GLES20.glVertexAttribPointer(colLoc, 3, GLES20.GL_FLOAT, false, stride, 6 * 4)

        GLES20.glEnableVertexAttribArray(uvLoc)
        GLES20.glVertexAttribPointer(uvLoc, 2, GLES20.GL_FLOAT, false, stride, 9 * 4)

        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indexCount, GLES20.GL_UNSIGNED_SHORT, 0)
    }

    fun release() {
        GLES20.glDeleteBuffers(2, intArrayOf(vboId, iboId), 0)
    }
}

class MeshDataBuilder {
    private val floats = ArrayList<Float>(4096)
    private val indices = ArrayList<Short>(4096)

    private fun addVertex(
        x: Float, y: Float, z: Float,
        nx: Float, ny: Float, nz: Float,
        r: Float, g: Float, b: Float,
        u: Float = 0f, v: Float = 0f
    ): Short {
        val idx = (floats.size / 11).toShort()
        val len = sqrt(nx * nx + ny * ny + nz * nz).let { if (it > 1e-5f) it else 1f }
        floats.add(x); floats.add(y); floats.add(z)
        floats.add(nx / len); floats.add(ny / len); floats.add(nz / len)
        floats.add(r); floats.add(g); floats.add(b)
        floats.add(u); floats.add(v)
        return idx
    }

    private fun addTri(a: Short, b: Short, c: Short) {
        indices.add(a); indices.add(b); indices.add(c)
    }

    fun addSphere(
        cx: Float, cy: Float, cz: Float,
        rx: Float, ry: Float, rz: Float,
        r: Float, g: Float, b: Float,
        stacks: Int = 14, slices: Int = 20,
        dimpleAmp: Float = 0f
    ) {
        val base = floats.size / 11
        for (i in 0..stacks) {
            val v = i.toFloat() / stacks
            val phi = v * PI.toFloat()
            val sinPhi = sin(phi)
            val cosPhi = cos(phi)
            for (j in 0..slices) {
                val u = j.toFloat() / slices
                val theta = u * 2f * PI.toFloat()
                val cosT = cos(theta)
                val sinT = sin(theta)

                val bump = if (dimpleAmp != 0f) {
                    1f + dimpleAmp * sin(phi * 10f) * cos(theta * 12f)
                } else 1f

                val x = cx + rx * bump * sinPhi * cosT
                val y = cy + ry * bump * cosPhi
                val z = cz + rz * bump * sinPhi * sinT
                addVertex(x, y, z, sinPhi * cosT / rx, cosPhi / ry, sinPhi * sinT / rz, r, g, b, u, v)
            }
        }
        val row = slices + 1
        for (i in 0 until stacks) {
            for (j in 0 until slices) {
                val a = (base + i * row + j).toShort()
                val d = (base + (i + 1) * row + j).toShort()
                val c = (base + (i + 1) * row + j + 1).toShort()
                val b2 = (base + i * row + j + 1).toShort()
                addTri(a, d, b2)
                addTri(b2, d, c)
            }
        }
    }

    fun addLathe(
        profile: List<Pair<Float, Float>>, // (radius, y)
        r: Float, g: Float, b: Float,
        segments: Int = 24,
        tiltZ: Float = 0f
    ) {
        val base = floats.size / 11
        val cosA = cos(tiltZ)
        val sinA = sin(tiltZ)
        for (i in profile.indices) {
            val (rad, py) = profile[i]
            val prev = profile[max(0, i - 1)]
            val next = profile[kotlin.math.min(profile.lastIndex, i + 1)]
            val dr = next.first - prev.first
            val dy = next.second - prev.second
            val nr = dy
            val ny = -dr

            for (j in 0..segments) {
                val theta = (j.toFloat() / segments) * 2f * PI.toFloat()
                val ct = cos(theta)
                val st = sin(theta)
                val lx = rad * ct
                val lz = rad * st
                val x = lx * cosA - py * sinA
                val y = lx * sinA + py * cosA

                val lnx = nr * ct
                val lnz = nr * st
                val nx = lnx * cosA - ny * sinA
                val ny2 = lnx * sinA + ny * cosA

                addVertex(x, y, lz, nx, ny2, lnz, r, g, b, j.toFloat() / segments, i.toFloat() / profile.lastIndex)
            }
        }
        val row = segments + 1
        for (i in 0 until profile.lastIndex) {
            for (j in 0 until segments) {
                val a = (base + i * row + j).toShort()
                val d = (base + (i + 1) * row + j).toShort()
                val c = (base + (i + 1) * row + j + 1).toShort()
                val b2 = (base + i * row + j + 1).toShort()
                addTri(a, b2, d)
                addTri(b2, c, d)
            }
        }
    }

    fun addOrientedBox(
        cx: Float, cy: Float, cz: Float,
        hx: Float, hy: Float, hz: Float,
        r: Float, g: Float, b: Float
    ) {
        val faces = listOf(
            // Front +Z
            Triple(floatArrayOf(0f, 0f, 1f), arrayOf(
                floatArrayOf(cx - hx, cy - hy, cz + hz, 0f, 1f),
                floatArrayOf(cx + hx, cy - hy, cz + hz, 1f, 1f),
                floatArrayOf(cx + hx, cy + hy, cz + hz, 1f, 0f),
                floatArrayOf(cx - hx, cy + hy, cz + hz, 0f, 0f)
            ), 1f),
            // Back -Z
            Triple(floatArrayOf(0f, 0f, -1f), arrayOf(
                floatArrayOf(cx + hx, cy - hy, cz - hz, 0f, 1f),
                floatArrayOf(cx - hx, cy - hy, cz - hz, 1f, 1f),
                floatArrayOf(cx - hx, cy + hy, cz - hz, 1f, 0f),
                floatArrayOf(cx + hx, cy + hy, cz - hz, 0f, 0f)
            ), 1f),
            // Top +Y
            Triple(floatArrayOf(0f, 1f, 0f), arrayOf(
                floatArrayOf(cx - hx, cy + hy, cz + hz, 0f, 1f),
                floatArrayOf(cx + hx, cy + hy, cz + hz, 1f, 1f),
                floatArrayOf(cx + hx, cy + hy, cz - hz, 1f, 0f),
                floatArrayOf(cx - hx, cy + hy, cz - hz, 0f, 0f)
            ), 1f),
            // Bottom -Y
            Triple(floatArrayOf(0f, -1f, 0f), arrayOf(
                floatArrayOf(cx - hx, cy - hy, cz - hz, 0f, 1f),
                floatArrayOf(cx + hx, cy - hy, cz - hz, 1f, 1f),
                floatArrayOf(cx + hx, cy - hy, cz + hz, 1f, 0f),
                floatArrayOf(cx - hx, cy - hy, cz + hz, 0f, 0f)
            ), 1f),
            // Right +X
            Triple(floatArrayOf(1f, 0f, 0f), arrayOf(
                floatArrayOf(cx + hx, cy - hy, cz + hz, 0f, 1f),
                floatArrayOf(cx + hx, cy - hy, cz - hz, 1f, 1f),
                floatArrayOf(cx + hx, cy + hy, cz - hz, 1f, 0f),
                floatArrayOf(cx + hx, cy + hy, cz + hz, 0f, 0f)
            ), 1f),
            // Left -X
            Triple(floatArrayOf(-1f, 0f, 0f), arrayOf(
                floatArrayOf(cx - hx, cy - hy, cz - hz, 0f, 1f),
                floatArrayOf(cx - hx, cy - hy, cz + hz, 1f, 1f),
                floatArrayOf(cx - hx, cy + hy, cz + hz, 1f, 0f),
                floatArrayOf(cx - hx, cy + hy, cz - hz, 0f, 0f)
            ), 1f)
        )
        faces.forEach { (n, pts, _) ->
            val v0 = addVertex(pts[0][0], pts[0][1], pts[0][2], n[0], n[1], n[2], r, g, b, pts[0][3], pts[0][4])
            val v1 = addVertex(pts[1][0], pts[1][1], pts[1][2], n[0], n[1], n[2], r, g, b, pts[1][3], pts[1][4])
            val v2 = addVertex(pts[2][0], pts[2][1], pts[2][2], n[0], n[1], n[2], r, g, b, pts[2][3], pts[2][4])
            val v3 = addVertex(pts[3][0], pts[3][1], pts[3][2], n[0], n[1], n[2], r, g, b, pts[3][3], pts[3][4])
            addTri(v0, v1, v2)
            addTri(v0, v2, v3)
        }
    }

    fun addCylinderBetween(
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        rad1: Float, rad2: Float,
        r: Float, g: Float, b: Float,
        segs: Int = 8
    ) {
        val dx = x2 - x1; val dy = y2 - y1; val dz = z2 - z1
        val len = sqrt(dx * dx + dy * dy + dz * dz).let { if (it > 1e-5f) it else 1f }
        val ax = dx / len; val ay = dy / len; val az = dz / len

        // Orthonormal basis perpendicular to axis
        val upX = if (kotlin.math.abs(ay) < 0.9f) 0f else 1f
        val upY = if (kotlin.math.abs(ay) < 0.9f) 1f else 0f
        val upZ = 0f

        var ux = ay * upZ - az * upY
        var uy = az * upX - ax * upZ
        var uz = ax * upY - ay * upX
        val uLen = sqrt(ux * ux + uy * uy + uz * uz).let { if (it > 1e-5f) it else 1f }
        ux /= uLen; uy /= uLen; uz /= uLen

        val vx = ay * uz - az * uy
        val vy = az * ux - ax * uz
        val vz = ax * uy - ay * ux

        val base = floats.size / 11
        for (i in 0..segs) {
            val t = (i.toFloat() / segs) * 2f * PI.toFloat()
            val ct = cos(t); val st = sin(t)
            val nx = ux * ct + vx * st
            val ny = uy * ct + vy * st
            val nz = uz * ct + vz * st
            addVertex(x1 + nx * rad1, y1 + ny * rad1, z1 + nz * rad1, nx, ny, nz, r, g, b)
            addVertex(x2 + nx * rad2, y2 + ny * rad2, z2 + nz * rad2, nx, ny, nz, r, g, b)
        }
        for (i in 0 until segs) {
            val a = (base + i * 2).toShort()
            val b2 = (base + i * 2 + 1).toShort()
            val c = (base + (i + 1) * 2).toShort()
            val d = (base + (i + 1) * 2 + 1).toShort()
            addTri(a, c, b2)
            addTri(b2, c, d)
        }
    }

    fun addTorus(
        majorR: Float, minorR: Float,
        r: Float, g: Float, b: Float,
        majorSegs: Int = 28, minorSegs: Int = 10,
        tiltX: Float = 0f, tiltY: Float = 0f
    ) {
        val base = floats.size / 11
        val cx = cos(tiltX); val sx = sin(tiltX)
        val cy = cos(tiltY); val sy = sin(tiltY)

        for (i in 0..majorSegs) {
            val u = (i.toFloat() / majorSegs) * 2f * PI.toFloat()
            val cu = cos(u); val su = sin(u)
            for (j in 0..minorSegs) {
                val v = (j.toFloat() / minorSegs) * 2f * PI.toFloat()
                val cv = cos(v); val sv = sin(v)

                val px0 = (majorR + minorR * cv) * cu
                val py0 = (majorR + minorR * cv) * su
                val pz0 = minorR * sv

                val nx0 = cv * cu; val ny0 = cv * su; val nz0 = sv

                // Rotate X then Y
                val py1 = py0 * cx - pz0 * sx
                val pz1 = py0 * sx + pz0 * cx
                val px2 = px0 * cy + pz1 * sy
                val pz2 = -px0 * sy + pz1 * cy

                val ny1 = ny0 * cx - nz0 * sx
                val nz1 = ny0 * sx + nz0 * cx
                val nx2 = nx0 * cy + nz1 * sy
                val nz2 = -nx0 * sy + nz1 * cy

                addVertex(px2, py1, pz2, nx2, ny1, nz2, r, g, b)
            }
        }
        val row = minorSegs + 1
        for (i in 0 until majorSegs) {
            for (j in 0 until minorSegs) {
                val a = (base + i * row + j).toShort()
                val d = (base + (i + 1) * row + j).toShort()
                val c = (base + (i + 1) * row + j + 1).toShort()
                val b2 = (base + i * row + j + 1).toShort()
                addTri(a, d, b2)
                addTri(b2, d, c)
            }
        }
    }

    fun addQuad(
        x0: Float, y0: Float, z0: Float, u0: Float, v0: Float,
        x1: Float, y1: Float, z1: Float, u1: Float, v1: Float,
        x2: Float, y2: Float, z2: Float, u2: Float, v2: Float,
        x3: Float, y3: Float, z3: Float, u3: Float, v3: Float,
        nx: Float, ny: Float, nz: Float,
        r: Float, g: Float, b: Float
    ) {
        val a = addVertex(x0, y0, z0, nx, ny, nz, r, g, b, u0, v0)
        val b2 = addVertex(x1, y1, z1, nx, ny, nz, r, g, b, u1, v1)
        val c = addVertex(x2, y2, z2, nx, ny, nz, r, g, b, u2, v2)
        val d = addVertex(x3, y3, z3, nx, ny, nz, r, g, b, u3, v3)
        addTri(a, b2, c)
        addTri(a, c, d)
    }

    fun addDisc(
        radiusInner: Float, radiusOuter: Float, z: Float,
        r: Float, g: Float, b: Float, segs: Int = 28
    ) {
        val base = floats.size / 11
        for (i in 0..segs) {
            val a = (i.toFloat() / segs) * 2f * PI.toFloat()
            val ca = cos(a); val sa = sin(a)
            addVertex(ca * radiusInner, sa * radiusInner, z, 0f, 0f, 1f, r, g, b, 0.5f + ca * 0.25f, 0.5f + sa * 0.25f)
            addVertex(ca * radiusOuter, sa * radiusOuter, z, 0f, 0f, 1f, r, g, b, 0.5f + ca * 0.5f, 0.5f + sa * 0.5f)
        }
        for (i in 0 until segs) {
            val v0 = (base + i * 2).toShort()
            val v1 = (base + i * 2 + 1).toShort()
            val v2 = (base + (i + 1) * 2).toShort()
            val v3 = (base + (i + 1) * 2 + 1).toShort()
            addTri(v0, v1, v3)
            addTri(v0, v3, v2)
        }
    }

    fun addFlatPolygonPrism(
        pointsXY: List<Pair<Float, Float>>,
        halfDepth: Float,
        r: Float, g: Float, b: Float
    ) {
        // Compute centroid for fan triangulation
        var cx = 0f; var cy = 0f
        pointsXY.forEach { cx += it.first; cy += it.second }
        cx /= pointsXY.size; cy /= pointsXY.size

        // Front & Back faces
        val fCenter = addVertex(cx, cy, halfDepth, 0f, 0f, 1f, r, g, b)
        val bCenter = addVertex(cx, cy, -halfDepth, 0f, 0f, -1f, r, g, b)

        val fVerts = pointsXY.map { (x, y) -> addVertex(x, y, halfDepth, 0f, 0f, 1f, r, g, b) }
        val bVerts = pointsXY.map { (x, y) -> addVertex(x, y, -halfDepth, 0f, 0f, -1f, r, g, b) }

        for (i in pointsXY.indices) {
            val next = (i + 1) % pointsXY.size
            addTri(fCenter, fVerts[i], fVerts[next])
            addTri(bCenter, bVerts[next], bVerts[i])

            val p1 = pointsXY[i]; val p2 = pointsXY[next]
            val ex = p2.first - p1.first; val ey = p2.second - p1.second
            val nx = ey; val ny = -ex
            val s0 = addVertex(p1.first, p1.second, halfDepth, nx, ny, 0f, r, g, b)
            val s1 = addVertex(p2.first, p2.second, halfDepth, nx, ny, 0f, r, g, b)
            val s2 = addVertex(p2.first, p2.second, -halfDepth, nx, ny, 0f, r, g, b)
            val s3 = addVertex(p1.first, p1.second, -halfDepth, nx, ny, 0f, r, g, b)
            addTri(s0, s3, s2)
            addTri(s0, s2, s1)
        }
    }

    fun addOctahedron(radius: Float) {
        val dirs = listOf(
            floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, -1f, 0f),
            floatArrayOf(1f, 0f, 0f), floatArrayOf(-1f, 0f, 0f),
            floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, 0f, -1f)
        )
        val faces = listOf(
            Triple(0, 4, 2) to floatArrayOf(1f, 0.2f, 0.7f),
            Triple(0, 2, 5) to floatArrayOf(0f, 0.95f, 1f),
            Triple(0, 5, 3) to floatArrayOf(1f, 0.85f, 0.1f),
            Triple(0, 3, 4) to floatArrayOf(0.6f, 0.25f, 1f),
            Triple(1, 2, 4) to floatArrayOf(0.1f, 0.95f, 0.5f),
            Triple(1, 5, 2) to floatArrayOf(1f, 0.45f, 0.1f),
            Triple(1, 3, 5) to floatArrayOf(0.2f, 0.55f, 1f),
            Triple(1, 4, 3) to floatArrayOf(1f, 0.15f, 0.4f)
        )
        faces.forEach { (tri, col) ->
            val p0 = dirs[tri.first]; val p1 = dirs[tri.second]; val p2 = dirs[tri.third]
            val nx = p0[0] + p1[0] + p2[0]
            val ny = p0[1] + p1[1] + p2[1]
            val nz = p0[2] + p1[2] + p2[2]
            val a = addVertex(p0[0] * radius, p0[1] * radius, p0[2] * radius, nx, ny, nz, col[0], col[1], col[2])
            val b2 = addVertex(p1[0] * radius, p1[1] * radius, p1[2] * radius, nx, ny, nz, col[0], col[1], col[2])
            val c = addVertex(p2[0] * radius, p2[1] * radius, p2[2] * radius, nx, ny, nz, col[0], col[1], col[2])
            addTri(a, b2, c)
        }
    }

    fun build(): GpuMesh {
        val vBuf: FloatBuffer = ByteBuffer.allocateDirect(floats.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (f in floats) vBuf.put(f)
        vBuf.position(0)

        val iBuf: ShortBuffer = ByteBuffer.allocateDirect(indices.size * 2)
            .order(ByteOrder.nativeOrder()).asShortBuffer()
        for (s in indices) iBuf.put(s)
        iBuf.position(0)

        val ids = IntArray(2)
        GLES20.glGenBuffers(2, ids, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, floats.size * 4, vBuf, GLES20.GL_STATIC_DRAW)

        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ids[1])
        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, indices.size * 2, iBuf, GLES20.GL_STATIC_DRAW)

        return GpuMesh(ids[0], ids[1], indices.size)
    }
}

object FruitMeshFactory {

    fun buildStrawberry(): GpuMesh = MeshDataBuilder().apply {
        addLathe(
            listOf(
                0.001f to -0.44f,
                0.16f to -0.35f,
                0.32f to -0.10f,
                0.39f to 0.16f,
                0.30f to 0.34f,
                0.12f to 0.38f,
                0.001f to 0.36f
            ),
            1.0f, 0.10f, 0.26f, segments = 24
        )
        // Golden 3D seeds
        for (i in 0 until 16) {
            val phi = (i / 16f) * 2f * PI.toFloat() + (i % 2) * 0.3f
            val y = -0.22f + (i % 4) * 0.14f
            val r = 0.36f - kotlin.math.abs(y - 0.12f) * 0.45f
            addSphere(cos(phi) * r, y, sin(phi) * r, 0.028f, 0.036f, 0.028f, 1.0f, 0.88f, 0.38f, 6, 8)
        }
        // 5 Sepal leaves
        for (i in 0 until 5) {
            val a = (i / 5f) * 2f * PI.toFloat()
            addCylinderBetween(
                0f, 0.35f, 0f,
                cos(a) * 0.25f, 0.41f, sin(a) * 0.25f,
                0.08f, 0.015f,
                0.16f, 0.82f, 0.26f, segs = 6
            )
        }
        // Stem
        addCylinderBetween(0f, 0.35f, 0f, 0f, 0.52f, 0f, 0.045f, 0.03f, 0.28f, 0.52f, 0.16f, 8)
    }.build()

    fun buildCherry(): GpuMesh = MeshDataBuilder().apply {
        addSphere(-0.20f, -0.16f, 0.04f, 0.25f, 0.225f, 0.24f, 0.88f, 0.02f, 0.18f, 14, 18)
        addSphere(0.21f, -0.11f, -0.04f, 0.25f, 0.225f, 0.24f, 0.88f, 0.02f, 0.18f, 14, 18)
        // Curved stems (2 segments each)
        addCylinderBetween(-0.18f, -0.01f, 0.04f, -0.09f, 0.24f, 0.02f, 0.028f, 0.026f, 0.32f, 0.55f, 0.18f, 6)
        addCylinderBetween(-0.09f, 0.24f, 0.02f, 0.02f, 0.44f, 0f, 0.026f, 0.024f, 0.32f, 0.55f, 0.18f, 6)
        addCylinderBetween(0.19f, 0.03f, -0.04f, 0.12f, 0.27f, -0.01f, 0.028f, 0.026f, 0.32f, 0.55f, 0.18f, 6)
        addCylinderBetween(0.12f, 0.27f, -0.01f, 0.02f, 0.44f, 0f, 0.026f, 0.024f, 0.32f, 0.55f, 0.18f, 6)
        // Leaf
        addSphere(0.16f, 0.38f, 0.02f, 0.17f, 0.045f, 0.09f, 0.18f, 0.84f, 0.28f, 8, 12)
    }.build()

    fun buildOrange(): GpuMesh = MeshDataBuilder().apply {
        addSphere(0f, -0.02f, 0f, 0.40f, 0.37f, 0.40f, 1.0f, 0.48f, 0.0f, 16, 22, dimpleAmp = 0.022f)
        addCylinderBetween(0f, 0.33f, 0f, 0f, 0.43f, 0f, 0.04f, 0.03f, 0.28f, 0.52f, 0.16f, 8)
        addSphere(0.16f, 0.37f, 0.04f, 0.18f, 0.04f, 0.10f, 0.16f, 0.82f, 0.26f, 8, 12)
    }.build()

    fun buildLemon(): GpuMesh = MeshDataBuilder().apply {
        addLathe(
            listOf(
                0.001f to -0.45f,
                0.08f to -0.39f,
                0.28f to -0.22f,
                0.35f to 0.0f,
                0.28f to 0.22f,
                0.08f to 0.39f,
                0.001f to 0.45f
            ),
            1.0f, 0.90f, 0.04f, segments = 22, tiltZ = -0.38f
        )
        addSphere(0.22f, 0.33f, 0.04f, 0.16f, 0.04f, 0.08f, 0.18f, 0.84f, 0.28f, 8, 12)
    }.build()

    fun buildGrape(): GpuMesh = MeshDataBuilder().apply {
        val coords = listOf(
            floatArrayOf(-0.18f, 0.16f, 0.06f), floatArrayOf(0f, 0.18f, 0.10f), floatArrayOf(0.18f, 0.16f, 0.04f),
            floatArrayOf(-0.08f, 0.14f, -0.10f), floatArrayOf(0.10f, 0.14f, -0.10f),
            floatArrayOf(-0.13f, -0.02f, 0.08f), floatArrayOf(0.06f, -0.02f, 0.09f), floatArrayOf(0f, -0.04f, -0.09f),
            floatArrayOf(-0.07f, -0.20f, 0.04f), floatArrayOf(0.08f, -0.19f, -0.02f),
            floatArrayOf(0f, -0.34f, 0.01f)
        )
        coords.forEach { p ->
            addSphere(p[0], p[1], p[2], 0.15f, 0.15f, 0.15f, 0.62f, 0.20f, 0.98f, 10, 14)
        }
        addCylinderBetween(0f, 0.26f, 0f, 0f, 0.44f, 0f, 0.035f, 0.03f, 0.28f, 0.52f, 0.16f, 8)
        addSphere(0.15f, 0.33f, 0.04f, 0.16f, 0.04f, 0.10f, 0.18f, 0.84f, 0.28f, 8, 12)
    }.build()

    fun buildBlueberry(): GpuMesh = MeshDataBuilder().apply {
        addSphere(0f, -0.02f, 0f, 0.40f, 0.34f, 0.40f, 0.15f, 0.36f, 1.0f, 16, 22)
        for (i in 0 until 5) {
            val a = (i / 5f) * 2f * PI.toFloat()
            addCylinderBetween(
                cos(a) * 0.09f, 0.29f, sin(a) * 0.09f,
                cos(a) * 0.16f, 0.39f, sin(a) * 0.16f,
                0.055f, 0.01f,
                0.09f, 0.22f, 0.72f, 6
            )
        }
    }.build()

    fun buildWatermelon(): GpuMesh = MeshDataBuilder().apply {
        // Juicy red flesh semicircle wedge
        val fleshPts = ArrayList<Pair<Float, Float>>()
        fleshPts.add(-0.40f to 0.18f)
        fleshPts.add(0.40f to 0.18f)
        for (i in 1..11) {
            val a = -(i / 12f) * PI.toFloat()
            fleshPts.add((cos(a) * 0.40f) to (0.18f + sin(a) * 0.40f))
        }
        addFlatPolygonPrism(fleshPts, 0.11f, 1.0f, 0.16f, 0.34f)

        // Green rind arc segments along outer rim
        for (i in 0 until 12) {
            val a1 = -(i / 12f) * PI.toFloat()
            val a2 = -((i + 1) / 12f) * PI.toFloat()
            val isDark = i % 2 == 0
            val gr = if (isDark) 0.0f else 0.04f
            val gg = if (isDark) 0.45f else 0.82f
            val gb = if (isDark) 0.16f else 0.32f
            val segPts = listOf(
                (cos(a1) * 0.39f) to (0.18f + sin(a1) * 0.39f),
                (cos(a1) * 0.47f) to (0.18f + sin(a1) * 0.47f),
                (cos(a2) * 0.47f) to (0.18f + sin(a2) * 0.47f),
                (cos(a2) * 0.39f) to (0.18f + sin(a2) * 0.39f)
            )
            addFlatPolygonPrism(segPts, 0.125f, gr, gg, gb)
        }

        // Black seeds on front & back
        listOf(-0.17f to 0.05f, 0f to 0.07f, 0.17f to 0.05f, -0.09f to -0.06f, 0.09f to -0.06f).forEach { (sx, sy) ->
            addSphere(sx, sy, 0.12f, 0.022f, 0.036f, 0.018f, 0.10f, 0.07f, 0.08f, 6, 6)
            addSphere(sx, sy, -0.12f, 0.022f, 0.036f, 0.018f, 0.10f, 0.07f, 0.08f, 6, 6)
        }
    }.build()

    fun buildPineapple(): GpuMesh = MeshDataBuilder().apply {
        // Golden oval body
        addLathe(
            listOf(
                0.001f to -0.40f,
                0.20f to -0.34f,
                0.32f to -0.14f,
                0.34f to 0.04f,
                0.27f to 0.20f,
                0.14f to 0.27f,
                0.001f to 0.28f
            ),
            1.0f, 0.72f, 0.04f, segments = 22
        )
        // Diamond texture bumps around body
        for (row in 0 until 4) {
            val y = -0.24f + row * 0.14f
            val ringR = if (row == 1 || row == 2) 0.33f else 0.25f
            val offset = if (row % 2 == 0) 0f else (PI.toFloat() / 8f)
            for (i in 0 until 8) {
                val a = (i / 8f) * 2f * PI.toFloat() + offset
                addSphere(
                    cos(a) * ringR, y, sin(a) * ringR,
                    0.042f, 0.042f, 0.042f,
                    0.96f, 0.50f, 0.02f, 6, 8
                )
            }
        }
        // Spiky emerald crown leaves (outer & inner rings)
        for (i in 0 until 7) {
            val a = (i / 7f) * 2f * PI.toFloat()
            addCylinderBetween(
                0f, 0.25f, 0f,
                cos(a) * 0.28f, 0.49f, sin(a) * 0.28f,
                0.075f, 0.012f,
                0.08f, 0.80f, 0.24f, segs = 6
            )
        }
        for (i in 0 until 5) {
            val a = (i / 5f) * 2f * PI.toFloat() + 0.3f
            addCylinderBetween(
                0f, 0.28f, 0f,
                cos(a) * 0.14f, 0.58f, sin(a) * 0.14f,
                0.06f, 0.010f,
                0.14f, 0.92f, 0.32f, segs = 6
            )
        }
    }.build()
}
