package com.example.gl

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import com.example.data.LevelRepository
import com.example.model.CellPos
import com.example.model.FruitCell
import com.example.model.FruitType
import com.example.model.SaveState
import com.example.model.ScreenMode
import com.example.model.SpecialType
import java.util.concurrent.CopyOnWriteArrayList
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class Retro3DRenderer : GLSurfaceView.Renderer {

    companion object {
        const val CELL_SIZE = 1.04f
        const val BOARD_OFFSET = 3.5f * CELL_SIZE

        fun gridToWorldX(c: Int): Float = c * CELL_SIZE - BOARD_OFFSET
        fun gridToWorldY(r: Int): Float = BOARD_OFFSET - r * CELL_SIZE
    }

    private data class Particle3D(
        var x: Float, var y: Float, var z: Float,
        var vx: Float, var vy: Float, var vz: Float,
        var rx: Float, var ry: Float,
        val r: Float, val g: Float, val b: Float,
        var life: Float = 0f,
        val maxLife: Float = 0.65f,
        val baseScale: Float = 0.14f
    )

    private data class Shockwave3D(
        val x: Float, val y: Float, val z: Float,
        val r: Float, val g: Float, val b: Float,
        val isBeam: Boolean,
        val horizontal: Boolean = true,
        var life: Float = 0f,
        val maxLife: Float = 0.38f,
        val targetScale: Float = 2.6f
    )

    private data class MapNodePos(
        val id: Int,
        val x: Float,
        val y: Float,
        val z: Float,
        val isBoss: Boolean
    )

    // Shader & Uniforms
    private var program = 0
    private var aPos = 0
    private var aNorm = 0
    private var aCol = 0
    private var aUv = 0

    private var uMvp = 0
    private var uModel = 0
    private var uCamPos = 0
    private var uColorTint = 0
    private var uEmissive = 0
    private var uAlpha = 0
    private var uUseTex = 0
    private var uUnlit = 0
    private var uUvOffset = 0
    private var uTex = 0

    // Meshes
    private lateinit var fruitMeshes: Array<GpuMesh>
    private lateinit var torusRingMesh: GpuMesh
    private lateinit var torusRingWhiteMesh: GpuMesh
    private lateinit var bombAuraMesh: GpuMesh
    private lateinit var colorPrismMesh: GpuMesh
    private lateinit var floorMesh: GpuMesh
    private lateinit var sunMesh: GpuMesh
    private lateinit var marqueeMesh: GpuMesh
    private lateinit var boardBackMesh: GpuMesh
    private lateinit var rimHorizCyanMesh: GpuMesh
    private lateinit var rimVertPinkMesh: GpuMesh
    private lateinit var padLightMesh: GpuMesh
    private lateinit var padDarkMesh: GpuMesh
    private lateinit var iceMesh: GpuMesh
    private lateinit var cageMesh: GpuMesh
    private lateinit var stoneMesh: GpuMesh
    private lateinit var shadowMesh: GpuMesh
    private lateinit var selectRingMesh: GpuMesh
    private lateinit var particleMesh: GpuMesh
    private lateinit var shockwaveMesh: GpuMesh
    private lateinit var beamHorizMesh: GpuMesh
    private lateinit var beamVertMesh: GpuMesh
    private lateinit var mapPathMesh: GpuMesh
    private lateinit var mapPedestalMesh: GpuMesh
    private lateinit var mapBadgeMesh: GpuMesh

    // Textures
    private var texGrid = 0
    private var texMarquee = 0
    private var texBadgeCache = IntArray(100)
    private var badgeCacheVersion = -1

    // Matrices & Viewport for Camera + Raycasting
    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val invVpMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    @Volatile var viewportW = 1
    @Volatile var viewportH = 1
    private val camPos = floatArrayOf(0f, 0f, 14f)
    private val baseCamPos = floatArrayOf(0f, 0f, 14f)

    // Render State shared safely with GameController
    @Volatile var screenMode = ScreenMode.MENU
    @Volatile var saveSnapshot = SaveState()
    @Volatile var selectedCell: CellPos? = null

    val gridLock = Any()
    val boardGrid: Array<Array<FruitCell?>> = Array(8) { arrayOfNulls(8) }
    val iceGrid: Array<IntArray> = Array(8) { IntArray(8) }
    val cageGrid: Array<IntArray> = Array(8) { IntArray(8) }
    val stoneGrid: Array<IntArray> = Array(8) { IntArray(8) }

    // Map Scroll State
    @Volatile var mapTargetScrollY = 0f
    @Volatile var mapScrollY = 0f
    private val mapNodes: List<MapNodePos> = (1..100).map { id ->
        val i = id - 1
        MapNodePos(
            id = id,
            x = sin(i * 0.55f) * 2.1f,
            y = i * 1.65f,
            z = cos(i * 0.35f) * 0.35f,
            isBoss = id % 10 == 0
        )
    }

    // VFX & Shake
    private val particles = CopyOnWriteArrayList<Particle3D>()
    private val shockwaves = CopyOnWriteArrayList<Shockwave3D>()
    @Volatile private var shakeTime = 0f
    @Volatile private var shakeAmp = 0f

    private var lastFrameNs = System.nanoTime()
    private var elapsedSec = 0f

    fun triggerShake(amp: Float, dur: Float) {
        shakeAmp = max(shakeAmp, amp)
        shakeTime = max(shakeTime, dur)
    }

    fun spawnExplosion(wx: Float, wy: Float, wz: Float, colorInt: Int, count: Int = 14, big: Boolean = false) {
        val r = ((colorInt shr 16) and 0xFF) / 255f
        val g = ((colorInt shr 8) and 0xFF) / 255f
        val b = (colorInt and 0xFF) / 255f

        for (i in 0 until count) {
            val angle = Random.nextFloat() * 2f * PI.toFloat()
            val speed = (if (big) 5.5f else 3.4f) * (0.4f + Random.nextFloat() * 0.9f)
            val vy = (Random.nextFloat() - 0.15f) * (if (big) 7f else 5f)
            val vz = (Random.nextFloat() - 0.2f) * 4.5f
            val white = i % 3 == 0
            particles.add(
                Particle3D(
                    x = wx, y = wy, z = wz + 0.15f,
                    vx = cos(angle) * speed, vy = vy, vz = vz,
                    rx = Random.nextFloat() * 6f, ry = Random.nextFloat() * 6f,
                    r = if (white) 1f else r, g = if (white) 1f else g, b = if (white) 1f else b,
                    maxLife = 0.45f + Random.nextFloat() * 0.35f,
                    baseScale = if (big) 0.16f else 0.11f
                )
            )
        }
        shockwaves.add(
            Shockwave3D(
                x = wx, y = wy, z = wz + 0.28f,
                r = if (big) 1f else r,
                g = if (big) 0.85f else g,
                b = if (big) 0.15f else b,
                isBeam = false,
                maxLife = if (big) 0.52f else 0.34f,
                targetScale = if (big) 4.6f else 2.2f
            )
        )
    }

    fun spawnLineBeam(wx: Float, wy: Float, horizontal: Boolean, colorInt: Int = 0xFF00F0FF.toInt()) {
        val r = ((colorInt shr 16) and 0xFF) / 255f
        val g = ((colorInt shr 8) and 0xFF) / 255f
        val b = (colorInt and 0xFF) / 255f
        shockwaves.add(
            Shockwave3D(
                x = wx, y = wy, z = 0.35f,
                r = r, g = g, b = b,
                isBeam = true,
                horizontal = horizontal,
                maxLife = 0.32f
            )
        )
    }

    fun invalidateMapBadges() {
        badgeCacheVersion = -1
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.043f, 0.008f, 0.125f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        compileShaderProgram()
        buildAllMeshes()
        texGrid = uploadBitmapTexture(createGridBitmap(), repeat = true)
        texMarquee = uploadBitmapTexture(createMarqueeBitmap(), repeat = false)
        badgeCacheVersion = -1
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportW = max(1, width)
        viewportH = max(1, height)
        GLES20.glViewport(0, 0, viewportW, viewportH)
        updateProjectionAndFraming()
    }

    private fun updateProjectionAndFraming() {
        val aspect = viewportW.toFloat() / viewportH.toFloat()
        val fovY = 46f
        Matrix.perspectiveM(projMatrix, 0, fovY, aspect, 0.1f, 160f)

        val tanHalfFov = kotlin.math.tan(Math.toRadians((fovY / 2.0))).toFloat()
        when (screenMode) {
            ScreenMode.GAME -> {
                val halfBoard = 5.05f
                val distV = halfBoard / tanHalfFov
                val distH = halfBoard / (tanHalfFov * aspect)
                val dist = max(distV, distH) * 1.15f
                baseCamPos[0] = 0f; baseCamPos[1] = -0.25f; baseCamPos[2] = dist
            }
            ScreenMode.MENU -> {
                val dist = if (aspect < 0.7f) 14.4f else 11.2f
                baseCamPos[0] = 0f; baseCamPos[1] = 0.3f; baseCamPos[2] = dist
            }
            ScreenMode.MAP -> {
                val dist = if (aspect < 0.7f) 12.2f else 9.6f
                baseCamPos[0] = 0f; baseCamPos[1] = mapScrollY; baseCamPos[2] = dist
            }
        }
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = min(0.05f, (now - lastFrameNs) / 1_000_000_000f)
        lastFrameNs = now
        elapsedSec += dt

        updateProjectionAndFraming()

        // Smooth camera interpolation + screen shake
        val goalX = baseCamPos[0]
        val goalY = baseCamPos[1]
        val goalZ = baseCamPos[2]

        if (screenMode == ScreenMode.MAP) {
            mapScrollY += (mapTargetScrollY - mapScrollY) * 0.15f
            camPos[0] += (goalX - camPos[0]) * 0.18f
            camPos[1] += (mapScrollY - camPos[1]) * 0.22f
            camPos[2] += (goalZ - camPos[2]) * 0.18f
        } else {
            var sx = 0f; var sy = 0f
            if (shakeTime > 0f) {
                shakeTime -= dt
                sx = (Random.nextFloat() - 0.5f) * shakeAmp
                sy = (Random.nextFloat() - 0.5f) * shakeAmp
                if (shakeTime <= 0f) shakeAmp = 0f
            }
            camPos[0] += (goalX - camPos[0]) * 0.16f + sx
            camPos[1] += (goalY - camPos[1]) * 0.16f + sy
            camPos[2] += (goalZ - camPos[2]) * 0.16f
        }

        val lookY = when (screenMode) {
            ScreenMode.MENU -> 0.45f
            ScreenMode.MAP -> camPos[1] + 0.25f
            ScreenMode.GAME -> -0.25f
        }

        Matrix.setLookAtM(viewMatrix, 0, camPos[0], camPos[1], camPos[2], 0f, lookY, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)
        Matrix.invertM(invVpMatrix, 0, vpMatrix, 0)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(program)
        GLES20.glUniform3f(uCamPos, camPos[0], camPos[1], camPos[2])

        // 1. Draw Retro Synthwave Environment
        drawEnvironment()

        // 2. Draw Active Scene
        when (screenMode) {
            ScreenMode.MENU -> drawMainMenuScene()
            ScreenMode.MAP -> drawMapScene()
            ScreenMode.GAME -> drawGameplayBoardScene(dt)
        }

        // 3. Draw 3D Particles & Shockwaves
        drawVfx(dt)
    }

    private fun drawMesh(
        mesh: GpuMesh,
        x: Float, y: Float, z: Float,
        rxDeg: Float = 0f, ryDeg: Float = 0f, rzDeg: Float = 0f,
        sx: Float = 1f, sy: Float = 1f, sz: Float = 1f,
        tintR: Float = 1f, tintG: Float = 1f, tintB: Float = 1f,
        emR: Float = 0f, emG: Float = 0f, emB: Float = 0f,
        alpha: Float = 1f,
        texId: Int = 0,
        unlit: Boolean = false,
        uvOffX: Float = 0f, uvOffY: Float = 0f
    ) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, x, y, z)
        if (ryDeg != 0f) Matrix.rotateM(modelMatrix, 0, ryDeg, 0f, 1f, 0f)
        if (rxDeg != 0f) Matrix.rotateM(modelMatrix, 0, rxDeg, 1f, 0f, 0f)
        if (rzDeg != 0f) Matrix.rotateM(modelMatrix, 0, rzDeg, 0f, 0f, 1f)
        if (sx != 1f || sy != 1f || sz != 1f) Matrix.scaleM(modelMatrix, 0, sx, sy, sz)

        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, modelMatrix, 0)
        GLES20.glUniform3f(uColorTint, tintR, tintG, tintB)
        GLES20.glUniform3f(uEmissive, emR, emG, emB)
        GLES20.glUniform1f(uAlpha, alpha)
        GLES20.glUniform1i(uUnlit, if (unlit) 1 else 0)
        GLES20.glUniform2f(uUvOffset, uvOffX, uvOffY)

        if (texId != 0) {
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
            GLES20.glUniform1i(uTex, 0)
            GLES20.glUniform1i(uUseTex, 1)
        } else {
            GLES20.glUniform1i(uUseTex, 0)
        }

        mesh.bindAndDraw(aPos, aNorm, aCol, aUv)
    }

    private fun drawEnvironment() {
        // Scrolling retro grid floor
        val scrollV = (elapsedSec * 0.28f) % 1f
        val floorY = if (screenMode == ScreenMode.MAP) camPos[1] - 7.5f else -6.8f
        drawMesh(
            floorMesh,
            0f, floorY, -10f,
            rxDeg = -90f,
            emR = 0.16f, emG = 0.02f, emB = 0.30f,
            texId = texGrid,
            unlit = true,
            uvOffY = scrollV
        )

        // Glowing retro synthwave sun disc in distant sky
        val sunY = if (screenMode == ScreenMode.MAP) camPos[1] + 2.5f else 2.4f
        GLES20.glDepthMask(false)
        drawMesh(
            sunMesh,
            0f, sunY, -26f,
            alpha = 0.34f,
            unlit = true
        )
        GLES20.glDepthMask(true)
    }

    private fun drawMainMenuScene() {
        // Bobbing & gently tilting 3D Arcade Marquee Sign
        val logoY = 2.0f + sin(elapsedSec * 1.6f) * 0.13f
        val logoRy = sin(elapsedSec * 1.1f) * 11f
        val logoRx = cos(elapsedSec * 0.8f) * 4f
        drawMesh(
            marqueeMesh,
            0f, logoY, 0f,
            rxDeg = logoRx, ryDeg = logoRy,
            texId = texMarquee,
            emR = 0.25f, emG = 0.15f, emB = 0.35f
        )

        // 14 Orbiting & Bouncing 3D Glossy Fruits
        for (i in 0 until 14) {
            val typeIdx = i % FruitType.entries.size
            val baseAngle = (i / 14f) * 2f * PI.toFloat()
            val speed = 0.35f + (i % 3) * 0.12f
            val angle = baseAngle + elapsedSec * speed
            val radius = 3.5f + (i % 3) * 1.05f
            val baseY = (i % 4 - 1.5f) * 1.35f
            val x = cos(angle) * radius
            val z = -1.6f + sin(angle) * 2.3f
            val y = baseY + sin(elapsedSec * 2.2f + i * 0.8f) * 0.38f
            val sc = 0.92f + (i % 3) * 0.16f
            drawMesh(
                fruitMeshes[typeIdx],
                x, y, z,
                rxDeg = sin(elapsedSec + i) * 16f,
                ryDeg = (elapsedSec * 78f + i * 25f) % 360f,
                sx = sc, sy = sc, sz = sc
            )
        }
    }

    private fun drawMapScene() {
        val currentVersion = saveSnapshot.unlockedLevel * 1000 + saveSnapshot.totalStars
        if (badgeCacheVersion != currentVersion) {
            badgeCacheVersion = currentVersion
            for (i in 0 until 100) {
                val lvlId = i + 1
                val state = when {
                    lvlId > saveSnapshot.unlockedLevel -> 0
                    lvlId == saveSnapshot.unlockedLevel -> 1
                    else -> 2
                }
                val stars = saveSnapshot.stars[lvlId] ?: 0
                val bmp = createLevelBadgeBitmap(lvlId, state, stars, lvlId % 10 == 0)
                if (texBadgeCache[i] != 0) {
                    GLES20.glDeleteTextures(1, intArrayOf(texBadgeCache[i]), 0)
                }
                texBadgeCache[i] = uploadBitmapTexture(bmp, repeat = false)
            }
        }

        // Draw winding neon road segments connecting visible nodes
        val minY = camPos[1] - 12f
        val maxY = camPos[1] + 12f

        for (i in 0 until mapNodes.lastIndex) {
            val a = mapNodes[i]
            val b = mapNodes[i + 1]
            if (b.y < minY || a.y > maxY) continue
            val mx = (a.x + b.x) * 0.5f
            val my = (a.y + b.y) * 0.5f
            val mz = (a.z + b.z) * 0.5f - 0.15f
            val dx = b.x - a.x; val dy = b.y - a.y
            val len = sqrt(dx * dx + dy * dy)
            val angDeg = Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble())).toFloat() - 90f
            drawMesh(
                mapPathMesh,
                mx, my, mz,
                rzDeg = angDeg,
                sx = 1f, sy = len, sz = 1f,
                emR = 0.0f, emG = 0.35f, emB = 0.55f
            )
        }

        // Draw visible 3D Pedestals + Badges + Boss Fruits
        for (i in mapNodes.indices) {
            val node = mapNodes[i]
            if (node.y < minY || node.y > maxY) continue
            val lvlId = node.id
            val isUnlocked = lvlId <= saveSnapshot.unlockedLevel
            val isCurrent = lvlId == saveSnapshot.unlockedLevel

            val pulse = if (isCurrent) 1f + sin(elapsedSec * 4.5f) * 0.08f else 1f
            val (pr, pg, pb) = when {
                !isUnlocked -> Triple(0.18f, 0.12f, 0.28f)
                isCurrent -> Triple(1.0f, 0.16f, 0.52f)
                else -> Triple(0.0f, 0.55f, 0.85f)
            }

            drawMesh(
                mapPedestalMesh,
                node.x, node.y, node.z,
                rxDeg = 90f,
                sx = pulse, sy = pulse, sz = pulse,
                tintR = pr, tintG = pg, tintB = pb,
                emR = if (isCurrent) 0.35f else 0.05f,
                emG = if (isCurrent) 0.05f else 0.10f,
                emB = if (isCurrent) 0.20f else 0.20f
            )

            drawMesh(
                mapBadgeMesh,
                node.x, node.y, node.z + 0.24f,
                sx = pulse, sy = pulse, sz = 1f,
                texId = texBadgeCache[i],
                unlit = true
            )

            if (node.isBoss) {
                val bossFruit = (i / 10) % FruitType.entries.size
                drawMesh(
                    fruitMeshes[bossFruit],
                    node.x + 0.92f, node.y + 0.15f + sin(elapsedSec * 2.5f + i) * 0.1f, node.z + 0.32f,
                    ryDeg = (elapsedSec * 90f) % 360f,
                    sx = 0.62f, sy = 0.62f, sz = 0.62f
                )
            }
        }
    }

    private fun drawGameplayBoardScene(dt: Float) {
        // 1. Arcade Cabinet Backplane & Neon Rim
        drawMesh(boardBackMesh, 0f, 0f, -0.58f)
        drawMesh(rimHorizCyanMesh, 0f, 4.52f, -0.35f, unlit = true)
        drawMesh(rimHorizCyanMesh, 0f, -4.52f, -0.35f, unlit = true)
        drawMesh(rimVertPinkMesh, -4.52f, 0f, -0.35f, unlit = true)
        drawMesh(rimVertPinkMesh, 4.52f, 0f, -0.35f, unlit = true)

        // 2. Checkered Board Pads
        for (r in 0..7) {
            for (c in 0..7) {
                val wx = gridToWorldX(c)
                val wy = gridToWorldY(r)
                val pad = if ((r + c) % 2 == 0) padLightMesh else padDarkMesh
                drawMesh(pad, wx, wy, -0.34f)
            }
        }

        // 3. Opaque Fruits + Stones + Drop Shadows
        synchronized(gridLock) {
            for (r in 0..7) {
                for (c in 0..7) {
                    val wx = gridToWorldX(c)
                    val wy = gridToWorldY(r)

                    val sv = stoneGrid[r][c]
                    if (sv > 0) {
                        val dark = sv == 2
                        drawMesh(
                            stoneMesh,
                            wx, wy, 0.0f,
                            tintR = if (dark) 0.45f else 0.78f,
                            tintG = if (dark) 0.38f else 0.72f,
                            tintB = if (dark) 0.65f else 0.95f
                        )
                    }

                    val cell = boardGrid[r][c] ?: continue
                    // Smooth fall interpolation inside GL loop
                    cell.curX += (cell.targetX - cell.curX) * min(1f, dt * 16f)
                    cell.curY += (cell.targetY - cell.curY) * min(1f, dt * 16f)

                    // Soft dark shadow disc behind fruit
                    drawMesh(
                        shadowMesh,
                        cell.curX + 0.05f, cell.curY - 0.07f, -0.25f,
                        alpha = 0.42f,
                        unlit = true
                    )

                    val isSel = selectedCell?.r == r && selectedCell?.c == c
                    val targetSc = if (isSel) 1.08f + sin(elapsedSec * 8f) * 0.05f else 0.90f
                    cell.scale += (targetSc - cell.scale) * min(1f, dt * 14f)

                    val rotY = sin(elapsedSec * 1.5f + r * 0.5f + c * 0.7f) * 14f +
                        if (isSel) (elapsedSec * 180f) % 360f else 0f

                    if (cell.special == SpecialType.COLOR) {
                        val hue = (elapsedSec * 0.45f) % 1f
                        val em = hslToRgb(hue, 0.9f, 0.45f)
                        drawMesh(
                            colorPrismMesh,
                            cell.curX, cell.curY, cell.curZ,
                            rxDeg = (elapsedSec * 90f) % 360f,
                            ryDeg = (elapsedSec * 140f) % 360f,
                            sx = cell.scale, sy = cell.scale, sz = cell.scale,
                            emR = em[0], emG = em[1], emB = em[2]
                        )
                        drawMesh(
                            torusRingMesh,
                            cell.curX, cell.curY, cell.curZ,
                            rxDeg = (elapsedSec * 120f) % 360f,
                            rzDeg = (elapsedSec * 160f) % 360f,
                            sx = cell.scale, sy = cell.scale, sz = cell.scale,
                            unlit = true
                        )
                    } else {
                        drawMesh(
                            fruitMeshes[cell.type.id],
                            cell.curX, cell.curY, cell.curZ,
                            ryDeg = rotY,
                            sx = cell.scale, sy = cell.scale, sz = cell.scale
                        )

                        if (cell.special == SpecialType.ROW || cell.special == SpecialType.COL) {
                            val baseRx = if (cell.special == SpecialType.ROW) 90f else 0f
                            val baseRy = if (cell.special == SpecialType.COL) 90f else 0f
                            drawMesh(
                                torusRingMesh,
                                cell.curX, cell.curY, cell.curZ,
                                rxDeg = baseRx + sin(elapsedSec * 3f) * 18f,
                                ryDeg = baseRy,
                                rzDeg = (elapsedSec * 180f) % 360f,
                                sx = cell.scale, sy = cell.scale, sz = cell.scale,
                                unlit = true
                            )
                            drawMesh(
                                torusRingWhiteMesh,
                                cell.curX, cell.curY, cell.curZ,
                                rxDeg = baseRx + 25f,
                                ryDeg = baseRy + 20f,
                                rzDeg = -(elapsedSec * 150f) % 360f,
                                sx = cell.scale * 0.94f, sy = cell.scale * 0.94f, sz = cell.scale * 0.94f,
                                unlit = true
                            )
                        } else if (cell.special == SpecialType.BOMB) {
                            drawMesh(
                                bombAuraMesh,
                                cell.curX, cell.curY, cell.curZ,
                                rxDeg = (elapsedSec * 110f) % 360f,
                                ryDeg = (elapsedSec * 145f) % 360f,
                                sx = cell.scale * (1.0f + sin(elapsedSec * 6f) * 0.06f),
                                sy = cell.scale * (1.0f + sin(elapsedSec * 6f) * 0.06f),
                                sz = cell.scale * (1.0f + sin(elapsedSec * 6f) * 0.06f),
                                alpha = 0.45f,
                                unlit = true
                            )
                        }
                    }
                }
            }
        }

        // 4. Translucent Ice & Cages & Selection Ring
        GLES20.glDepthMask(false)
        for (r in 0..7) {
            for (c in 0..7) {
                val wx = gridToWorldX(c)
                val wy = gridToWorldY(r)
                val iv = iceGrid[r][c]
                if (iv > 0) {
                    drawMesh(
                        iceMesh,
                        wx, wy, 0.02f,
                        tintR = if (iv == 2) 0.15f else 0.65f,
                        tintG = if (iv == 2) 0.72f else 0.96f,
                        tintB = 1.0f,
                        emR = 0.05f, emG = 0.25f, emB = 0.35f,
                        alpha = if (iv == 2) 0.62f else 0.40f
                    )
                }
                if (cageGrid[r][c] > 0) {
                    drawMesh(
                        cageMesh,
                        wx, wy, 0.16f,
                        alpha = 0.85f,
                        unlit = true
                    )
                }
            }
        }

        selectedCell?.let { sel ->
            val pulse = 1f + sin(elapsedSec * 8f) * 0.07f
            drawMesh(
                selectRingMesh,
                gridToWorldX(sel.c), gridToWorldY(sel.r), 0.32f,
                rzDeg = (elapsedSec * 90f) % 360f,
                sx = pulse, sy = pulse, sz = 1f,
                unlit = true
            )
        }
        GLES20.glDepthMask(true)
    }

    private fun drawVfx(dt: Float) {
        GLES20.glDepthMask(false)
        val pIt = particles.iterator()
        while (pIt.hasNext()) {
            val p = pIt.next()
            p.life += dt
            if (p.life >= p.maxLife) {
                particles.remove(p)
                continue
            }
            p.vy -= 11f * dt
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.z += p.vz * dt
            p.rx += 380f * dt
            p.ry += 440f * dt
            val k = 1f - p.life / p.maxLife
            val sc = p.baseScale * k
            drawMesh(
                particleMesh,
                p.x, p.y, p.z,
                rxDeg = p.rx, ryDeg = p.ry,
                sx = sc, sy = sc, sz = sc,
                tintR = p.r, tintG = p.g, tintB = p.b,
                alpha = k,
                unlit = true
            )
        }

        val sIt = shockwaves.iterator()
        while (sIt.hasNext()) {
            val s = sIt.next()
            s.life += dt
            if (s.life >= s.maxLife) {
                shockwaves.remove(s)
                continue
            }
            val t = s.life / s.maxLife
            if (s.isBeam) {
                val beamMesh = if (s.horizontal) beamHorizMesh else beamVertMesh
                val sc = 1f + t * 0.6f
                drawMesh(
                    beamMesh,
                    s.x, s.y, s.z,
                    sx = if (s.horizontal) 1f else sc,
                    sy = if (s.horizontal) sc else 1f,
                    sz = 1f,
                    tintR = s.r, tintG = s.g, tintB = s.b,
                    alpha = 1f - t,
                    unlit = true
                )
            } else {
                val sc = 1f + t * s.targetScale
                drawMesh(
                    shockwaveMesh,
                    s.x, s.y, s.z,
                    sx = sc, sy = sc, sz = 1f,
                    tintR = s.r, tintG = s.g, tintB = s.b,
                    alpha = (1f - t) * 0.9f,
                    unlit = true
                )
            }
        }
        GLES20.glDepthMask(true)
    }

    // Raycast Helpers
    fun raycastBoardCell(screenX: Float, screenY: Float): CellPos? {
        val hit = raycastToZPlane(screenX, screenY, 0f) ?: return null
        val c = ((hit[0] + BOARD_OFFSET) / CELL_SIZE).roundToInt()
        val r = ((BOARD_OFFSET - hit[1]) / CELL_SIZE).roundToInt()
        if (r !in 0..7 || c !in 0..7) return null
        return CellPos(r, c)
    }

    fun raycastMapNode(screenX: Float, screenY: Float): Int? {
        val hit = raycastToZPlane(screenX, screenY, 0.24f) ?: return null
        var bestId: Int? = null
        var bestDist = 0.85f * 0.85f
        for (n in mapNodes) {
            val dx = hit[0] - n.x
            val dy = hit[1] - n.y
            val d2 = dx * dx + dy * dy
            if (d2 < bestDist) {
                bestDist = d2
                bestId = n.id
            }
        }
        return bestId
    }

    private fun raycastToZPlane(screenX: Float, screenY: Float, planeZ: Float): FloatArray? {
        val ndcX = (screenX / viewportW) * 2f - 1f
        val ndcY = 1f - (screenY / viewportH) * 2f

        val nearWorld = FloatArray(4)
        val farWorld = FloatArray(4)
        Matrix.multiplyMV(nearWorld, 0, invVpMatrix, 0, floatArrayOf(ndcX, ndcY, -1f, 1f), 0)
        Matrix.multiplyMV(farWorld, 0, invVpMatrix, 0, floatArrayOf(ndcX, ndcY, 1f, 1f), 0)

        if (abs(nearWorld[3]) < 1e-6f || abs(farWorld[3]) < 1e-6f) return null
        for (i in 0..2) {
            nearWorld[i] /= nearWorld[3]
            farWorld[i] /= farWorld[3]
        }

        val dz = farWorld[2] - nearWorld[2]
        if (abs(dz) < 1e-6f) return null
        val t = (planeZ - nearWorld[2]) / dz
        return floatArrayOf(
            nearWorld[0] + (farWorld[0] - nearWorld[0]) * t,
            nearWorld[1] + (farWorld[1] - nearWorld[1]) * t
        )
    }

    private fun hslToRgb(h: Float, s: Float, l: Float): FloatArray {
        val c = (1f - abs(2f * l - 1f)) * s
        val x = c * (1f - abs((h * 6f) % 2f - 1f))
        val m = l - c / 2f
        val (r1, g1, b1) = when ((h * 6f).toInt() % 6) {
            0 -> Triple(c, x, 0f)
            1 -> Triple(x, c, 0f)
            2 -> Triple(0f, c, x)
            3 -> Triple(0f, x, c)
            4 -> Triple(x, 0f, c)
            else -> Triple(c, 0f, x)
        }
        return floatArrayOf(r1 + m, g1 + m, b1 + m)
    }

    private fun buildAllMeshes() {
        fruitMeshes = arrayOf(
            FruitMeshFactory.buildStrawberry(),
            FruitMeshFactory.buildCherry(),
            FruitMeshFactory.buildOrange(),
            FruitMeshFactory.buildLemon(),
            FruitMeshFactory.buildGrape(),
            FruitMeshFactory.buildBlueberry(),
            FruitMeshFactory.buildWatermelon(),
            FruitMeshFactory.buildPineapple()
        )

        torusRingMesh = MeshDataBuilder().apply { addTorus(0.45f, 0.036f, 0f, 0.94f, 1f) }.build()
        torusRingWhiteMesh = MeshDataBuilder().apply { addTorus(0.42f, 0.026f, 1f, 1f, 1f) }.build()
        bombAuraMesh = MeshDataBuilder().apply {
            addTorus(0.45f, 0.03f, 1f, 0.84f, 0f, tiltX = 0.9f)
            addTorus(0.45f, 0.03f, 1f, 0.84f, 0f, tiltY = 0.9f)
            addSphere(0f, 0f, 0f, 0.48f, 0.48f, 0.48f, 1f, 0.84f, 0f, 10, 14)
        }.build()
        colorPrismMesh = MeshDataBuilder().apply { addOctahedron(0.40f) }.build()

        floorMesh = MeshDataBuilder().apply {
            addQuad(
                -45f, -45f, 0f, 0f, 0f,
                45f, -45f, 0f, 18f, 0f,
                45f, 45f, 0f, 18f, 18f,
                -45f, 45f, 0f, 0f, 18f,
                0f, 0f, 1f, 1f, 1f, 1f
            )
        }.build()

        sunMesh = MeshDataBuilder().apply {
            addDisc(0f, 7.6f, 0f, 1f, 0.16f, 0.52f, 48)
        }.build()

        marqueeMesh = MeshDataBuilder().apply {
            // Beveled colorful frame + front textured marquee face
            addOrientedBox(0f, 0f, -0.14f, 3.45f, 1.72f, 0.14f, 0.14f, 0.03f, 0.34f)
            addOrientedBox(0f, 1.72f, 0f, 3.55f, 0.08f, 0.18f, 0f, 0.94f, 1f)
            addOrientedBox(0f, -1.72f, 0f, 3.55f, 0.08f, 0.18f, 1f, 0.16f, 0.52f)
            addOrientedBox(-3.48f, 0f, 0f, 0.08f, 1.75f, 0.18f, 1f, 0.84f, 0f)
            addOrientedBox(3.48f, 0f, 0f, 0.08f, 1.75f, 0.18f, 1f, 0.84f, 0f)
            addQuad(
                -3.35f, -1.62f, 0.02f, 0f, 1f,
                3.35f, -1.62f, 0.02f, 1f, 1f,
                3.35f, 1.62f, 0.02f, 1f, 0f,
                -3.35f, 1.62f, 0.02f, 0f, 0f,
                0f, 0f, 1f, 1f, 1f, 1f
            )
        }.build()

        boardBackMesh = MeshDataBuilder().apply {
            addOrientedBox(0f, 0f, 0f, 4.46f, 4.46f, 0.22f, 0.08f, 0.02f, 0.20f)
        }.build()
        rimHorizCyanMesh = MeshDataBuilder().apply {
            addOrientedBox(0f, 0f, 0f, 4.56f, 0.08f, 0.09f, 0f, 0.94f, 1f)
        }.build()
        rimVertPinkMesh = MeshDataBuilder().apply {
            addOrientedBox(0f, 0f, 0f, 0.08f, 4.56f, 0.09f, 1f, 0.16f, 0.52f)
        }.build()
        padLightMesh = MeshDataBuilder().apply {
            addOrientedBox(0f, 0f, 0f, 0.47f, 0.47f, 0.07f, 0.20f, 0.07f, 0.44f)
        }.build()
        padDarkMesh = MeshDataBuilder().apply {
            addOrientedBox(0f, 0f, 0f, 0.47f, 0.47f, 0.07f, 0.12f, 0.03f, 0.30f)
        }.build()

        iceMesh = MeshDataBuilder().apply {
            addOrientedBox(0f, 0f, 0f, 0.48f, 0.48f, 0.30f, 1f, 1f, 1f)
        }.build()
        cageMesh = MeshDataBuilder().apply {
            val r = 0.44f; val t = 0.038f
            addOrientedBox(0f, r, 0f, r, t, t, 1f, 0.16f, 0.52f)
            addOrientedBox(0f, -r, 0f, r, t, t, 1f, 0.16f, 0.52f)
            addOrientedBox(-r, 0f, 0f, t, r, t, 1f, 0.16f, 0.52f)
            addOrientedBox(r, 0f, 0f, t, r, t, 1f, 0.16f, 0.52f)
            addOrientedBox(0f, 0f, 0.22f, r, t * 0.7f, t * 0.7f, 1f, 0.4f, 0.7f)
            addOrientedBox(0f, 0f, 0.22f, t * 0.7f, r, t * 0.7f, 1f, 0.4f, 0.7f)
        }.build()
        stoneMesh = MeshDataBuilder().apply {
            addOrientedBox(0f, 0f, 0f, 0.43f, 0.43f, 0.36f, 0.55f, 0.48f, 0.72f)
            addOrientedBox(0f, 0f, 0.37f, 0.28f, 0.28f, 0.03f, 0.85f, 0.78f, 1.0f)
        }.build()

        shadowMesh = MeshDataBuilder().apply { addDisc(0f, 0.38f, 0f, 0.02f, 0.0f, 0.06f, 18) }.build()
        selectRingMesh = MeshDataBuilder().apply { addDisc(0.42f, 0.52f, 0f, 1f, 0.85f, 0.0f, 28) }.build()
        particleMesh = MeshDataBuilder().apply { addOrientedBox(0f, 0f, 0f, 0.5f, 0.5f, 0.5f, 1f, 1f, 1f) }.build()
        shockwaveMesh = MeshDataBuilder().apply { addDisc(0.22f, 0.34f, 0f, 1f, 1f, 1f, 28) }.build()
        beamHorizMesh = MeshDataBuilder().apply { addOrientedBox(0f, 0f, 0f, 4.3f, 0.18f, 0.15f, 1f, 1f, 1f) }.build()
        beamVertMesh = MeshDataBuilder().apply { addOrientedBox(0f, 0f, 0f, 0.18f, 4.3f, 0.15f, 1f, 1f, 1f) }.build()

        mapPathMesh = MeshDataBuilder().apply {
            addCylinderBetween(0f, -0.5f, 0f, 0f, 0.5f, 0f, 0.13f, 0.13f, 0f, 0.90f, 1f, 10)
        }.build()
        mapPedestalMesh = MeshDataBuilder().apply {
            addCylinderBetween(0f, -0.18f, 0f, 0f, 0.18f, 0f, 0.66f, 0.56f, 1f, 1f, 1f, 20)
        }.build()
        mapBadgeMesh = MeshDataBuilder().apply {
            addQuad(
                -0.58f, -0.58f, 0f, 0f, 1f,
                0.58f, -0.58f, 0f, 1f, 1f,
                0.58f, 0.58f, 0f, 1f, 0f,
                -0.58f, 0.58f, 0f, 0f, 0f,
                0f, 0f, 1f, 1f, 1f, 1f
            )
        }.build()
    }

    private fun createGridBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.rgb(9, 1, 26))
        val p = Paint().apply { style = Paint.Style.STROKE }
        p.color = Color.argb(120, 0, 240, 255)
        p.strokeWidth = 2f
        for (i in 64 until 256 step 64) {
            c.drawLine(i.toFloat(), 0f, i.toFloat(), 256f, p)
            c.drawLine(0f, i.toFloat(), 256f, i.toFloat(), p)
        }
        p.color = Color.rgb(255, 42, 133)
        p.strokeWidth = 4f
        c.drawRect(0f, 0f, 256f, 256f, p)
        return bmp
    }

    private fun createMarqueeBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(1024, 512, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, 0f, 512f,
                Color.rgb(66, 0, 128), Color.rgb(18, 0, 44), Shader.TileMode.CLAMP
            )
        }
        c.drawRoundRect(RectF(20f, 20f, 1004f, 492f), 48f, 48f, bgPaint)

        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 14f
            color = Color.rgb(0, 240, 255)
        }
        c.drawRoundRect(RectF(20f, 20f, 1004f, 492f), 48f, 48f, border)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD)
            textSize = 112f
            color = Color.rgb(255, 213, 0)
            setShadowLayer(22f, 0f, 6f, Color.rgb(255, 42, 133))
        }
        c.drawText("CANDY CRUSH", 512f, 205f, titlePaint)

        val retroPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textSize = 136f
            color = Color.rgb(255, 42, 133)
            setShadowLayer(24f, 0f, 0f, Color.rgb(0, 240, 255))
        }
        c.drawText("RETRO", 512f, 382f, retroPaint)

        val strokePaint = Paint(retroPaint).apply {
            style = Paint.Style.STROKE
            strokeWidth = 5f
            color = Color.WHITE
            clearShadowLayer()
        }
        c.drawText("RETRO", 512f, 382f, strokePaint)
        return bmp
    }

    private fun createLevelBadgeBitmap(num: Int, state: Int, stars: Int, isBoss: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(160, 160, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = when (state) {
                0 -> Color.rgb(37, 26, 64)
                1 -> Color.rgb(255, 42, 133)
                else -> Color.rgb(0, 180, 216)
            }
        }
        c.drawCircle(80f, 74f, 56f, fill)

        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 8f
            color = when {
                isBoss -> Color.rgb(255, 213, 0)
                state == 0 -> Color.rgb(94, 75, 139)
                else -> Color.WHITE
            }
        }
        c.drawCircle(80f, 74f, 56f, ring)

        val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD)
            textSize = if (state == 0) 38f else 44f
            color = if (state == 0) Color.rgb(141, 124, 184) else Color.WHITE
        }
        val label = if (state == 0) "\uD83D\uDD12" else num.toString()
        c.drawText(label, 80f, 89f, txt)

        if (stars > 0) {
            val st = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textAlign = Paint.Align.CENTER
                textSize = 28f
                color = Color.rgb(255, 213, 0)
            }
            c.drawText("\u2605".repeat(stars), 80f, 150f, st)
        }
        return bmp
    }

    private fun uploadBitmapTexture(bitmap: Bitmap, repeat: Boolean): Int {
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        val wrap = if (repeat) GLES20.GL_REPEAT else GLES20.GL_CLAMP_TO_EDGE
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, wrap)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, wrap)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        bitmap.recycle()
        return ids[0]
    }

    private fun compileShaderProgram() {
        val vsCode = """
            uniform mat4 uMvp;
            uniform mat4 uModel;
            uniform vec2 uUvOffset;
            attribute vec3 aPos;
            attribute vec3 aNorm;
            attribute vec3 aCol;
            attribute vec2 aUv;
            varying vec3 vWorldPos;
            varying vec3 vNorm;
            varying vec3 vCol;
            varying vec2 vUv;
            void main() {
                vec4 wp = uModel * vec4(aPos, 1.0);
                vWorldPos = wp.xyz;
                vNorm = normalize(mat3(uModel) * aNorm);
                vCol = aCol;
                vUv = aUv + uUvOffset;
                gl_Position = uMvp * vec4(aPos, 1.0);
            }
        """.trimIndent()

        val fsCode = """
            precision mediump float;
            uniform vec3 uCamPos;
            uniform vec3 uColorTint;
            uniform vec3 uEmissive;
            uniform float uAlpha;
            uniform int uUseTex;
            uniform int uUnlit;
            uniform sampler2D uTex;
            varying vec3 vWorldPos;
            varying vec3 vNorm;
            varying vec3 vCol;
            varying vec2 vUv;
            void main() {
                vec4 base = vec4(vCol * uColorTint, 1.0);
                if (uUseTex == 1) {
                    vec4 texCol = texture2D(uTex, vUv);
                    base = vec4(texCol.rgb * uColorTint, texCol.a);
                }
                if (uUnlit == 1) {
                    gl_FragColor = vec4(base.rgb + uEmissive, base.a * uAlpha);
                    return;
                }
                vec3 N = normalize(vNorm);
                vec3 V = normalize(uCamPos - vWorldPos);

                // Key white light + Clearcoat specular
                vec3 L1 = normalize(vec3(5.0, 9.0, 12.0));
                vec3 H1 = normalize(L1 + V);
                float diff1 = max(dot(N, L1), 0.0);
                float spec1 = pow(max(dot(N, H1), 0.0), 54.0) * 1.15;

                // Dual neon arcade rim lights (cyan left, pink right)
                vec3 L2 = normalize(vec3(-8.0, 3.0, 6.0));
                float diff2 = max(dot(N, L2), 0.0);
                vec3 L3 = normalize(vec3(8.0, -3.0, 6.0));
                float diff3 = max(dot(N, L3), 0.0);

                // Clearcoat Fresnel reflection
                float fresnel = pow(1.0 - max(dot(N, V), 0.0), 3.0);

                vec3 lit = base.rgb * (0.42 + diff1 * 0.72)
                         + base.rgb * vec3(0.0, 0.85, 1.0) * diff2 * 0.25
                         + base.rgb * vec3(1.0, 0.2, 0.55) * diff3 * 0.22
                         + vec3(1.0) * spec1
                         + vec3(0.55, 0.90, 1.0) * fresnel * 0.34
                         + uEmissive;

                gl_FragColor = vec4(lit, base.a * uAlpha);
            }
        """.trimIndent()

        val vs = compileShader(GLES20.GL_VERTEX_SHADER, vsCode)
        val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fsCode)
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vs)
        GLES20.glAttachShader(program, fs)
        GLES20.glLinkProgram(program)

        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aNorm = GLES20.glGetAttribLocation(program, "aNorm")
        aCol = GLES20.glGetAttribLocation(program, "aCol")
        aUv = GLES20.glGetAttribLocation(program, "aUv")

        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uModel = GLES20.glGetUniformLocation(program, "uModel")
        uCamPos = GLES20.glGetUniformLocation(program, "uCamPos")
        uColorTint = GLES20.glGetUniformLocation(program, "uColorTint")
        uEmissive = GLES20.glGetUniformLocation(program, "uEmissive")
        uAlpha = GLES20.glGetUniformLocation(program, "uAlpha")
        uUseTex = GLES20.glGetUniformLocation(program, "uUseTex")
        uUnlit = GLES20.glGetUniformLocation(program, "uUnlit")
        uUvOffset = GLES20.glGetUniformLocation(program, "uUvOffset")
        uTex = GLES20.glGetUniformLocation(program, "uTex")
    }

    private fun compileShader(type: Int, src: String): Int {
        val id = GLES20.glCreateShader(type)
        GLES20.glShaderSource(id, src)
        GLES20.glCompileShader(id)
        return id
    }
}
