package com.example.model

enum class FruitType(
    val id: Int,
    val displayName: String,
    val emoji: String,
    val colorInt: Int
) {
    STRAWBERRY(0, "Strawberry", "\uD83C\uDF53", 0xFFFF2048.toInt()),
    CHERRY(1, "Cherry", "\uD83C\uDF52", 0xFFD90429.toInt()),
    ORANGE(2, "Orange", "\uD83C\uDF4A", 0xFFFF7B00.toInt()),
    LEMON(3, "Lemon", "\uD83C\uDF4B", 0xFFFFE600.toInt()),
    GRAPE(4, "Grapes", "\uD83C\uDF47", 0xFF9D4EDD.toInt()),
    BLUEBERRY(5, "Blueberry", "\uD83E\uDED0", 0xFF2962FF.toInt()),
    WATERMELON(6, "Watermelon", "\uD83C\uDF49", 0xFF00E676.toInt()),
    PINEAPPLE(7, "Pineapple", "\uD83C\uDF4D", 0xFFFFB703.toInt());

    companion object {
        fun fromId(id: Int): FruitType = entries[id.coerceIn(0, entries.lastIndex)]
    }
}

enum class SpecialType {
    NONE,
    ROW,
    COL,
    BOMB,
    COLOR
}

enum class BoosterType(val label: String, val icon: String) {
    HAMMER("Hammer", "\uD83D\uDD28"),
    BOMB("Bomb 3x3", "\uD83D\uDCA3"),
    LASER("CrossZap", "\u26A1"),
    PAINT("ColorZap", "\uD83C\uDFA8")
}

enum class ObjectiveType {
    SCORE,
    ICE,
    COLLECT,
    MIXED
}

data class LevelLayout(
    val ice: Array<IntArray>,
    val cage: Array<IntArray>,
    val stone: Array<IntArray>,
    val iceCount: Int
)

data class LevelDef(
    val id: Int,
    val world: Int,
    val worldName: String,
    val isBoss: Boolean,
    val title: String,
    val fruitCount: Int,
    val moves: Int,
    val objType: ObjectiveType,
    val targetScore: Int,
    val starScores: Triple<Int, Int, Int>,
    val collectTargets: Map<FruitType, Int>,
    val layout: LevelLayout,
    val difficultyLabel: String = "Normal"
) {
    fun describeObjective(): String {
        val parts = mutableListOf<String>()
        if (objType == ObjectiveType.SCORE) {
            parts += "Reach ${"%,d".format(targetScore)} pts"
        }
        if (objType == ObjectiveType.ICE || objType == ObjectiveType.MIXED) {
            parts += "Break ${layout.iceCount} Ice"
        }
        if (objType == ObjectiveType.COLLECT || objType == ObjectiveType.MIXED) {
            collectTargets.forEach { (fruit, qty) ->
                parts += "$qty ${fruit.emoji}"
            }
        }
        return parts.joinToString(" + ")
    }
}

data class CellPos(val r: Int, val c: Int) {
    fun isAdjacentTo(other: CellPos): Boolean =
        kotlin.math.abs(r - other.r) + kotlin.math.abs(c - other.c) == 1
}

data class FruitCell(
    val uid: Long,
    var type: FruitType,
    var special: SpecialType = SpecialType.NONE,
    var curX: Float,
    var curY: Float,
    var curZ: Float = 0f,
    var targetX: Float,
    var targetY: Float,
    var scale: Float = 0.92f
)

enum class ScreenMode {
    MENU,
    MAP,
    GAME
}

enum class ActiveModal {
    NONE,
    PAUSE,
    SETTINGS,
    TUTORIAL,
    WIN,
    LOSE,
    GRAND_VICTORY,
    DAILY_BONUS,
    LEADERBOARD
}

data class LeaderboardEntry(
    val score: Int,
    val levelId: Int,
    val timestamp: Long
)

data class DailyBonusInfo(
    val canClaim: Boolean = false,
    val activeDay: Int = 1,
    val todayRewards: Map<BoosterType, Int> = emptyMap(),
    val lastClaimedDate: String = "",
    val todayDate: String = "",
    val todayDayIdx: Long = -1L
)

data class SaveState(
    val unlockedLevel: Int = 1,
    val stars: Map<Int, Int> = emptyMap(),
    val highScores: Map<Int, Int> = emptyMap(),
    val boosters: Map<BoosterType, Int> = mapOf(
        BoosterType.HAMMER to 4,
        BoosterType.BOMB to 3,
        BoosterType.LASER to 3,
        BoosterType.PAINT to 3
    ),
    val musicVol: Float = 0.65f,
    val sfxVol: Float = 0.85f,
    val musicMuted: Boolean = false,
    val sfxMuted: Boolean = false,
    val lastLogin: Long = 0L,
    val lastDailyBonusDate: String = "",
    val lastDailyBonusDayIdx: Long = -1L,
    val dailyLoginStreak: Int = 0,
    val topScores: List<LeaderboardEntry> = emptyList()
) {
    val totalStars: Int get() = stars.values.sum()
}

data class ComboBannerState(
    val id: Long = 0L,
    val title: String = "",
    val subtitle: String = ""
)

data class WinResult(
    val levelId: Int,
    val stars: Int,
    val score: Int,
    val bonusMessage: String
)

data class GameUiState(
    val screen: ScreenMode = ScreenMode.MENU,
    val activeModal: ActiveModal = ActiveModal.NONE,
    val returnModalToPause: Boolean = false,
    val save: SaveState = SaveState(),
    val currentLevel: LevelDef? = null,
    val movesLeft: Int = 0,
    val score: Int = 0,
    val collected: Map<FruitType, Int> = emptyMap(),
    val iceLeft: Int = 0,
    val comboMultiplier: Int = 1,
    val activeBooster: BoosterType? = null,
    val selectedMapLevel: LevelDef? = null,
    val currentMapWorld: Int = 0,
    val comboBanner: ComboBannerState? = null,
    val toastMessage: String? = null,
    val winResult: WinResult? = null,
    val loseScore: Int = 0,
    val dailyBonus: DailyBonusInfo = DailyBonusInfo(),
    val dailyBonusJustClaimed: Boolean = false
)
