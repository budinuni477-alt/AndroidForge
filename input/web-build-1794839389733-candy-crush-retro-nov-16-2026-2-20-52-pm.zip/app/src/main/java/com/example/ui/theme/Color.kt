package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CosmicBgDark = Color(0xFF0B0220)
val CosmicBgMid = Color(0xFF17063A)
val ArcadePanelBg = Color(0xE012052E)
val ArcadeCardBg = Color(0xF01C0846)

val NeonPink = Color(0xFFFF2A85)
val NeonPinkDark = Color(0xFFC4005E)
val NeonCyan = Color(0xFF00F0FF)
val NeonCyanDark = Color(0xFF0088CC)
val NeonGold = Color(0xFFFFD500)
val NeonGoldDark = Color(0xFFE57E00)
val NeonPurple = Color(0xFF9D4EDD)
val NeonPurpleDark = Color(0xFF5A00C2)
val NeonGreen = Color(0xFF00F58C)
val NeonGreenDark = Color(0xFF009C51)
val NeonRed = Color(0xFFFF3B5C)
