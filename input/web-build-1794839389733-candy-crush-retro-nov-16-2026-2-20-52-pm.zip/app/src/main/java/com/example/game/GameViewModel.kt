package com.example.game

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.RetroAudioEngine
import com.example.data.LevelRepository
import com.example.data.SaveRepository
import com.example.gl.Retro3DRenderer
import com.example.model.ActiveModal
import com.example.model.BoosterType
import com.example.model.CellPos
import com.example.model.ComboBannerState
import com.example.model.FruitCell
import com.example.model.FruitType
import com.example.model.GameUiState
import com.example.model.LeaderboardEntry
import com.example.model.LevelDef
import com.example.model.ObjectiveType
import com.example.model.SaveState
import com.example.model.ScreenMode
import com.example.model.SpecialType
import com.example.model.WinResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class GameViewModel(application: Application) : AndroidViewModel(application) {

    val renderer = Retro3DRenderer()
    val audio = RetroAudioEngine()
    private val saveRepo = SaveRepository(application.applicationContext)

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var uidSeq = 1L
    private var busy = false
    private var paused = false
    private var ended = false
    private var combo = 0
    private var score = 0
    private var movesLeft = 0
    private var collected = HashMap<FruitType, Int>()
    private var currentLevel: LevelDef? = null
    private var toastSeq = 0L

    init {
        audio.start()
        viewModelScope.launch {
            val loaded = saveRepo.saveFlow.first()
            applySave(loaded)
            audio.playMusic(RetroAudioEngine.MusicTrack.MENU)
            checkDailyBonus(loaded)
        }
    }

    private fun applySave(save: SaveState) {
        renderer.saveSnapshot = save
        renderer.invalidateMapBadges()
        audio.applySettings(save.musicVol, save.sfxVol, save.musicMuted, save.sfxMuted)
        _uiState.update { it.copy(save = save) }
    }

    private fun persistSave(newSave: SaveState) {
        val stampedSave = newSave.copy(lastLogin = System.currentTimeMillis())
        applySave(stampedSave)
        viewModelScope.launch { saveRepo.save(stampedSave) }
    }

    fun checkDailyBonus(
        save: SaveState = _uiState.value.save,
        nowMillis: Long = System.currentTimeMillis()
    ) {
        val bonusInfo = DailyBonusManager.checkDailyBonus(save, nowMillis)
        if (bonusInfo.canClaim) {
            _uiState.update {
                it.copy(
                    dailyBonus = bonusInfo,
                    dailyBonusJustClaimed = false,
                    activeModal = ActiveModal.DAILY_BONUS
                )
            }
        } else {
            _uiState.update { it.copy(dailyBonus = bonusInfo) }
        }
    }

    fun onAppPause() {
        audio.pause()
    }

    fun onAppResume() {
        audio.resume()
        checkDailyBonus()
    }

    fun openDailyBonus() {
        audio.playClick()
        val current = _uiState.value
        val existingRewards = if (current.dailyBonus.canClaim && current.dailyBonus.todayRewards.isNotEmpty()) {
            current.dailyBonus.todayRewards
        } else null
        val info = DailyBonusManager.checkDailyBonus(current.save).let { fresh ->
            if (fresh.canClaim && existingRewards != null) fresh.copy(todayRewards = existingRewards) else fresh
        }
        _uiState.update {
            it.copy(
                dailyBonus = info,
                dailyBonusJustClaimed = false,
                activeModal = ActiveModal.DAILY_BONUS
            )
        }
    }

    fun claimDailyBonus() {
        val currentState = _uiState.value
        val currentSave = currentState.save
        val (updatedSave, updatedInfo) = DailyBonusManager.applyClaim(
            save = currentSave,
            precomputedRewards = currentState.dailyBonus.todayRewards
        )
        if (updatedSave == currentSave) {
            audio.playInvalid()
            showToast("Daily bonus already claimed today!")
            _uiState.update { it.copy(dailyBonus = updatedInfo) }
            return
        }
        audio.playColorBomb()
        audio.playLevelWin()
        persistSave(updatedSave)
        val rewardSummary = updatedInfo.todayRewards.entries.joinToString(" + ") { (b, q) -> "+$q ${b.label}" }
        _uiState.update {
            it.copy(
                dailyBonus = updatedInfo,
                dailyBonusJustClaimed = true
            )
        }
        showToast("Day ${updatedInfo.activeDay} Bonus: $rewardSummary!")
    }

    override fun onCleared() {
        super.onCleared()
        audio.release()
    }

    // Navigation & Modals
    fun goToMenu() {
        audio.playClick()
        paused = false
        renderer.screenMode = ScreenMode.MENU
        audio.playMusic(RetroAudioEngine.MusicTrack.MENU)
        _uiState.update {
            it.copy(
                screen = ScreenMode.MENU,
                activeModal = ActiveModal.NONE,
                selectedMapLevel = null,
                comboBanner = null
            )
        }
    }

    fun goToMap() {
        audio.playClick()
        paused = false
        val unlocked = _uiState.value.save.unlockedLevel
        val scrollY = (unlocked - 1) * 1.65f
        renderer.mapTargetScrollY = scrollY
        renderer.mapScrollY = scrollY
        renderer.screenMode = ScreenMode.MAP
        renderer.invalidateMapBadges()
        audio.playMusic(RetroAudioEngine.MusicTrack.MENU)
        _uiState.update {
            it.copy(
                screen = ScreenMode.MAP,
                activeModal = ActiveModal.NONE,
                selectedMapLevel = null,
                currentMapWorld = (unlocked - 1) / 20,
                comboBanner = null
            )
        }
    }

    fun playNextUnlockedLevel() {
        audio.playClick()
        startLevel(_uiState.value.save.unlockedLevel)
    }

    fun jumpToWorld(worldIdx: Int) {
        audio.playClick()
        renderer.mapTargetScrollY = (worldIdx * 20 * 1.65f).coerceIn(0f, 99 * 1.65f)
        _uiState.update { it.copy(currentMapWorld = worldIdx, selectedMapLevel = null) }
    }

    fun scrollMapBy(deltaPixels: Float) {
        val next = (renderer.mapTargetScrollY + deltaPixels * 0.025f).coerceIn(0f, 99 * 1.65f)
        renderer.mapTargetScrollY = next
        val w = min(4, (next / (20f * 1.65f) + 0.15f).toInt())
        if (w != _uiState.value.currentMapWorld) {
            _uiState.update { it.copy(currentMapWorld = w) }
        }
    }

    fun onMapTapped(screenX: Float, screenY: Float) {
        val nodeId = renderer.raycastMapNode(screenX, screenY) ?: return
        audio.playClick()
        val unlocked = _uiState.value.save.unlockedLevel
        if (nodeId > unlocked) {
            showToast("Complete Level ${nodeId - 1} first!")
        } else {
            _uiState.update { it.copy(selectedMapLevel = LevelRepository.getLevel(nodeId)) }
        }
    }

    fun closeMapLevelCard() {
        audio.playClick()
        _uiState.update { it.copy(selectedMapLevel = null) }
    }

    fun openPauseModal() {
        if (_uiState.value.screen != ScreenMode.GAME) return
        audio.playClick()
        paused = true
        _uiState.update { it.copy(activeModal = ActiveModal.PAUSE) }
    }

    fun resumeGame() {
        audio.playClick()
        paused = false
        _uiState.update { it.copy(activeModal = ActiveModal.NONE) }
    }

    fun openSettings(fromPause: Boolean = false) {
        audio.playClick()
        _uiState.update {
            it.copy(
                activeModal = ActiveModal.SETTINGS,
                returnModalToPause = fromPause
            )
        }
    }

    fun closeSettings() {
        audio.playClick()
        val backToPause = _uiState.value.returnModalToPause
        _uiState.update {
            it.copy(
                activeModal = if (backToPause) ActiveModal.PAUSE else ActiveModal.NONE,
                returnModalToPause = false
            )
        }
    }

    fun openTutorial() {
        audio.playClick()
        _uiState.update { it.copy(activeModal = ActiveModal.TUTORIAL) }
    }

    fun openLeaderboard() {
        audio.playClick()
        _uiState.update { it.copy(activeModal = ActiveModal.LEADERBOARD) }
    }

    fun closeModal() {
        audio.playClick()
        _uiState.update { it.copy(activeModal = ActiveModal.NONE) }
    }

    fun handleBackPress(): Boolean {
        val state = _uiState.value
        if (state.activeModal == ActiveModal.SETTINGS && state.returnModalToPause) {
            closeSettings()
            return true
        }
        if (state.activeModal != ActiveModal.NONE) {
            if (state.activeModal == ActiveModal.PAUSE) resumeGame()
            else if (state.activeModal == ActiveModal.WIN || state.activeModal == ActiveModal.LOSE || state.activeModal == ActiveModal.GRAND_VICTORY) goToMap()
            else closeModal()
            return true
        }
        if (state.selectedMapLevel != null) {
            closeMapLevelCard()
            return true
        }
        return when (state.screen) {
            ScreenMode.GAME -> { openPauseModal(); true }
            ScreenMode.MAP -> { goToMenu(); true }
            ScreenMode.MENU -> false
        }
    }

    // Audio Settings
    fun toggleQuickMute() {
        val s = _uiState.value.save
        val muteAll = !(s.musicMuted && s.sfxMuted)
        persistSave(s.copy(musicMuted = muteAll, sfxMuted = muteAll))
        if (!muteAll) audio.playClick()
    }

    fun setMusicVolume(v: Float) {
        persistSave(_uiState.value.save.copy(musicVol = v.coerceIn(0f, 1f)))
    }

    fun setSfxVolume(v: Float) {
        persistSave(_uiState.value.save.copy(sfxVol = v.coerceIn(0f, 1f)))
    }

    fun toggleMusicMute() {
        val s = _uiState.value.save
        persistSave(s.copy(musicMuted = !s.musicMuted))
        audio.playClick()
    }

    fun toggleSfxMute() {
        val s = _uiState.value.save
        persistSave(s.copy(sfxMuted = !s.sfxMuted))
        audio.playClick()
    }

    fun resetProgress() {
        audio.playClick()
        viewModelScope.launch {
            val fresh = saveRepo.resetAllKeepingSettings(_uiState.value.save)
            applySave(fresh)
            goToMenu()
            showToast("Progress Reset!")
        }
    }

    fun showToast(msg: String) {
        val id = ++toastSeq
        _uiState.update { it.copy(toastMessage = msg) }
        viewModelScope.launch {
            delay(2100)
            if (toastSeq == id) {
                _uiState.update { it.copy(toastMessage = null) }
            }
        }
    }

    // =========================================================================
    // LEVEL INITIALIZATION & BOARD LIFECYCLE
    // =========================================================================
    fun startLevel(levelId: Int) {
        val lvl = LevelRepository.getLevel(levelId)
        currentLevel = lvl
        movesLeft = lvl.moves
        score = 0
        combo = 0
        busy = false
        paused = false
        ended = false
        collected = HashMap()
        lvl.collectTargets.keys.forEach { collected[it] = 0 }

        synchronized(renderer.gridLock) {
            renderer.selectedCell = null
            for (r in 0..7) {
                for (c in 0..7) {
                    renderer.iceGrid[r][c] = lvl.layout.ice[r][c]
                    renderer.cageGrid[r][c] = lvl.layout.cage[r][c]
                    renderer.stoneGrid[r][c] = lvl.layout.stone[r][c]
                    renderer.boardGrid[r][c] = null
                }
            }

            for (r in 0..7) {
                for (c in 0..7) {
                    if (renderer.stoneGrid[r][c] > 0) continue
                    var type: FruitType
                    var guard = 0
                    do {
                        type = FruitType.fromId(Random.nextInt(lvl.fruitCount))
                        guard++
                    } while (
                        guard < 25 &&
                        ((c >= 2 && renderer.boardGrid[r][c - 1]?.type == type && renderer.boardGrid[r][c - 2]?.type == type) ||
                            (r >= 2 && renderer.boardGrid[r - 1][c]?.type == type && renderer.boardGrid[r - 2][c]?.type == type))
                    )
                    val wx = Retro3DRenderer.gridToWorldX(c)
                    val wy = Retro3DRenderer.gridToWorldY(r)
                    val startY = Retro3DRenderer.gridToWorldY(r - 4)
                    renderer.boardGrid[r][c] = FruitCell(
                        uid = uidSeq++,
                        type = type,
                        special = SpecialType.NONE,
                        curX = wx,
                        curY = startY,
                        targetX = wx,
                        targetY = wy
                    )
                }
            }
            if (!hasValidMoveLocked()) shuffleBoardLocked(silent = true)
        }

        renderer.screenMode = ScreenMode.GAME
        audio.playMusic(RetroAudioEngine.MusicTrack.GAME)

        _uiState.update {
            it.copy(
                screen = ScreenMode.GAME,
                activeModal = ActiveModal.NONE,
                selectedMapLevel = null,
                currentLevel = lvl,
                activeBooster = null,
                comboBanner = null,
                winResult = null
            )
        }
        syncHud()
    }

    fun selectBooster(type: BoosterType) {
        if (busy || paused || ended) return
        val count = _uiState.value.save.boosters[type] ?: 0
        if (count <= 0) return
        audio.playClick()
        _uiState.update {
            it.copy(activeBooster = if (it.activeBooster == type) null else type)
        }
    }

    fun onBoardTap(screenX: Float, screenY: Float) {
        if (busy || paused || ended) return
        val pos = renderer.raycastBoardCell(screenX, screenY) ?: return

        val booster = _uiState.value.activeBooster
        if (booster != null) {
            viewModelScope.launch { useBoosterAt(booster, pos) }
            return
        }

        val canTap = synchronized(renderer.gridLock) { canSwapCellLocked(pos.r, pos.c) }
        if (!canTap) return

        val prev = renderer.selectedCell
        if (prev != null && prev.isAdjacentTo(pos)) {
            viewModelScope.launch { trySwap(prev, pos) }
        } else {
            audio.playClick()
            renderer.selectedCell = pos
        }
    }

    fun onBoardSwipe(startScreenX: Float, startScreenY: Float, dx: Float, dy: Float) {
        if (busy || paused || ended) return
        if (_uiState.value.activeBooster != null) return
        val startCell = renderer.raycastBoardCell(startScreenX, startScreenY) ?: return
        val dr: Int
        val dc: Int
        if (kotlin.math.abs(dx) > kotlin.math.abs(dy)) {
            dr = 0; dc = if (dx > 0) 1 else -1
        } else {
            dr = if (dy > 0) 1 else -1; dc = 0
        }
        val target = CellPos(startCell.r + dr, startCell.c + dc)
        viewModelScope.launch { trySwap(startCell, target) }
    }

    // =========================================================================
    // MATCH-3 CORE ENGINE
    // =========================================================================
    private data class MatchCellInfo(
        val r: Int,
        val c: Int,
        val type: FruitType,
        var hasH: Boolean = false,
        var hasV: Boolean = false,
        var maxLen: Int = 0
    )

    private fun canSwapCellLocked(r: Int, c: Int): Boolean =
        r in 0..7 && c in 0..7 &&
            renderer.boardGrid[r][c] != null &&
            renderer.stoneGrid[r][c] == 0 &&
            renderer.cageGrid[r][c] == 0

    private fun findMatchComponentsLocked(): List<List<MatchCellInfo>> {
        val cellMap = LinkedHashMap<String, MatchCellInfo>()
        fun addCell(r: Int, c: Int, isH: Boolean, len: Int) {
            val key = "$r,$c"
            val cell = renderer.boardGrid[r][c] ?: return
            val info = cellMap.getOrPut(key) { MatchCellInfo(r, c, cell.type) }
            if (isH) info.hasH = true else info.hasV = true
            info.maxLen = max(info.maxLen, len)
        }

        for (r in 0..7) {
            var c = 0
            while (c < 8) {
                val cell = renderer.boardGrid[r][c]
                if (cell == null || cell.special == SpecialType.COLOR) {
                    c++; continue
                }
                var end = c + 1
                while (end < 8) {
                    val nb = renderer.boardGrid[r][end]
                    if (nb != null && nb.special != SpecialType.COLOR && nb.type == cell.type) end++ else break
                }
                if (end - c >= 3) {
                    for (cc in c until end) addCell(r, cc, true, end - c)
                }
                c = end
            }
        }

        for (c in 0..7) {
            var r = 0
            while (r < 8) {
                val cell = renderer.boardGrid[r][c]
                if (cell == null || cell.special == SpecialType.COLOR) {
                    r++; continue
                }
                var end = r + 1
                while (end < 8) {
                    val nb = renderer.boardGrid[end][c]
                    if (nb != null && nb.special != SpecialType.COLOR && nb.type == cell.type) end++ else break
                }
                if (end - r >= 3) {
                    for (rr in r until end) addCell(rr, c, false, end - r)
                }
                r = end
            }
        }

        val visited = HashSet<String>()
        val comps = ArrayList<List<MatchCellInfo>>()
        for ((key, item) in cellMap) {
            if (!visited.add(key)) continue
            val comp = ArrayList<MatchCellInfo>()
            val queue = ArrayDeque<MatchCellInfo>()
            queue.add(item)
            while (queue.isNotEmpty()) {
                val cur = queue.removeFirst()
                comp.add(cur)
                listOf(0 to 1, 0 to -1, 1 to 0, -1 to 0).forEach { (dr, dc) ->
                    val nk = "${cur.r + dr},${cur.c + dc}"
                    val nb = cellMap[nk]
                    if (nb != null && nb.type == cur.type && visited.add(nk)) {
                        queue.add(nb)
                    }
                }
            }
            comps.add(comp)
        }
        return comps
    }

    private fun hasValidMoveLocked(): Boolean {
        for (r in 0..7) {
            for (c in 0..7) {
                if (!canSwapCellLocked(r, c)) continue
                val cur = renderer.boardGrid[r][c] ?: continue
                for ((dr, dc) in listOf(0 to 1, 1 to 0)) {
                    val nr = r + dr; val nc = c + dc
                    if (!canSwapCellLocked(nr, nc)) continue
                    val nb = renderer.boardGrid[nr][nc] ?: continue
                    if (cur.special == SpecialType.COLOR || nb.special == SpecialType.COLOR) return true
                    if (cur.special != SpecialType.NONE && nb.special != SpecialType.NONE) return true
                    renderer.boardGrid[r][c] = nb; renderer.boardGrid[nr][nc] = cur
                    val ok = findMatchComponentsLocked().isNotEmpty()
                    renderer.boardGrid[r][c] = cur; renderer.boardGrid[nr][nc] = nb
                    if (ok) return true
                }
            }
        }
        return false
    }

    private fun shuffleBoardLocked(silent: Boolean) {
        if (!silent) showToast("No Moves — Reshuffling!")
        val coords = ArrayList<CellPos>()
        val cells = ArrayList<FruitCell>()
        for (r in 0..7) for (c in 0..7) {
            val cell = renderer.boardGrid[r][c]
            if (cell != null && renderer.cageGrid[r][c] == 0) {
                coords.add(CellPos(r, c))
                cells.add(cell)
            }
        }
        repeat(25) {
            cells.shuffle()
            coords.forEachIndexed { idx, pos -> renderer.boardGrid[pos.r][pos.c] = cells[idx] }
            if (findMatchComponentsLocked().isEmpty() && hasValidMoveLocked()) return@repeat
        }
        coords.forEach { pos ->
            val cell = renderer.boardGrid[pos.r][pos.c] ?: return@forEach
            val wx = Retro3DRenderer.gridToWorldX(pos.c)
            val wy = Retro3DRenderer.gridToWorldY(pos.r)
            cell.targetX = wx; cell.targetY = wy
            cell.curX = wx; cell.curY = wy
        }
    }

    private suspend fun animateSwap(a: CellPos, b: CellPos) {
        val (cellA, cellB) = synchronized(renderer.gridLock) {
            renderer.boardGrid[a.r][a.c] to renderer.boardGrid[b.r][b.c]
        }
        val ax = Retro3DRenderer.gridToWorldX(a.c); val ay = Retro3DRenderer.gridToWorldY(a.r)
        val bx = Retro3DRenderer.gridToWorldX(b.c); val by = Retro3DRenderer.gridToWorldY(b.r)
        audio.playSwap()

        val steps = 9
        for (i in 1..steps) {
            val t = i.toFloat() / steps
            val ease = if (t < 0.5f) 2f * t * t else -1f + (4f - 2f * t) * t
            synchronized(renderer.gridLock) {
                cellA?.let {
                    it.curX = ax + (bx - ax) * ease
                    it.curY = ay + (by - ay) * ease
                    it.targetX = it.curX; it.targetY = it.curY
                    it.curZ = sin(t * PI.toFloat()) * 0.45f
                }
                cellB?.let {
                    it.curX = bx + (ax - bx) * ease
                    it.curY = by + (ay - by) * ease
                    it.targetX = it.curX; it.targetY = it.curY
                    it.curZ = -sin(t * PI.toFloat()) * 0.28f
                }
            }
            delay(16)
        }

        synchronized(renderer.gridLock) {
            renderer.boardGrid[a.r][a.c] = cellB
            renderer.boardGrid[b.r][b.c] = cellA
            cellB?.let { it.curX = ax; it.curY = ay; it.targetX = ax; it.targetY = ay; it.curZ = 0f }
            cellA?.let { it.curX = bx; it.curY = by; it.targetX = bx; it.targetY = by; it.curZ = 0f }
        }
    }

    private fun addScore(pts: Int) {
        score += pts * max(1, combo)
    }

    private fun damageObstacleAtLocked(r: Int, c: Int, direct: Boolean) {
        if (r !in 0..7 || c !in 0..7) return
        val wx = Retro3DRenderer.gridToWorldX(c)
        val wy = Retro3DRenderer.gridToWorldY(r)
        if (direct && renderer.cageGrid[r][c] > 0) {
            renderer.cageGrid[r][c] = 0
            renderer.spawnExplosion(wx, wy, 0.1f, 0xFFFF2A85.toInt(), 9, false)
            addScore(60)
        }
        if (direct && renderer.iceGrid[r][c] > 0) {
            renderer.iceGrid[r][c]--
            renderer.spawnExplosion(wx, wy, 0.05f, 0xFF70F3FF.toInt(), 10, false)
            addScore(80)
        }
        if (renderer.stoneGrid[r][c] > 0) {
            renderer.stoneGrid[r][c]--
            renderer.spawnExplosion(wx, wy, 0.1f, 0xFFB8A9FF.toInt(), 12, false)
            addScore(100)
        }
    }

    private data class BlastTarget(val r: Int, val c: Int, val force: Boolean)

    private fun collectBlastQueueLocked(initial: List<BlastTarget>): List<CellPos> {
        val toClear = LinkedHashMap<String, CellPos>()
        val specialTriggered = HashSet<String>()
        val queue = ArrayDeque<BlastTarget>()
        queue.addAll(initial)
        val lvl = currentLevel ?: return emptyList()

        while (queue.isNotEmpty()) {
            val t = queue.removeFirst()
            if (t.r !in 0..7 || t.c !in 0..7) continue
            val key = "${t.r},${t.c}"

            if (renderer.stoneGrid[t.r][t.c] > 0) {
                if (t.force) damageObstacleAtLocked(t.r, t.c, true)
                continue
            }

            val cell = renderer.boardGrid[t.r][t.c] ?: continue
            toClear.putIfAbsent(key, CellPos(t.r, t.c))

            if (cell.special != SpecialType.NONE && specialTriggered.add(key)) {
                val wx = Retro3DRenderer.gridToWorldX(t.c)
                val wy = Retro3DRenderer.gridToWorldY(t.r)
                when (cell.special) {
                    SpecialType.ROW -> {
                        audio.playLaser()
                        renderer.spawnLineBeam(wx, wy, horizontal = true)
                        renderer.triggerShake(0.22f, 0.22f)
                        for (cc in 0..7) queue.add(BlastTarget(t.r, cc, true))
                    }
                    SpecialType.COL -> {
                        audio.playLaser()
                        renderer.spawnLineBeam(wx, wy, horizontal = false)
                        renderer.triggerShake(0.22f, 0.22f)
                        for (rr in 0..7) queue.add(BlastTarget(rr, t.c, true))
                    }
                    SpecialType.BOMB -> {
                        audio.playExplode()
                        renderer.spawnExplosion(wx, wy, 0.1f, 0xFFFFD500.toInt(), 22, true)
                        renderer.triggerShake(0.36f, 0.34f)
                        for (dr in -1..1) for (dc in -1..1) queue.add(BlastTarget(t.r + dr, t.c + dc, true))
                    }
                    SpecialType.COLOR -> {
                        audio.playColorBomb()
                        val targetType = FruitType.fromId(Random.nextInt(lvl.fruitCount))
                        for (rr in 0..7) for (cc in 0..7) {
                            if (renderer.boardGrid[rr][cc]?.type == targetType) queue.add(BlastTarget(rr, cc, true))
                        }
                    }
                    SpecialType.NONE -> Unit
                }
            }
        }
        return toClear.values.toList()
    }

    private fun destroyCellsLocked(cells: List<CellPos>) {
        val damagedAdj = HashSet<String>()
        for (pos in cells) {
            val cell = renderer.boardGrid[pos.r][pos.c] ?: continue
            if (collected.containsKey(cell.type)) {
                collected[cell.type] = (collected[cell.type] ?: 0) + 1
            }
            val wx = Retro3DRenderer.gridToWorldX(pos.c)
            val wy = Retro3DRenderer.gridToWorldY(pos.r)
            renderer.spawnExplosion(wx, wy, 0.1f, cell.type.colorInt, 12, cell.special != SpecialType.NONE)
            renderer.boardGrid[pos.r][pos.c] = null

            addScore(if (cell.special != SpecialType.NONE) 120 else 35)
            damageObstacleAtLocked(pos.r, pos.c, true)

            listOf(0 to 1, 0 to -1, 1 to 0, -1 to 0).forEach { (dr, dc) ->
                val nr = pos.r + dr; val nc = pos.c + dc
                val k = "$nr,$nc"
                if (nr in 0..7 && nc in 0..7 && renderer.stoneGrid[nr][nc] > 0 && damagedAdj.add(k)) {
                    damageObstacleAtLocked(nr, nc, false)
                }
            }
        }
    }

    private suspend fun applyGravityAndRefill() {
        val lvl = currentLevel ?: return
        synchronized(renderer.gridLock) {
            var changed = true
            while (changed) {
                changed = false
                // 1. Vertical drop
                for (c in 0..7) {
                    for (r in 7 downTo 0) {
                        if (renderer.boardGrid[r][c] != null || renderer.stoneGrid[r][c] > 0) continue
                        var srcR = r - 1
                        while (srcR >= 0) {
                            if (renderer.stoneGrid[srcR][c] > 0 || renderer.cageGrid[srcR][c] > 0) break
                            if (renderer.boardGrid[srcR][c] != null) break
                            srcR--
                        }
                        if (srcR >= 0 && renderer.boardGrid[srcR][c] != null &&
                            renderer.stoneGrid[srcR][c] == 0 && renderer.cageGrid[srcR][c] == 0
                        ) {
                            val moved = renderer.boardGrid[srcR][c]!!
                            renderer.boardGrid[r][c] = moved
                            renderer.boardGrid[srcR][c] = null
                            moved.targetX = Retro3DRenderer.gridToWorldX(c)
                            moved.targetY = Retro3DRenderer.gridToWorldY(r)
                            changed = true
                        }
                    }
                }
                // 2. Spawn new fruits above top open cells
                for (c in 0..7) {
                    for (r in 0..7) {
                        if (renderer.stoneGrid[r][c] > 0 || renderer.cageGrid[r][c] > 0) break
                        if (renderer.boardGrid[r][c] == null) {
                            val wx = Retro3DRenderer.gridToWorldX(c)
                            val wy = Retro3DRenderer.gridToWorldY(r)
                            val startY = Retro3DRenderer.gridToWorldY(-2 - (7 - r) / 2)
                            renderer.boardGrid[r][c] = FruitCell(
                                uid = uidSeq++,
                                type = FruitType.fromId(Random.nextInt(lvl.fruitCount)),
                                special = SpecialType.NONE,
                                curX = wx, curY = startY,
                                targetX = wx, targetY = wy
                            )
                            changed = true
                        }
                    }
                }
                // 3. Diagonal slide around stones/cages
                for (r in 7 downTo 1) {
                    for (c in 0..7) {
                        if (renderer.boardGrid[r][c] != null || renderer.stoneGrid[r][c] > 0) continue
                        for (dc in listOf(-1, 1)) {
                            val nc = c + dc
                            if (nc in 0..7 && renderer.boardGrid[r - 1][nc] != null &&
                                renderer.stoneGrid[r - 1][nc] == 0 && renderer.cageGrid[r - 1][nc] == 0
                            ) {
                                val moved = renderer.boardGrid[r - 1][nc]!!
                                renderer.boardGrid[r][c] = moved
                                renderer.boardGrid[r - 1][nc] = null
                                moved.targetX = Retro3DRenderer.gridToWorldX(c)
                                moved.targetY = Retro3DRenderer.gridToWorldY(r)
                                changed = true
                                break
                            }
                        }
                    }
                }
            }
        }
        delay(230)
    }

    private fun triggerComboBanner(comboMult: Int) {
        if (comboMult < 2) return
        val titles = listOf("COMBO!", "AMAZING!", "INCREDIBLE!", "SUPER MATCH!", "ULTRA RETRO!")
        val title = titles[min(comboMult - 2, titles.lastIndex)]
        audio.playComboBig()
        val id = System.nanoTime()
        _uiState.update {
            it.copy(comboBanner = ComboBannerState(id = id, title = title, subtitle = "x$comboMult SCORE MULTIPLIER"))
        }
        viewModelScope.launch {
            delay(1150)
            if (_uiState.value.comboBanner?.id == id) {
                _uiState.update { it.copy(comboBanner = null) }
            }
        }
    }

    private suspend fun resolveBoard(swappedPair: Pair<CellPos, CellPos>? = null) {
        var swapPair = swappedPair
        combo = 0

        while (true) {
            val comps = synchronized(renderer.gridLock) { findMatchComponentsLocked() }
            if (comps.isEmpty()) break

            combo++
            audio.playMatch(combo)
            if (combo >= 2) {
                triggerComboBanner(combo)
                renderer.triggerShake(0.18f + combo * 0.04f, 0.22f)
            }

            synchronized(renderer.gridLock) {
                val blastInputs = ArrayList<BlastTarget>()
                data class SpecialSpawn(val r: Int, val c: Int, val type: FruitType, val special: SpecialType)
                val spawns = ArrayList<SpecialSpawn>()

                comps.forEach { comp ->
                    val hasBoth = comp.any { it.hasH } && comp.any { it.hasV }
                    val maxL = comp.maxOf { it.maxLen }
                    val spType = when {
                        maxL >= 5 -> SpecialType.COLOR
                        hasBoth -> SpecialType.BOMB
                        maxL == 4 -> {
                            val isH = comp.any { it.hasH && it.maxLen == 4 }
                            if (isH) SpecialType.COL else SpecialType.ROW
                        }
                        else -> SpecialType.NONE
                    }

                    var spawnTarget: MatchCellInfo? = null
                    if (spType != SpecialType.NONE) {
                        if (swapPair != null) {
                            spawnTarget = comp.find {
                                (it.r == swapPair!!.first.r && it.c == swapPair!!.first.c) ||
                                    (it.r == swapPair!!.second.r && it.c == swapPair!!.second.c)
                            }
                        }
                        if (spawnTarget == null) spawnTarget = comp[comp.size / 2]
                        spawns.add(SpecialSpawn(spawnTarget.r, spawnTarget.c, comp[0].type, spType))
                    }

                    comp.forEach { item ->
                        if (spawnTarget == null || item.r != spawnTarget.r || item.c != spawnTarget.c) {
                            blastInputs.add(BlastTarget(item.r, item.c, false))
                        }
                    }
                }

                val toDestroy = collectBlastQueueLocked(blastInputs)
                destroyCellsLocked(toDestroy)

                spawns.forEach { sp ->
                    val wx = Retro3DRenderer.gridToWorldX(sp.c)
                    val wy = Retro3DRenderer.gridToWorldY(sp.r)
                    renderer.boardGrid[sp.r][sp.c] = FruitCell(
                        uid = uidSeq++,
                        type = sp.type,
                        special = sp.special,
                        curX = wx, curY = wy,
                        targetX = wx, targetY = wy
                    )
                    renderer.spawnExplosion(wx, wy, 0.1f, 0xFFFFD500.toInt(), 12, false)
                }
            }

            swapPair = null
            syncHud()
            delay(160)
            applyGravityAndRefill()
            delay(65)
        }

        combo = 0
        syncHud()

        if (!isObjectiveMet()) {
            synchronized(renderer.gridLock) {
                if (!hasValidMoveLocked()) shuffleBoardLocked(silent = false)
            }
        }
        checkEndState()
    }

    private suspend fun trySwap(a: CellPos, b: CellPos) {
        if (busy || paused || ended) return
        val valid = synchronized(renderer.gridLock) {
            a.isAdjacentTo(b) && canSwapCellLocked(a.r, a.c) && canSwapCellLocked(b.r, b.c)
        }
        if (!valid) return

        busy = true
        renderer.selectedCell = null
        animateSwap(a, b)

        val (ca, cb) = synchronized(renderer.gridLock) {
            renderer.boardGrid[a.r][a.c] to renderer.boardGrid[b.r][b.c]
        }

        val isSpecialCombo = ca != null && cb != null &&
            (ca.special == SpecialType.COLOR || cb.special == SpecialType.COLOR ||
                (ca.special != SpecialType.NONE && cb.special != SpecialType.NONE))

        if (isSpecialCombo) {
            movesLeft--
            syncHud()
            handleSpecialComboSwap(a, b)
            busy = false
            return
        }

        val hasMatch = synchronized(renderer.gridLock) { findMatchComponentsLocked().isNotEmpty() }
        if (!hasMatch) {
            audio.playInvalid()
            animateSwap(a, b)
            busy = false
            return
        }

        movesLeft--
        syncHud()
        resolveBoard(a to b)
        busy = false
    }

    private suspend fun handleSpecialComboSwap(a: CellPos, b: CellPos) {
        combo = 2
        synchronized(renderer.gridLock) {
            val ca = renderer.boardGrid[a.r][a.c] ?: return@synchronized
            val cb = renderer.boardGrid[b.r][b.c] ?: return@synchronized
            val targets = ArrayList<BlastTarget>()
            val bx = Retro3DRenderer.gridToWorldX(b.c)
            val by = Retro3DRenderer.gridToWorldY(b.r)

            when {
                ca.special == SpecialType.COLOR && cb.special == SpecialType.COLOR -> {
                    audio.playColorBomb(); audio.playExplode()
                    renderer.triggerShake(0.55f, 0.50f)
                    triggerComboBanner(5)
                    for (r in 0..7) for (c in 0..7) targets.add(BlastTarget(r, c, true))
                }
                ca.special == SpecialType.COLOR || cb.special == SpecialType.COLOR -> {
                    val cPos = if (ca.special == SpecialType.COLOR) a else b
                    val other = if (ca.special == SpecialType.COLOR) cb else ca
                    audio.playColorBomb()
                    renderer.triggerShake(0.42f, 0.38f)
                    triggerComboBanner(4)
                    targets.add(BlastTarget(cPos.r, cPos.c, true))
                    for (r in 0..7) for (c in 0..7) {
                        val cell = renderer.boardGrid[r][c]
                        if (cell != null && cell.type == other.type) {
                            if (other.special != SpecialType.NONE && other.special != SpecialType.COLOR) {
                                cell.special = other.special
                            }
                            targets.add(BlastTarget(r, c, true))
                        }
                    }
                }
                ca.special == SpecialType.BOMB && cb.special == SpecialType.BOMB -> {
                    audio.playExplode()
                    renderer.triggerShake(0.52f, 0.44f)
                    triggerComboBanner(4)
                    renderer.spawnExplosion(bx, by, 0.1f, 0xFFFFD500.toInt(), 32, true)
                    for (dr in -2..2) for (dc in -2..2) targets.add(BlastTarget(b.r + dr, b.c + dc, true))
                }
                (ca.special == SpecialType.BOMB && (cb.special == SpecialType.ROW || cb.special == SpecialType.COL)) ||
                    (cb.special == SpecialType.BOMB && (ca.special == SpecialType.ROW || ca.special == SpecialType.COL)) -> {
                    audio.playLaser(); audio.playExplode()
                    renderer.triggerShake(0.48f, 0.42f)
                    triggerComboBanner(4)
                    for (d in -1..1) {
                        for (i in 0..7) {
                            targets.add(BlastTarget(b.r + d, i, true))
                            targets.add(BlastTarget(i, b.c + d, true))
                        }
                        if (b.r + d in 0..7) renderer.spawnLineBeam(bx, Retro3DRenderer.gridToWorldY(b.r + d), true, 0xFFFFD500.toInt())
                        if (b.c + d in 0..7) renderer.spawnLineBeam(Retro3DRenderer.gridToWorldX(b.c + d), by, false, 0xFFFFD500.toInt())
                    }
                }
                else -> {
                    audio.playLaser()
                    renderer.triggerShake(0.32f, 0.32f)
                    triggerComboBanner(3)
                    renderer.spawnLineBeam(bx, by, true)
                    renderer.spawnLineBeam(bx, by, false)
                    for (i in 0..7) {
                        targets.add(BlastTarget(b.r, i, true))
                        targets.add(BlastTarget(i, b.c, true))
                    }
                }
            }
            val blast = collectBlastQueueLocked(targets)
            destroyCellsLocked(blast)
        }
        syncHud()
        delay(210)
        applyGravityAndRefill()
        resolveBoard()
    }

    private suspend fun useBoosterAt(booster: BoosterType, pos: CellPos) {
        val curSave = _uiState.value.save
        val count = curSave.boosters[booster] ?: 0
        if (count <= 0 || busy) return

        val updatedBoosters = curSave.boosters.toMutableMap().apply { put(booster, count - 1) }
        persistSave(curSave.copy(boosters = updatedBoosters))
        _uiState.update { it.copy(activeBooster = null) }

        busy = true
        combo = 2
        val wx = Retro3DRenderer.gridToWorldX(pos.c)
        val wy = Retro3DRenderer.gridToWorldY(pos.r)

        synchronized(renderer.gridLock) {
            val targets = ArrayList<BlastTarget>()
            when (booster) {
                BoosterType.HAMMER -> {
                    audio.playExplode()
                    renderer.triggerShake(0.28f, 0.25f)
                    if (renderer.stoneGrid[pos.r][pos.c] > 0) damageObstacleAtLocked(pos.r, pos.c, true)
                    else targets.add(BlastTarget(pos.r, pos.c, true))
                }
                BoosterType.BOMB -> {
                    audio.playExplode()
                    renderer.triggerShake(0.44f, 0.35f)
                    renderer.spawnExplosion(wx, wy, 0.1f, 0xFFFFD500.toInt(), 26, true)
                    for (dr in -1..1) for (dc in -1..1) targets.add(BlastTarget(pos.r + dr, pos.c + dc, true))
                }
                BoosterType.LASER -> {
                    audio.playLaser()
                    renderer.triggerShake(0.34f, 0.30f)
                    renderer.spawnLineBeam(wx, wy, true)
                    renderer.spawnLineBeam(wx, wy, false)
                    for (i in 0..7) {
                        targets.add(BlastTarget(pos.r, i, true))
                        targets.add(BlastTarget(i, pos.c, true))
                    }
                }
                BoosterType.PAINT -> {
                    val tapped = renderer.boardGrid[pos.r][pos.c]
                    if (tapped != null) {
                        audio.playColorBomb()
                        renderer.triggerShake(0.35f, 0.30f)
                        for (rr in 0..7) for (cc in 0..7) {
                            if (renderer.boardGrid[rr][cc]?.type == tapped.type) targets.add(BlastTarget(rr, cc, true))
                        }
                    }
                }
            }
            if (targets.isNotEmpty()) destroyCellsLocked(collectBlastQueueLocked(targets))
        }

        syncHud()
        delay(200)
        applyGravityAndRefill()
        resolveBoard()
        busy = false
    }

    private fun countIceLeft(): Int {
        var cnt = 0
        synchronized(renderer.gridLock) {
            for (r in 0..7) for (c in 0..7) if (renderer.iceGrid[r][c] > 0) cnt++
        }
        return cnt
    }

    private fun isObjectiveMet(): Boolean {
        val lvl = currentLevel ?: return false
        return when (lvl.objType) {
            ObjectiveType.SCORE -> score >= lvl.targetScore
            ObjectiveType.ICE -> countIceLeft() == 0
            ObjectiveType.COLLECT -> lvl.collectTargets.all { (f, q) -> (collected[f] ?: 0) >= q }
            ObjectiveType.MIXED -> countIceLeft() == 0 && lvl.collectTargets.all { (f, q) -> (collected[f] ?: 0) >= q }
        }
    }

    private suspend fun checkEndState() {
        if (ended) return
        val lvl = currentLevel ?: return

        if (isObjectiveMet()) {
            ended = true
            if (movesLeft > 0) {
                triggerComboBanner(3)
                score += movesLeft * 150
                movesLeft = 0
                syncHud()
                repeat(4) {
                    val rr = Random.nextInt(8); val cc = Random.nextInt(8)
                    renderer.spawnExplosion(
                        Retro3DRenderer.gridToWorldX(cc),
                        Retro3DRenderer.gridToWorldY(rr),
                        0.15f,
                        0xFFFFD500.toInt(),
                        16,
                        true
                    )
                    delay(100)
                }
            }

            var stars = 1
            if (score >= lvl.starScores.second) stars = 2
            if (score >= lvl.starScores.third) stars = 3

            val cur = _uiState.value.save
            val newStars = cur.stars.toMutableMap().apply { put(lvl.id, max(this[lvl.id] ?: 0, stars)) }
            val newHighs = cur.highScores.toMutableMap().apply { put(lvl.id, max(this[lvl.id] ?: 0, score)) }
            val nextUnlocked = if (lvl.id >= cur.unlockedLevel && lvl.id < 100) lvl.id + 1 else cur.unlockedLevel

            val rewardBooster = BoosterType.entries[lvl.id % BoosterType.entries.size]
            val rewardQty = if (lvl.isBoss) 2 else 1
            val newBoosters = cur.boosters.toMutableMap().apply {
                put(rewardBooster, (this[rewardBooster] ?: 0) + rewardQty)
            }

            val updatedTopScores = updateLeaderboard(cur.topScores, score, lvl.id)
            val updatedSave = cur.copy(
                unlockedLevel = nextUnlocked,
                stars = newStars,
                highScores = newHighs,
                boosters = newBoosters,
                topScores = updatedTopScores
            )
            persistSave(updatedSave)

            if (lvl.id == 100) {
                audio.playGrandVictory()
                _uiState.update { it.copy(activeModal = ActiveModal.GRAND_VICTORY) }
            } else {
                audio.playLevelWin()
                _uiState.update {
                    it.copy(
                        activeModal = ActiveModal.WIN,
                        winResult = WinResult(
                            levelId = lvl.id,
                            stars = stars,
                            score = score,
                            bonusMessage = "+$rewardQty ${rewardBooster.label} Booster Earned!"
                        )
                    )
                }
            }
        } else if (movesLeft <= 0) {
            ended = true
            audio.playLevelFail()
            if (score > 0) {
                val cur = _uiState.value.save
                val updatedTopScores = updateLeaderboard(cur.topScores, score, lvl.id)
                if (updatedTopScores != cur.topScores) {
                    persistSave(cur.copy(topScores = updatedTopScores))
                }
            }
            _uiState.update {
                it.copy(
                    activeModal = ActiveModal.LOSE,
                    loseScore = score
                )
            }
        }
    }

    companion object {
        fun updateLeaderboard(
            current: List<LeaderboardEntry>,
            score: Int,
            levelId: Int,
            timestamp: Long = System.currentTimeMillis()
        ): List<LeaderboardEntry> {
            if (score <= 0) return current.take(5)
            return (current + LeaderboardEntry(score = score, levelId = levelId, timestamp = timestamp))
                .sortedWith(compareByDescending<LeaderboardEntry> { it.score }.thenByDescending { it.timestamp })
                .take(5)
        }
    }

    private fun syncHud() {
        _uiState.update {
            it.copy(
                movesLeft = movesLeft,
                score = score,
                collected = HashMap(collected),
                iceLeft = countIceLeft(),
                comboMultiplier = max(1, combo)
            )
        }
    }
}
