package com.example.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveModal
import com.example.model.GameUiState
import com.example.ui.theme.FredokaFontFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

@Composable
fun ModalRouter(
    state: GameUiState,
    onResume: () -> Unit,
    onRestartLevel: (Int) -> Unit,
    onOpenSettingsFromPause: () -> Unit,
    onCloseSettings: () -> Unit,
    onCloseModal: () -> Unit,
    onGoToMap: () -> Unit,
    onGoToMenu: () -> Unit,
    onNextLevel: (Int) -> Unit,
    onMusicVol: (Float) -> Unit,
    onSfxVol: (Float) -> Unit,
    onToggleMusicMute: () -> Unit,
    onToggleSfxMute: () -> Unit,
    onResetProgress: () -> Unit,
    onClaimDailyBonus: () -> Unit
) {
    when (state.activeModal) {
        ActiveModal.NONE -> Unit

        ActiveModal.PAUSE -> {
            val lvl = state.currentLevel
            ArcadeModal(title = "GAME PAUSED", onDismiss = onResume) {
                if (lvl != null) {
                    Text(
                        text = "Level ${lvl.id}: ${lvl.title}",
                        fontFamily = FredokaFontFamily,
                        color = Color(0xFFB8EAFF),
                        fontSize = 16.sp
                    )
                }
                ArcadeButton(
                    text = "\u25B6  RESUME",
                    onClick = onResume,
                    style = ArcadeButtonStyle.GREEN,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "pause_resume_button"
                )
                if (lvl != null) {
                    ArcadeButton(
                        text = "\u21BB  RESTART LEVEL",
                        onClick = { onRestartLevel(lvl.id) },
                        style = ArcadeButtonStyle.GOLD,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "pause_restart_button"
                    )
                }
                ArcadeButton(
                    text = "\u2699  SETTINGS",
                    onClick = onOpenSettingsFromPause,
                    style = ArcadeButtonStyle.PURPLE,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "pause_settings_button"
                )
                ArcadeButton(
                    text = "\uD83D\uDDFA  LEVEL MAP",
                    onClick = onGoToMap,
                    style = ArcadeButtonStyle.PINK,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "pause_map_button"
                )
            }
        }

        ActiveModal.SETTINGS -> {
            var confirmReset by remember { mutableStateOf(false) }
            val s = state.save
            ArcadeModal(title = "AUDIO & SETTINGS", onDismiss = onCloseSettings) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "\uD83C\uDFB5 Music Volume",
                            fontFamily = FredokaFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        ArcadeButton(
                            text = if (s.musicMuted) "MUTED" else "ON",
                            onClick = onToggleMusicMute,
                            style = ArcadeButtonStyle.CYAN,
                            minHeight = 48.dp,
                            fontSize = 13.sp,
                            testTag = "mute_music_button"
                        )
                    }
                    Slider(
                        value = s.musicVol,
                        onValueChange = onMusicVol,
                        colors = SliderDefaults.colors(thumbColor = NeonPink, activeTrackColor = NeonPink)
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "\uD83D\uDCA5 SFX Volume",
                            fontFamily = FredokaFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        ArcadeButton(
                            text = if (s.sfxMuted) "MUTED" else "ON",
                            onClick = onToggleSfxMute,
                            style = ArcadeButtonStyle.CYAN,
                            minHeight = 48.dp,
                            fontSize = 13.sp,
                            testTag = "mute_sfx_button"
                        )
                    }
                    Slider(
                        value = s.sfxVol,
                        onValueChange = onSfxVol,
                        colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                    )
                }

                if (!confirmReset) {
                    ArcadeButton(
                        text = "\uD83D\uDDD1  RESET PROGRESS",
                        onClick = { confirmReset = true },
                        style = ArcadeButtonStyle.DANGER,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "reset_progress_button"
                    )
                } else {
                    ArcadeButton(
                        text = "\u26A0 CONFIRM RESET ALL 100 LEVELS",
                        onClick = {
                            confirmReset = false
                            onResetProgress()
                        },
                        style = ArcadeButtonStyle.DANGER,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "confirm_reset_button"
                    )
                }

                ArcadeButton(
                    text = "\u2713  DONE",
                    onClick = onCloseSettings,
                    style = ArcadeButtonStyle.CYAN,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "settings_done_button"
                )
            }
        }

        ActiveModal.TUTORIAL -> {
            ArcadeModal(title = "HOW TO PLAY", onDismiss = onCloseModal) {
                val items = listOf(
                    "\uD83C\uDF53 Swap & Match 3+: Swipe any 3D fruit onto an adjacent fruit (or tap two neighbors) to match 3 or more!",
                    "\u26A1 Match 4 in a Line: Creates a glowing Line Blaster that clears an entire row or column!",
                    "\uD83D\uDCA3 Match in L or T Shape: Creates a pulsing Fruit Bomb that blasts a 3x3 area!",
                    "\uD83C\uDF08 Match 5 in a Line: Creates a Hyper Color Prism! Swap it with any fruit to vaporize every fruit of that color!",
                    "\uD83D\uDD25 Super Combos: Swap ANY two special fruits together for massive chain explosions & multipliers (x2, x3, x4, x5+)!",
                    "\uD83E\uDDCA Obstacles & 100 Levels: Shatter Ice blocks, free Laser-Caged fruits, and crush Stone crates across 100 sequentially unlocked levels!"
                )
                items.forEach { tip ->
                    Text(
                        text = tip,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                            .border(1.dp, NeonPink.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                            .padding(10.dp),
                        fontFamily = FredokaFontFamily,
                        fontSize = 14.sp,
                        color = Color.White,
                        lineHeight = 19.sp
                    )
                }
                ArcadeButton(
                    text = "GOT IT!",
                    onClick = onCloseModal,
                    style = ArcadeButtonStyle.GOLD,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "tutorial_close_button"
                )
            }
        }

        ActiveModal.WIN -> {
            val res = state.winResult
            var shownStars by remember(res?.levelId) { mutableIntStateOf(0) }
            LaunchedEffect(res) {
                shownStars = 0
                val target = res?.stars ?: 0
                for (i in 1..target) {
                    delay(200)
                    shownStars = i
                }
            }

            ArcadeModal(title = "LEVEL CLEARED!") {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 1..3) {
                        val earned = i <= shownStars
                        val s by animateFloatAsState(
                            targetValue = if (earned) 1.2f else 0.85f,
                            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                            label = "star$i"
                        )
                        Text(
                            text = "\u2B50",
                            fontSize = 38.sp,
                            modifier = Modifier
                                .scale(s)
                                .alpha(if (earned) 1f else 0.25f)
                        )
                    }
                }
                Text(
                    text = "Score: ${"%,d".format(res?.score ?: 0)} pts",
                    fontFamily = FredokaFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = NeonCyan
                )
                Text(
                    text = res?.bonusMessage ?: "",
                    fontFamily = FredokaFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = NeonGold
                )
                val nextId = minOf(100, (res?.levelId ?: 1) + 1)
                ArcadeButton(
                    text = "\u25B6  NEXT LEVEL",
                    onClick = { onNextLevel(nextId) },
                    style = ArcadeButtonStyle.GREEN,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "win_next_button"
                )
                ArcadeButton(
                    text = "\u21BB  REPLAY",
                    onClick = { onRestartLevel(res?.levelId ?: 1) },
                    style = ArcadeButtonStyle.GOLD,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "win_replay_button"
                )
                ArcadeButton(
                    text = "\uD83D\uDDFA  LEVEL MAP",
                    onClick = onGoToMap,
                    style = ArcadeButtonStyle.PURPLE,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "win_map_button"
                )
            }
        }

        ActiveModal.LOSE -> {
            val lvlId = state.currentLevel?.id ?: 1
            ArcadeModal(title = "OUT OF MOVES!", titleColor = Color(0xFFFF4F7B)) {
                Text(text = "\uD83D\uDC94", fontSize = 46.sp)
                Text(
                    text = "Score: ${"%,d".format(state.loseScore)} pts \u2014 Keep matching specials!",
                    fontFamily = FredokaFontFamily,
                    fontSize = 16.sp,
                    color = Color(0xFFD6C7FF),
                    textAlign = TextAlign.Center
                )
                ArcadeButton(
                    text = "\u21BB  TRY AGAIN",
                    onClick = { onRestartLevel(lvlId) },
                    style = ArcadeButtonStyle.GOLD,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "lose_retry_button"
                )
                ArcadeButton(
                    text = "\uD83D\uDDFA  LEVEL MAP",
                    onClick = onGoToMap,
                    style = ArcadeButtonStyle.PURPLE,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "lose_map_button"
                )
            }
        }

        ActiveModal.GRAND_VICTORY -> {
            ArcadeModal(title = "ARCADE CHAMPION!", borderColor = NeonGold) {
                Text(text = "\uD83C\uDFC6\uD83D\uDC51\uD83C\uDF53", fontSize = 48.sp)
                Text(
                    text = "INCREDIBLE! You conquered all 100 LEVELS of CANDY CRUSH RETRO!",
                    fontFamily = FredokaFontFamily,
                    fontSize = 17.sp,
                    color = Color(0xFFFFF7C2),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Total Stars: ${state.save.totalStars} / 300",
                    fontFamily = FredokaFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 19.sp,
                    color = NeonCyan
                )
                ArcadeButton(
                    text = "\uD83D\uDDFA  REPLAY ANY LEVEL",
                    onClick = onGoToMap,
                    style = ArcadeButtonStyle.GOLD,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "victory_map_button"
                )
                ArcadeButton(
                    text = "\uD83C\uDFE0  MAIN MENU",
                    onClick = onGoToMenu,
                    style = ArcadeButtonStyle.CYAN,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "victory_menu_button"
                )
            }
        }

        ActiveModal.DAILY_BONUS -> {
            val bonus = state.dailyBonus
            val claimedToday = !bonus.canClaim
            ArcadeModal(
                title = "DAILY ARCADE BONUS",
                borderColor = if (bonus.canClaim) NeonGold else NeonCyan,
                onDismiss = onCloseModal
            ) {
                Text(
                    text = if (bonus.canClaim) {
                        "Welcome back! New day detected — claim your random Day ${bonus.activeDay} boosters!"
                    } else if (state.dailyBonusJustClaimed) {
                        "\uD83C\uDF89 Day ${bonus.activeDay} Random Boosters Added!"
                    } else {
                        "Today's bonus already claimed (${bonus.lastClaimedDate}). Come back tomorrow!"
                    },
                    fontFamily = FredokaFontFamily,
                    fontSize = 15.sp,
                    color = if (bonus.canClaim) Color(0xFFFFF3B0) else NeonCyan,
                    textAlign = TextAlign.Center
                )

                // Today's Random Booster Rewards Showcase
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (bonus.canClaim) NeonGold.copy(alpha = 0.16f) else NeonGreen.copy(alpha = 0.12f),
                            RoundedCornerShape(16.dp)
                        )
                        .border(
                            2.dp,
                            if (bonus.canClaim) NeonGold else NeonGreen,
                            RoundedCornerShape(16.dp)
                        )
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    bonus.todayRewards.forEach { (booster, qty) ->
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color(0x55000000), RoundedCornerShape(12.dp))
                                .padding(vertical = 8.dp, horizontal = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(text = booster.icon, fontSize = 26.sp)
                            Text(
                                text = "+$qty ${booster.label}",
                                fontFamily = FredokaFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // 7-Day Login Streak Progress Pills
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (dayIdx in 1..7) {
                        val isCurrent = dayIdx == bonus.activeDay
                        val isDone = dayIdx < bonus.activeDay || (isCurrent && claimedToday)
                        val borderCol = when {
                            isCurrent && bonus.canClaim -> NeonGold
                            isDone -> NeonGreen
                            else -> Color.White.copy(alpha = 0.22f)
                        }
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (isCurrent && bonus.canClaim) NeonGold.copy(alpha = 0.22f)
                                    else Color.White.copy(alpha = 0.06f),
                                    RoundedCornerShape(10.dp)
                                )
                                .border(1.5.dp, borderCol, RoundedCornerShape(10.dp))
                                .padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (dayIdx == 7) "\uD83D\uDC517" else "D$dayIdx",
                                fontFamily = FredokaFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isDone) NeonGreen else NeonGold
                            )
                            Text(
                                text = if (isDone) "\u2713" else if (isCurrent) "\uD83C\uDF81" else "\u2022",
                                fontSize = 12.sp,
                                color = if (isDone) NeonGreen else Color.White
                            )
                        }
                    }
                }

                if (bonus.canClaim) {
                    ArcadeButton(
                        text = "\uD83C\uDF81  CLAIM DAY ${bonus.activeDay} BONUS!",
                        onClick = onClaimDailyBonus,
                        style = ArcadeButtonStyle.GOLD,
                        pulse = true,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "claim_daily_bonus_button"
                    )
                } else {
                    ArcadeBadgePill(
                        text = "\u2713 CLAIMED TODAY (${bonus.todayDate})",
                        borderColor = NeonGreen
                    )
                }

                ArcadeButton(
                    text = if (bonus.canClaim) "LATER" else "CLOSE",
                    onClick = onCloseModal,
                    style = ArcadeButtonStyle.CYAN,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "daily_bonus_close_button"
                )
            }
        }

        ActiveModal.LEADERBOARD -> {
            val top5 = state.save.topScores
            val dateFmt = remember { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()) }
            ArcadeModal(
                title = "TOP 5 HIGH SCORES",
                titleColor = NeonGold,
                borderColor = NeonGold,
                onDismiss = onCloseModal
            ) {
                if (top5.isEmpty()) {
                    Text(
                        text = "\uD83C\uDFC6 No high scores recorded yet!\nComplete a level to claim #1 on the arcade board!",
                        fontFamily = FredokaFontFamily,
                        fontSize = 15.sp,
                        color = Color(0xFFD6C7FF),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        top5.forEachIndexed { idx, entry ->
                            val rank = idx + 1
                            val medal = when (rank) {
                                1 -> "\uD83E\uDD47"
                                2 -> "\uD83E\uDD48"
                                3 -> "\uD83E\uDD49"
                                else -> "#$rank"
                            }
                            val borderColor = when (rank) {
                                1 -> NeonGold
                                2 -> Color(0xFFE2E8F0)
                                3 -> Color(0xFFFF9F43)
                                else -> NeonCyan.copy(alpha = 0.45f)
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        if (rank == 1) NeonGold.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.07f),
                                        RoundedCornerShape(14.dp)
                                    )
                                    .border(1.8.dp, borderColor, RoundedCornerShape(14.dp))
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = medal,
                                        fontFamily = FredokaFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = if (rank <= 3) 22.sp else 16.sp,
                                        color = borderColor
                                    )
                                    Column {
                                        Text(
                                            text = "${"%,d".format(entry.score)} pts",
                                            fontFamily = FredokaFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 17.sp,
                                            color = Color.White
                                        )
                                        Text(
                                            text = "Level ${entry.levelId} \u2022 ${dateFmt.format(Date(entry.timestamp))}",
                                            fontFamily = FredokaFontFamily,
                                            fontSize = 12.sp,
                                            color = Color(0xFFB8EAFF)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                ArcadeButton(
                    text = "CLOSE",
                    onClick = onCloseModal,
                    style = ArcadeButtonStyle.CYAN,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "leaderboard_close_button"
                )
            }
        }
    }
}
