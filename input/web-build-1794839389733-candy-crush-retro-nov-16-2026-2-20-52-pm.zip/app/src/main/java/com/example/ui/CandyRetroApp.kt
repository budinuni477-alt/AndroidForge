package com.example.ui

import android.annotation.SuppressLint
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.game.GameViewModel
import com.example.model.ActiveModal
import com.example.model.ScreenMode
import com.example.ui.theme.FredokaFontFamily
import com.example.ui.theme.NeonCyan
import kotlin.math.abs
import kotlin.math.hypot

@SuppressLint("ClickableViewAccessibility")
@Composable
fun CandyRetroApp(
    vm: GameViewModel = viewModel()
) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    var glViewRef by remember { mutableStateOf<GLSurfaceView?>(null) }
    val lifecycleOwner = LocalLifecycleOwner.current

    BackHandler(enabled = state.screen != ScreenMode.MENU || state.activeModal != ActiveModal.NONE || state.selectedMapLevel != null) {
        vm.handleBackPress()
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    glViewRef?.onResume()
                    vm.onAppResume()
                }
                Lifecycle.Event.ON_PAUSE -> {
                    glViewRef?.onPause()
                    vm.onAppPause()
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Fullscreen Hardware-Accelerated 3D OpenGL ES Surface
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                GLSurfaceView(ctx).apply {
                    setEGLContextClientVersion(2)
                    setEGLConfigChooser(8, 8, 8, 8, 16, 0)
                    setRenderer(vm.renderer)
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

                    var downX = 0f
                    var downY = 0f
                    var lastY = 0f
                    var totalMove = 0f
                    var swipeHandled = false

                    setOnTouchListener { _, ev ->
                        when (ev.actionMasked) {
                            MotionEvent.ACTION_DOWN -> {
                                downX = ev.x
                                downY = ev.y
                                lastY = ev.y
                                totalMove = 0f
                                swipeHandled = false
                                true
                            }
                            MotionEvent.ACTION_MOVE -> {
                                val dx = ev.x - downX
                                val dy = ev.y - downY
                                val stepY = ev.y - lastY
                                lastY = ev.y
                                totalMove += abs(stepY)

                                when (vm.uiState.value.screen) {
                                    ScreenMode.MAP -> vm.scrollMapBy(stepY)
                                    ScreenMode.GAME -> {
                                        if (!swipeHandled && hypot(dx, dy) > 48f) {
                                            swipeHandled = true
                                            vm.onBoardSwipe(downX, downY, dx, dy)
                                        }
                                    }
                                    ScreenMode.MENU -> Unit
                                }
                                true
                            }
                            MotionEvent.ACTION_UP -> {
                                when (vm.uiState.value.screen) {
                                    ScreenMode.MAP -> {
                                        if (totalMove < 20f) {
                                            vm.onMapTapped(ev.x, ev.y)
                                        }
                                    }
                                    ScreenMode.GAME -> {
                                        if (!swipeHandled && hypot(ev.x - downX, ev.y - downY) < 40f) {
                                            vm.onBoardTap(ev.x, ev.y)
                                        }
                                    }
                                    ScreenMode.MENU -> Unit
                                }
                                true
                            }
                            else -> false
                        }
                    }
                    glViewRef = this
                }
            }
        )

        // Screen HUD Overlays
        when (state.screen) {
            ScreenMode.MENU -> MainMenuOverlay(
                state = state,
                onPlay = { vm.playNextUnlockedLevel() },
                onLevels = { vm.goToMap() },
                onSettings = { vm.openSettings(fromPause = false) },
                onTutorial = { vm.openTutorial() },
                onQuickMute = { vm.toggleQuickMute() },
                onDailyBonus = { vm.openDailyBonus() },
                onLeaderboard = { vm.openLeaderboard() }
            )

            ScreenMode.MAP -> LevelMapOverlay(
                state = state,
                onBackToMenu = { vm.goToMenu() },
                onSelectWorld = { vm.jumpToWorld(it) },
                onCloseCard = { vm.closeMapLevelCard() },
                onStartSelectedLevel = { vm.startLevel(it) }
            )

            ScreenMode.GAME -> GameplayHudOverlay(
                state = state,
                onPause = { vm.openPauseModal() },
                onSelectBooster = { vm.selectBooster(it) }
            )
        }

        // Animated Combo Multiplier Banner
        ComboBannerOverlay(banner = state.comboBanner)

        // Toast Notification
        AnimatedVisibility(
            visible = state.toastMessage != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 74.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = Color(0xEB0F0328),
                border = BorderStroke(2.dp, NeonCyan),
                shadowElevation = 10.dp
            ) {
                Text(
                    text = state.toastMessage.orEmpty(),
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 9.dp),
                    fontFamily = FredokaFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
            }
        }

        // Modals
        ModalRouter(
            state = state,
            onResume = { vm.resumeGame() },
            onRestartLevel = { vm.startLevel(it) },
            onOpenSettingsFromPause = { vm.openSettings(fromPause = true) },
            onCloseSettings = { vm.closeSettings() },
            onCloseModal = { vm.closeModal() },
            onGoToMap = { vm.goToMap() },
            onGoToMenu = { vm.goToMenu() },
            onNextLevel = { vm.startLevel(it) },
            onMusicVol = { vm.setMusicVolume(it) },
            onSfxVol = { vm.setSfxVolume(it) },
            onToggleMusicMute = { vm.toggleMusicMute() },
            onToggleSfxMute = { vm.toggleSfxMute() },
            onResetProgress = { vm.resetProgress() },
            onClaimDailyBonus = { vm.claimDailyBonus() }
        )
    }
}
