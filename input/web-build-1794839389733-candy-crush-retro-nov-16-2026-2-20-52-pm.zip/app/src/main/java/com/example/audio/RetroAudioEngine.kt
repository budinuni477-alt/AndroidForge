package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

class RetroAudioEngine {

    enum class MusicTrack { NONE, MENU, GAME }
    enum class Waveform { SINE, SQUARE, TRIANGLE, SAW, NOISE }

    private class Voice(
        val wave: Waveform,
        var freqStart: Float,
        val freqEnd: Float,
        val durSamples: Int,
        val vol: Float,
        val isMusic: Boolean,
        val delaySamples: Int = 0
    ) {
        var age = -delaySamples
        var phase = 0f
    }

    private val sampleRate = 22050
    private val voices = CopyOnWriteArrayList<Voice>()

    @Volatile var musicVol = 0.65f
    @Volatile var sfxVol = 0.85f
    @Volatile var musicMuted = false
    @Volatile var sfxMuted = false
    @Volatile var currentTrack = MusicTrack.NONE
        private set

    @Volatile private var paused = false
    @Volatile private var running = false
    private var audioThread: Thread? = null
    private var audioTrack: AudioTrack? = null

    private var stepCounter = 0
    private var samplesUntilNextStep = 0

    // Track 1: Cheerful Retro Arcade Menu / World Map Theme (118 BPM, C Major)
    private val menuLead = intArrayOf(
        72,0,76,79, 84,0,79,76, 77,0,81,84, 79,0,76,0,
        74,0,77,81, 79,0,74,71, 72,0,76,79, 84,0,0,0,
        84,0,83,81, 79,0,76,72, 77,0,79,81, 83,0,79,0,
        81,0,84,86, 88,0,84,79, 76,79,83,84, 84,0,0,0
    )
    private val menuBass = intArrayOf(
        48,0,60,0, 48,0,60,0, 53,0,65,0, 55,0,67,0,
        50,0,62,0, 55,0,67,0, 48,0,60,0, 48,55,60,55,
        45,0,57,0, 48,0,60,0, 53,0,65,0, 55,0,67,0,
        53,0,65,0, 55,0,67,0, 48,0,55,0, 48,0,0,0
    )
    private val menuArp = intArrayOf(64,67,72,67, 64,67,72,67, 65,69,72,69, 67,71,74,71)

    // Track 2: Energetic Fast Gameplay Retro Action Soundtrack (136 BPM, D Minor Synthwave)
    private val gameLead = intArrayOf(
        74,74,0,77, 81,0,79,77, 76,0,77,79, 81,0,74,0,
        70,70,0,74, 77,0,76,74, 72,0,74,76, 77,0,79,0,
        81,81,0,84, 86,0,84,81, 79,0,81,84, 86,0,88,0,
        89,0,86,84, 81,0,79,77, 76,79,81,84, 86,0,0,0
    )
    private val gameBass = intArrayOf(
        38,50,38,50, 38,50,38,50, 40,52,40,52, 41,53,43,55,
        46,58,46,58, 46,58,46,58, 48,60,48,60, 45,57,45,57,
        38,50,38,50, 41,53,41,53, 43,55,43,55, 45,57,48,60,
        46,58,46,58, 48,60,48,60, 45,57,43,55, 38,0,50,0
    )
    private val gameChords = intArrayOf(62,65,69, 60,64,67, 58,62,65, 60,64,67)

    fun start() {
        if (running) return
        running = true
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufSize = max(minBuf, 2048)

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.play()

        audioThread = Thread({
            val chunk = ShortArray(512)
            val twoPi = (2.0 * PI).toFloat()
            while (running) {
                if (paused) {
                    Thread.sleep(25)
                    continue
                }

                for (i in chunk.indices) {
                    if (currentTrack != MusicTrack.NONE) {
                        samplesUntilNextStep--
                        if (samplesUntilNextStep <= 0) {
                            triggerSequencerStep()
                            val stepMs = if (currentTrack == MusicTrack.MENU) 127 else 110
                            samplesUntilNextStep = (sampleRate * stepMs) / 1000
                        }
                    }

                    var mix = 0f
                    val it = voices.iterator()
                    while (it.hasNext()) {
                        val v = it.next()
                        if (v.age < 0) {
                            v.age++
                            continue
                        }
                        if (v.age >= v.durSamples) {
                            voices.remove(v)
                            continue
                        }
                        val progress = v.age.toFloat() / v.durSamples.toFloat()
                        val freq = if (v.freqStart == v.freqEnd) v.freqStart
                        else v.freqStart + (v.freqEnd - v.freqStart) * progress

                        v.phase += (freq / sampleRate)
                        if (v.phase >= 1f) v.phase -= 1f

                        val raw = when (v.wave) {
                            Waveform.SINE -> sin(v.phase * twoPi)
                            Waveform.SQUARE -> if (v.phase < 0.5f) 0.7f else -0.7f
                            Waveform.TRIANGLE -> 1f - 4f * kotlin.math.abs(v.phase - 0.5f)
                            Waveform.SAW -> 2f * v.phase - 1f
                            Waveform.NOISE -> Random.nextFloat() * 2f - 1f
                        }

                        val attack = min(1f, v.age / (sampleRate * 0.008f))
                        val decay = exp((-4.2f * progress).toDouble()).toFloat()
                        val gain = if (v.isMusic) {
                            if (musicMuted) 0f else musicVol * 0.34f
                        } else {
                            if (sfxMuted) 0f else sfxVol * 0.72f
                        }

                        mix += raw * v.vol * attack * decay * gain
                        v.age++
                    }

                    // Soft clip limiter
                    val clamped = (mix / (1f + kotlin.math.abs(mix) * 0.35f)).coerceIn(-0.98f, 0.98f)
                    chunk[i] = (clamped * 32767f).toInt().toShort()
                }
                audioTrack?.write(chunk, 0, chunk.size)
            }
        }, "RetroAudioThread").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun pause() {
        paused = true
        try { audioTrack?.pause() } catch (_: Exception) {}
    }

    fun resume() {
        paused = false
        try { audioTrack?.play() } catch (_: Exception) {}
    }

    fun release() {
        running = false
        try {
            audioThread?.join(300)
            audioTrack?.stop()
            audioTrack?.release()
        } catch (_: Exception) {}
        audioTrack = null
        voices.clear()
    }

    fun applySettings(musicVol: Float, sfxVol: Float, musicMuted: Boolean, sfxMuted: Boolean) {
        this.musicVol = musicVol
        this.sfxVol = sfxVol
        this.musicMuted = musicMuted
        this.sfxMuted = sfxMuted
    }

    fun playMusic(track: MusicTrack) {
        if (currentTrack == track) return
        voices.removeAll { it.isMusic }
        currentTrack = track
        stepCounter = 0
        samplesUntilNextStep = 0
    }

    private fun triggerSequencerStep() {
        val s = stepCounter % 64
        if (currentTrack == MusicTrack.MENU) {
            val l = menuLead[s]
            val b = menuBass[s]
            val a = menuArp[s % 16]
            if (l > 0) addVoice(Waveform.SQUARE, midi(l), midi(l), 0.16f, 0.14f, true)
            if (b > 0) addVoice(Waveform.TRIANGLE, midi(b), midi(b), 0.18f, 0.24f, true)
            if (s % 2 == 0) addVoice(Waveform.SINE, midi(a), midi(a), 0.09f, 0.10f, true)
            if (s % 4 == 0) addVoice(Waveform.SINE, 105f, 40f, 0.09f, 0.24f, true)
            if (s % 4 == 2) addVoice(Waveform.NOISE, 100f, 100f, 0.045f, 0.06f, true)
        } else if (currentTrack == MusicTrack.GAME) {
            val l = gameLead[s]
            val b = gameBass[s]
            if (l > 0) {
                addVoice(Waveform.SAW, midi(l), midi(l), 0.13f, 0.12f, true)
                addVoice(Waveform.SQUARE, midi(l + 12), midi(l + 12), 0.08f, 0.05f, true)
            }
            if (b > 0) addVoice(Waveform.TRIANGLE, midi(b), midi(b), 0.11f, 0.26f, true)
            if (s % 8 == 0) {
                val idx = ((s % 32) / 8) * 3
                for (k in 0..2) {
                    addVoice(Waveform.SQUARE, midi(gameChords[idx + k]), midi(gameChords[idx + k]), 0.18f, 0.045f, true)
                }
            }
            if (s % 4 == 0) addVoice(Waveform.SINE, 125f, 44f, 0.08f, 0.28f, true)
            if (s % 8 == 4) addVoice(Waveform.NOISE, 100f, 100f, 0.085f, 0.14f, true)
            if (s % 2 == 1) addVoice(Waveform.NOISE, 100f, 100f, 0.03f, 0.05f, true)
        }
        stepCounter++
    }

    private fun midi(note: Int): Float = 440f * 2.0.pow((note - 69) / 12.0).toFloat()

    private fun addVoice(
        wave: Waveform,
        fStart: Float,
        fEnd: Float,
        durSec: Float,
        vol: Float,
        isMusic: Boolean,
        delaySec: Float = 0f
    ) {
        if (voices.size > 48) return
        voices.add(
            Voice(
                wave = wave,
                freqStart = fStart,
                freqEnd = fEnd,
                durSamples = max(1, (durSec * sampleRate).toInt()),
                vol = vol,
                isMusic = isMusic,
                delaySamples = (delaySec * sampleRate).toInt()
            )
        )
    }

    // SFX Methods
    fun playClick() {
        addVoice(Waveform.SQUARE, 720f, 1020f, 0.055f, 0.18f, false)
    }

    fun playSwap() {
        addVoice(Waveform.SINE, 320f, 640f, 0.11f, 0.24f, false)
    }

    fun playInvalid() {
        addVoice(Waveform.SAW, 190f, 125f, 0.10f, 0.20f, false)
        addVoice(Waveform.SAW, 145f, 95f, 0.12f, 0.20f, false, 0.10f)
    }

    fun playMatch(combo: Int = 1) {
        val root = 58 + min(combo, 8) * 2
        addVoice(Waveform.TRIANGLE, midi(root), midi(root), 0.14f, 0.28f, false)
        addVoice(Waveform.SQUARE, midi(root + 4), midi(root + 4), 0.15f, 0.15f, false, 0.04f)
        addVoice(Waveform.SINE, midi(root + 7), midi(root + 7), 0.18f, 0.22f, false, 0.08f)
    }

    fun playExplode() {
        addVoice(Waveform.NOISE, 100f, 100f, 0.26f, 0.34f, false)
        addVoice(Waveform.SINE, 160f, 38f, 0.25f, 0.38f, false)
    }

    fun playLaser() {
        addVoice(Waveform.SAW, 1150f, 180f, 0.24f, 0.24f, false)
        addVoice(Waveform.SQUARE, 860f, 240f, 0.20f, 0.16f, false, 0.03f)
    }

    fun playColorBomb() {
        val notes = intArrayOf(60, 64, 67, 71, 72, 76, 79, 84)
        notes.forEachIndexed { idx, n ->
            addVoice(Waveform.TRIANGLE, midi(n), midi(n), 0.16f, 0.22f, false, idx * 0.035f)
        }
    }

    fun playComboBig() {
        intArrayOf(72, 76, 79, 84).forEachIndexed { idx, n ->
            addVoice(Waveform.SQUARE, midi(n), midi(n), 0.18f, 0.14f, false, idx * 0.05f)
        }
    }

    fun playLevelWin() {
        intArrayOf(60, 64, 67, 72, 67, 72, 76, 84).forEachIndexed { idx, n ->
            addVoice(Waveform.SQUARE, midi(n), midi(n), 0.18f, 0.16f, false, idx * 0.09f)
            addVoice(Waveform.TRIANGLE, midi(n - 12), midi(n - 12), 0.18f, 0.22f, false, idx * 0.09f)
        }
    }

    fun playLevelFail() {
        val notes = intArrayOf(60, 59, 58, 55)
        notes.forEachIndexed { idx, n ->
            addVoice(Waveform.SAW, midi(n), if (n == 55) 140f else midi(n), 0.26f, 0.18f, false, idx * 0.20f)
        }
    }

    fun playGrandVictory() {
        intArrayOf(60, 60, 60, 64, 67, 64, 67, 72, 76, 79, 84).forEachIndexed { idx, n ->
            addVoice(Waveform.SQUARE, midi(n), midi(n), 0.24f, 0.18f, false, idx * 0.11f)
            addVoice(Waveform.TRIANGLE, midi(n - 12), midi(n - 12), 0.24f, 0.25f, false, idx * 0.11f)
        }
    }
}
