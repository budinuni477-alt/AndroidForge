package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BoosterType
import com.example.model.GameUiState
import com.example.model.ObjectiveType
import com.example.ui.theme.ArcadeFontFamily
import com.example.ui.theme.ArcadePanelBg
import com.example.ui.theme.FredokaFontFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonRed

@Composable
fun MainMenuOverlay(
    state: GameUiState,
    onPlay: () -> Unit,
    onLevels: () -> Unit,
    onSettings: () -> Unit,
    onTutorial: () -> Unit,
    onQuickMute: () -> Unit,
    onDailyBonus: () -> Unit,
    onLeaderboard: () -> Unit
) {
    val allMuted = state.save.musicMuted && state.save.sfxMuted

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Progress Bar & Sound Toggle
        Row(
            modifier = Modifier
                .widthIn(max = 540.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ArcadeBadgePill(
                text = "\u2605 ${state.save.totalStars}/300  \u2022  LVL ${state.save.unlockedLevel}/100"
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ArcadeButton(
                    text = if (state.dailyBonus.canClaim) "\uD83C\uDF81 DAILY!" else "\uD83C\uDF81",
                    onClick = onDailyBonus,
                    style = if (state.dailyBonus.canClaim) ArcadeButtonStyle.GOLD else ArcadeButtonStyle.PURPLE,
                    minHeight = 48.dp,
                    fontSize = 14.sp,
                    pulse = state.dailyBonus.canClaim,
                    testTag = "daily_bonus_button"
                )
                ArcadeButton(
                    text = if (allMuted) "\uD83D\uDD07" else "\uD83D\uDD0A",
                    onClick = onQuickMute,
                    style = ArcadeButtonStyle.CYAN,
                    minHeight = 48.dp,
                    fontSize = 18.sp,
                    testTag = "quick_mute_button"
                )
            }
        }

        // Open viewport spacer so the live 3D rotating logo & orbiting fruits shine
        Spacer(modifier = Modifier.weight(1f))

        // Main Menu Arcade Buttons
        Column(
            modifier = Modifier
                .widthIn(max = 360.dp)
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ArcadeButton(
                text = "\u25B6  PLAY",
                onClick = onPlay,
                style = ArcadeButtonStyle.GOLD,
                minHeight = 64.dp,
                fontSize = 22.sp,
                pulse = true,
                modifier = Modifier.fillMaxWidth(),
                testTag = "play_button"
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ArcadeButton(
                    text = "\uD83D\uDDFA LEVELS",
                    onClick = onLevels,
                    style = ArcadeButtonStyle.CYAN,
                    modifier = Modifier.weight(1f),
                    testTag = "levels_button"
                )
                ArcadeButton(
                    text = "\u2699 SETTINGS",
                    onClick = onSettings,
                    style = ArcadeButtonStyle.PURPLE,
                    modifier = Modifier.weight(1f),
                    testTag = "settings_button"
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ArcadeButton(
                    text = "\uD83C\uDFC6 SCORES",
                    onClick = onLeaderboard,
                    style = ArcadeButtonStyle.GOLD,
                    modifier = Modifier.weight(1f),
                    testTag = "leaderboard_button"
                )
                ArcadeButton(
                    text = "\u2753 GUIDE",
                    onClick = onTutorial,
                    style = ArcadeButtonStyle.PINK,
                    modifier = Modifier.weight(1f),
                    testTag = "tutorial_button"
                )
            }
        }
    }
}

@Composable
fun LevelMapOverlay(
    state: GameUiState,
    onBackToMenu: () -> Unit,
    onSelectWorld: (Int) -> Unit,
    onCloseCard: () -> Unit,
    onStartSelectedLevel: (Int) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Map Header
            Surface(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = ArcadePanelBg,
                border = BorderStroke(2.dp, NeonCyan.copy(alpha = 0.55f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ArcadeButton(
                        text = "\u2B05 MENU",
                        onClick = onBackToMenu,
                        style = ArcadeButtonStyle.PINK,
                        minHeight = 48.dp,
                        fontSize = 14.sp,
                        testTag = "map_back_button"
                    )
                    Text(
                        text = "ARCADE MAP",
                        fontFamily = ArcadeFontFamily,
                        fontSize = 13.sp,
                        color = NeonCyan
                    )
                    ArcadeBadgePill(text = "\u2605 ${state.save.totalStars}")
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // World Selector Bar
            Column(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Swipe up/down to scroll 100 3D Levels \u2022 Tap a lit node",
                    fontFamily = FredokaFontFamily,
                    fontSize = 13.sp,
                    color = Color.White.copy(alpha = 0.88f),
                    textAlign = TextAlign.Center
                )
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = ArcadePanelBg,
                    border = BorderStroke(1.5.dp, NeonPink.copy(alpha = 0.55f))
                ) {
                    Row(
                        modifier = Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val labels = listOf("W1: 1-20", "W2: 21-40", "W3: 41-60", "W4: 61-80", "W5: 81-100")
                        labels.forEachIndexed { idx, label ->
                            val active = state.currentMapWorld == idx
                            Box(
                                modifier = Modifier
                                    .defaultMinSize(minHeight = 42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (active) Brush.verticalGradient(listOf(NeonPink, Color(0xFFA3004D)))
                                        else Brush.verticalGradient(listOf(Color(0x22FFFFFF), Color(0x11FFFFFF)))
                                    )
                                    .border(
                                        1.dp,
                                        if (active) Color.White else Color.White.copy(alpha = 0.22f),
                                        RoundedCornerShape(12.dp)
                                    )
                                    .clickable { onSelectWorld(idx) }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                                    .testTag("world_tab_$idx"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontFamily = FredokaFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        // Selected Level Bottom Card
        AnimatedVisibility(
            visible = state.selectedMapLevel != null,
            enter = fadeIn() + slideInVertically { it / 2 },
            exit = fadeOut() + slideOutVertically { it / 2 },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 78.dp)
        ) {
            val lvl = state.selectedMapLevel
            if (lvl != null) {
                val earned = state.save.stars[lvl.id] ?: 0
                Surface(
                    modifier = Modifier
                        .widthIn(max = 370.dp)
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = Color(0xF512052E),
                    border = BorderStroke(2.dp, NeonCyan),
                    shadowElevation = 14.dp
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "LEVEL ${lvl.id}${if (lvl.isBoss) " \u2022 BOSS" else ""}",
                                fontFamily = ArcadeFontFamily,
                                fontSize = 14.sp,
                                color = NeonGold
                            )
                            ArcadeButton(
                                text = "\u2715",
                                onClick = onCloseCard,
                                style = ArcadeButtonStyle.PINK,
                                minHeight = 48.dp,
                                fontSize = 14.sp,
                                testTag = "map_card_close"
                            )
                        }
                        Text(
                            text = "${lvl.worldName} \u2014 ${lvl.title}",
                            fontFamily = FredokaFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                        Text(
                            text = "${lvl.difficultyLabel}  \u2022  ${lvl.fruitCount} Fruit Types  \u2022  ${lvl.moves} Moves",
                            fontFamily = FredokaFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = NeonCyan
                        )
                        Text(
                            text = "Goal: ${lvl.describeObjective()}",
                            fontFamily = FredokaFontFamily,
                            fontSize = 14.sp,
                            color = Color(0xFFB8EAFF)
                        )
                        Text(
                            text = "\u2605".repeat(earned) + "\u2606".repeat(3 - earned),
                            fontSize = 22.sp,
                            color = NeonGold
                        )
                        ArcadeButton(
                            text = "\u25B6  START LEVEL",
                            onClick = { onStartSelectedLevel(lvl.id) },
                            style = ArcadeButtonStyle.GREEN,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "map_start_level_button"
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GameplayHudOverlay(
    state: GameUiState,
    onPause: () -> Unit,
    onSelectBooster: (BoosterType) -> Unit
) {
    val lvl = state.currentLevel ?: return
    val lowMoves = state.movesLeft <= 5
    val inf = rememberInfiniteTransition(label = "movesPulse")
    val lowScale by inf.animateFloat(
        initialValue = 1f,
        targetValue = if (lowMoves) 1.14f else 1f,
        animationSpec = infiniteRepeatable(tween(450), RepeatMode.Reverse),
        label = "lowScale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // TOP HUD
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Moves Box
                Surface(
                    modifier = Modifier.defaultMinSize(minWidth = 78.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = ArcadePanelBg,
                    border = BorderStroke(2.dp, if (lowMoves) NeonRed else NeonPink)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "MOVES",
                            fontFamily = FredokaFontFamily,
                            fontSize = 10.sp,
                            color = Color(0xFFFF9EC9)
                        )
                        Text(
                            text = state.movesLeft.toString(),
                            fontFamily = ArcadeFontFamily,
                            fontSize = 17.sp,
                            color = if (lowMoves) NeonRed else Color.White,
                            modifier = Modifier.scale(lowScale)
                        )
                    }
                }

                // Level & Score Bar
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    color = ArcadePanelBg,
                    border = BorderStroke(1.8.dp, NeonCyan.copy(alpha = 0.55f))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "LVL ${lvl.id} \u2022 ${lvl.difficultyLabel}${if (lvl.isBoss) " \uD83D\uDC51" else ""}",
                                fontFamily = FredokaFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = NeonGold
                            )
                            Text(
                                text = "${"%,d".format(state.score)} pts",
                                fontFamily = FredokaFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color.White
                            )
                        }
                        val progress = (state.score.toFloat() / lvl.starScores.third.toFloat()).coerceIn(0f, 1f)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(11.dp)
                                .clip(CircleShape)
                                .background(Color(0x88000000))
                                .border(1.dp, Color.White.copy(alpha = 0.22f), CircleShape)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(progress)
                                    .background(Brush.horizontalGradient(listOf(NeonCyan, NeonPink, NeonGold)))
                            )
                        }
                    }
                }

                ArcadeButton(
                    text = "\u23F8",
                    onClick = onPause,
                    style = ArcadeButtonStyle.PURPLE,
                    minHeight = 52.dp,
                    fontSize = 18.sp,
                    testTag = "pause_button"
                )
            }

            // Objectives & Multiplier Row
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (lvl.objType == ObjectiveType.SCORE) {
                    val done = state.score >= lvl.targetScore
                    ObjectiveChip(
                        text = "\uD83C\uDFAF ${"%,d".format(state.score)} / ${"%,d".format(lvl.targetScore)}",
                        done = done
                    )
                }
                if (lvl.objType == ObjectiveType.ICE || lvl.objType == ObjectiveType.MIXED) {
                    ObjectiveChip(
                        text = "\uD83E\uDDCA Ice Left: ${state.iceLeft}",
                        done = state.iceLeft == 0
                    )
                }
                if (lvl.objType == ObjectiveType.COLLECT || lvl.objType == ObjectiveType.MIXED) {
                    lvl.collectTargets.forEach { (fruit, target) ->
                        val cur = minOf(target, state.collected[fruit] ?: 0)
                        ObjectiveChip(
                            text = "${fruit.emoji} $cur/$target",
                            done = cur >= target
                        )
                    }
                }
                if (state.comboMultiplier >= 2) {
                    Surface(
                        shape = CircleShape,
                        color = NeonGold,
                        border = BorderStroke(2.dp, Color.White)
                    ) {
                        Text(
                            text = "x${state.comboMultiplier}",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            fontFamily = ArcadeFontFamily,
                            fontSize = 11.sp,
                            color = Color(0xFF240900)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // BOTTOM BOOSTER DOCK
        Column(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (state.activeBooster != null) {
                Surface(
                    shape = CircleShape,
                    color = NeonGold
                ) {
                    Text(
                        text = "Tap any tile on the board to trigger ${state.activeBooster.label}!",
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp),
                        fontFamily = FredokaFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF200800)
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = ArcadePanelBg,
                border = BorderStroke(1.8.dp, NeonCyan.copy(alpha = 0.55f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BoosterType.entries.forEach { b ->
                        val count = state.save.boosters[b] ?: 0
                        val active = state.activeBooster == b
                        val enabled = count > 0
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .defaultMinSize(minHeight = 56.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (active) NeonGold.copy(alpha = 0.25f)
                                    else Color.White.copy(alpha = if (enabled) 0.09f else 0.03f)
                                )
                                .border(
                                    1.8.dp,
                                    if (active) NeonGold else Color.White.copy(alpha = if (enabled) 0.28f else 0.10f),
                                    RoundedCornerShape(14.dp)
                                )
                                .clickable(enabled = enabled) { onSelectBooster(b) }
                                .padding(vertical = 6.dp, horizontal = 4.dp)
                                .testTag("booster_${b.name.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = b.icon, fontSize = 20.sp)
                                Text(
                                    text = "${b.label} ($count)",
                                    fontFamily = FredokaFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = if (enabled) Color.White else Color.White.copy(alpha = 0.4f),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ObjectiveChip(text: String, done: Boolean) {
    Surface(
        shape = CircleShape,
        color = Color(0xE00F052A),
        border = BorderStroke(1.5.dp, if (done) NeonGreen else Color.White.copy(alpha = 0.30f))
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            fontFamily = FredokaFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = if (done) NeonGreen else Color.White
        )
    }
}
