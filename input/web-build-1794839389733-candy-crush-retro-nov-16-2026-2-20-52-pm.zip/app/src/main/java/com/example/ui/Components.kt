package com.example.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.geometry.Offset
import com.example.model.ComboBannerState
import com.example.ui.theme.ArcadeFontFamily
import com.example.ui.theme.ArcadePanelBg
import com.example.ui.theme.FredokaFontFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanDark
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGoldDark
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenDark
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPinkDark
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleDark

enum class ArcadeButtonStyle(val top: Color, val bottom: Color, val textColor: Color = Color.White) {
    PINK(NeonPink, NeonPinkDark),
    CYAN(NeonCyan, NeonCyanDark, Color(0xFF031926)),
    GOLD(NeonGold, NeonGoldDark, Color(0xFF2B0F00)),
    PURPLE(NeonPurple, NeonPurpleDark),
    GREEN(NeonGreen, NeonGreenDark, Color(0xFF002412)),
    DANGER(Color(0xFFFF4D4D), Color(0xFF990000))
}

@Composable
fun ArcadeButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: ArcadeButtonStyle = ArcadeButtonStyle.PINK,
    minHeight: Dp = 52.dp,
    fontSize: TextUnit = 17.sp,
    pulse: Boolean = false,
    testTag: String = ""
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()

    val pulseScale = if (pulse) {
        val inf = rememberInfiniteTransition(label = "btnPulse")
        val s by inf.animateFloat(
            initialValue = 1.0f,
            targetValue = 1.035f,
            animationSpec = infiniteRepeatable(tween(950, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "pulseVal"
        )
        s
    } else 1f

    val scale = (if (pressed) 0.95f else 1f) * pulseScale
    val shape = RoundedCornerShape(18.dp)

    Box(
        modifier = modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = minHeight)
            .scale(scale)
            .shadow(elevation = if (pressed) 2.dp else 8.dp, shape = shape, ambientColor = style.top, spotColor = style.top)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(style.top, style.bottom)))
            .border(2.dp, Color.White.copy(alpha = 0.5f), shape)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = Color.White),
                onClick = onClick
            )
            .padding(horizontal = 18.dp, vertical = 10.dp)
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            fontFamily = FredokaFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = fontSize,
            color = style.textColor,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

@Composable
fun ArcadeBadgePill(
    text: String,
    modifier: Modifier = Modifier,
    borderColor: Color = NeonCyan.copy(alpha = 0.55f)
) {
    Surface(
        modifier = modifier,
        shape = CircleShape,
        color = ArcadePanelBg,
        border = BorderStroke(1.5.dp, borderColor)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            fontFamily = FredokaFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp,
            color = Color.White
        )
    }
}

@Composable
fun ArcadeModal(
    title: String,
    titleColor: Color = NeonGold,
    borderColor: Color = NeonCyan,
    onDismiss: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xC8060112))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onDismiss?.invoke() },
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .padding(16.dp)
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {}, // Consume inner clicks
            shape = RoundedCornerShape(26.dp),
            color = Color(0xF21A0742),
            border = BorderStroke(2.5.dp, borderColor),
            shadowElevation = 18.dp
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = title,
                    fontFamily = ArcadeFontFamily,
                    fontSize = 17.sp,
                    color = titleColor,
                    textAlign = TextAlign.Center,
                    lineHeight = 24.sp
                )
                content()
            }
        }
    }
}

@Composable
fun ComboBannerOverlay(banner: ComboBannerState?) {
    if (banner == null) return

    val scale = remember(banner.id) { Animatable(0.45f) }
    val alpha = remember(banner.id) { Animatable(0f) }

    LaunchedEffect(banner.id) {
        alpha.snapTo(1f)
        scale.animateTo(1.18f, tween(220, easing = FastOutSlowInEasing))
        scale.animateTo(1.0f, tween(200))
        alpha.animateTo(0f, tween(520))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 80.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .scale(scale.value)
                .alpha(alpha.value),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = banner.title,
                fontFamily = ArcadeFontFamily,
                fontSize = 24.sp,
                color = NeonGold,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.displayLarge.copy(
                    shadow = Shadow(
                        color = NeonPink,
                        offset = Offset(0f, 6f),
                        blurRadius = 18f
                    )
                )
            )
            Text(
                text = banner.subtitle,
                fontFamily = FredokaFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = NeonCyan,
                textAlign = TextAlign.Center
            )
        }
    }
}
