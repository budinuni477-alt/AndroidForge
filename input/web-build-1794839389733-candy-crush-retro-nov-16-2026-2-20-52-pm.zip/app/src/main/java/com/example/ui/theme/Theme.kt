package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RetroDarkColorScheme = darkColorScheme(
    primary = NeonPink,
    onPrimary = Color.White,
    secondary = NeonCyan,
    onSecondary = CosmicBgDark,
    tertiary = NeonGold,
    onTertiary = Color(0xFF2B0F00),
    background = CosmicBgDark,
    onBackground = Color.White,
    surface = ArcadePanelBg,
    onSurface = Color.White,
    surfaceVariant = ArcadeCardBg,
    onSurfaceVariant = Color(0xFFD6C7FF),
    error = NeonRed,
    onError = Color.White
)

@Composable
fun CandyCrushRetroTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RetroDarkColorScheme,
        typography = Typography,
        content = content
    )
}
