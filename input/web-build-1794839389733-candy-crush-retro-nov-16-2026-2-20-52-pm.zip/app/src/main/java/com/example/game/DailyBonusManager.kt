package com.example.game

import com.example.model.BoosterType
import com.example.model.DailyBonusInfo
import com.example.model.SaveState
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.floor
import kotlin.random.Random

object DailyBonusManager {

    data class DayReward(
        val day: Int,
        val title: String,
        val boosters: Map<BoosterType, Int>
    )

    val REWARD_SCHEDULE: List<DayReward> = listOf(
        DayReward(1, "Day 1", mapOf(BoosterType.HAMMER to 1)),
        DayReward(2, "Day 2", mapOf(BoosterType.BOMB to 1)),
        DayReward(3, "Day 3", mapOf(BoosterType.LASER to 1)),
        DayReward(4, "Day 4", mapOf(BoosterType.PAINT to 1)),
        DayReward(5, "Day 5", mapOf(BoosterType.HAMMER to 1, BoosterType.BOMB to 1)),
        DayReward(6, "Day 6", mapOf(BoosterType.LASER to 1, BoosterType.PAINT to 1)),
        DayReward(
            7,
            "Day 7 Mega",
            mapOf(
                BoosterType.HAMMER to 2,
                BoosterType.BOMB to 2,
                BoosterType.LASER to 2,
                BoosterType.PAINT to 2
            )
        )
    )

    fun isSameCalendarDay(
        ts1Millis: Long,
        ts2Millis: Long,
        timeZone: TimeZone = TimeZone.getDefault()
    ): Boolean {
        if (ts1Millis <= 0L || ts2Millis <= 0L) return false
        val c1 = Calendar.getInstance(timeZone).apply { timeInMillis = ts1Millis }
        val c2 = Calendar.getInstance(timeZone).apply { timeInMillis = ts2Millis }
        return c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR) &&
            c1.get(Calendar.DAY_OF_YEAR) == c2.get(Calendar.DAY_OF_YEAR)
    }

    fun dayInfoForMillis(
        millis: Long,
        timeZone: TimeZone = TimeZone.getDefault()
    ): Pair<Long, String> {
        val cal = Calendar.getInstance(timeZone).apply {
            timeInMillis = millis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val localMillis = cal.timeInMillis + cal.timeZone.getOffset(cal.timeInMillis)
        val dayIndex = floor(localMillis.toDouble() / 86_400_000.0).toLong()
        val dateStr = String.format(
            Locale.US,
            "%04d-%02d-%02d",
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
        return dayIndex to dateStr
    }

    fun generateRandomBoosters(
        streakDay: Int,
        random: Random = Random.Default
    ): Map<BoosterType, Int> {
        val pool = BoosterType.entries.toMutableList().apply { shuffle(random) }
        val result = LinkedHashMap<BoosterType, Int>()
        val picks = when {
            streakDay >= 7 -> 3
            streakDay >= 4 -> 2
            else -> 2
        }
        for (i in 0 until picks) {
            val qty = if (streakDay >= 7 || (streakDay >= 5 && i == 0)) 2 else 1
            result[pool[i]] = qty
        }
        return result
    }

    fun checkDailyBonus(
        save: SaveState,
        nowMillis: Long = System.currentTimeMillis(),
        timeZone: TimeZone = TimeZone.getDefault(),
        random: Random = Random.Default
    ): DailyBonusInfo {
        val (todayIdx, todayStr) = dayInfoForMillis(nowMillis, timeZone)
        val sameLoginDay = isSameCalendarDay(save.lastLogin, nowMillis, timeZone)
        val alreadyClaimedToday = sameLoginDay ||
            save.lastDailyBonusDayIdx == todayIdx ||
            (save.lastDailyBonusDate.isNotEmpty() && save.lastDailyBonusDate == todayStr)

        val wasYesterday = if (save.lastLogin > 0L) {
            val (lastLoginDayIdx, _) = dayInfoForMillis(save.lastLogin, timeZone)
            lastLoginDayIdx == todayIdx - 1L
        } else {
            save.lastDailyBonusDayIdx == todayIdx - 1L
        }

        val nextDay = when {
            alreadyClaimedToday -> save.dailyLoginStreak.coerceIn(1, 7)
            wasYesterday -> (save.dailyLoginStreak % 7) + 1
            else -> 1
        }

        val rewards = generateRandomBoosters(nextDay, random)
        return DailyBonusInfo(
            canClaim = !alreadyClaimedToday,
            activeDay = nextDay,
            todayRewards = rewards,
            lastClaimedDate = save.lastDailyBonusDate,
            todayDate = todayStr,
            todayDayIdx = todayIdx
        )
    }

    fun applyClaim(
        save: SaveState,
        precomputedRewards: Map<BoosterType, Int>? = null,
        nowMillis: Long = System.currentTimeMillis(),
        timeZone: TimeZone = TimeZone.getDefault(),
        random: Random = Random.Default
    ): Pair<SaveState, DailyBonusInfo> {
        val info = checkDailyBonus(save, nowMillis, timeZone, random)
        if (!info.canClaim) return save to info

        val rewardsToGrant = if (!precomputedRewards.isNullOrEmpty()) precomputedRewards else info.todayRewards
        val updatedBoosters = save.boosters.toMutableMap()
        rewardsToGrant.forEach { (type, qty) ->
            updatedBoosters[type] = (updatedBoosters[type] ?: 0) + qty
        }

        val updatedSave = save.copy(
            boosters = updatedBoosters,
            lastLogin = nowMillis,
            lastDailyBonusDate = info.todayDate,
            lastDailyBonusDayIdx = info.todayDayIdx,
            dailyLoginStreak = info.activeDay
        )
        return updatedSave to info.copy(
            canClaim = false,
            todayRewards = rewardsToGrant,
            lastClaimedDate = info.todayDate
        )
    }
}
