package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.BoosterType
import com.example.model.LeaderboardEntry
import com.example.model.SaveState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.saveDataStore: DataStore<Preferences> by preferencesDataStore(name = "candy_crush_retro_save")

class SaveRepository(private val context: Context) {

    private object Keys {
        val UNLOCKED_LEVEL = intPreferencesKey("unlocked_level")
        val STARS_MAP = stringPreferencesKey("stars_map")
        val HIGH_SCORES_MAP = stringPreferencesKey("high_scores_map")
        val BOOSTER_HAMMER = intPreferencesKey("booster_hammer")
        val BOOSTER_BOMB = intPreferencesKey("booster_bomb")
        val BOOSTER_LASER = intPreferencesKey("booster_laser")
        val BOOSTER_PAINT = intPreferencesKey("booster_paint")
        val MUSIC_VOL = floatPreferencesKey("music_vol")
        val SFX_VOL = floatPreferencesKey("sfx_vol")
        val MUSIC_MUTED = booleanPreferencesKey("music_muted")
        val SFX_MUTED = booleanPreferencesKey("sfx_muted")
        val LAST_LOGIN = longPreferencesKey("lastLogin")
        val LAST_DAILY_BONUS_DATE = stringPreferencesKey("last_daily_bonus_date")
        val LAST_DAILY_BONUS_DAY_IDX = longPreferencesKey("last_daily_bonus_day_idx")
        val DAILY_LOGIN_STREAK = intPreferencesKey("daily_login_streak")
        val TOP_SCORES = stringPreferencesKey("top_scores")
    }

    val saveFlow: Flow<SaveState> = context.saveDataStore.data.map { prefs ->
        SaveState(
            unlockedLevel = prefs[Keys.UNLOCKED_LEVEL] ?: 1,
            stars = decodeIntMap(prefs[Keys.STARS_MAP]),
            highScores = decodeIntMap(prefs[Keys.HIGH_SCORES_MAP]),
            boosters = mapOf(
                BoosterType.HAMMER to (prefs[Keys.BOOSTER_HAMMER] ?: 4),
                BoosterType.BOMB to (prefs[Keys.BOOSTER_BOMB] ?: 3),
                BoosterType.LASER to (prefs[Keys.BOOSTER_LASER] ?: 3),
                BoosterType.PAINT to (prefs[Keys.BOOSTER_PAINT] ?: 3)
            ),
            musicVol = prefs[Keys.MUSIC_VOL] ?: 0.65f,
            sfxVol = prefs[Keys.SFX_VOL] ?: 0.85f,
            musicMuted = prefs[Keys.MUSIC_MUTED] ?: false,
            sfxMuted = prefs[Keys.SFX_MUTED] ?: false,
            lastLogin = prefs[Keys.LAST_LOGIN] ?: 0L,
            lastDailyBonusDate = prefs[Keys.LAST_DAILY_BONUS_DATE] ?: "",
            lastDailyBonusDayIdx = prefs[Keys.LAST_DAILY_BONUS_DAY_IDX] ?: -1L,
            dailyLoginStreak = prefs[Keys.DAILY_LOGIN_STREAK] ?: 0,
            topScores = decodeLeaderboard(prefs[Keys.TOP_SCORES])
        )
    }

    suspend fun save(state: SaveState) {
        context.saveDataStore.edit { prefs ->
            prefs[Keys.UNLOCKED_LEVEL] = state.unlockedLevel
            prefs[Keys.STARS_MAP] = encodeIntMap(state.stars)
            prefs[Keys.HIGH_SCORES_MAP] = encodeIntMap(state.highScores)
            prefs[Keys.BOOSTER_HAMMER] = state.boosters[BoosterType.HAMMER] ?: 0
            prefs[Keys.BOOSTER_BOMB] = state.boosters[BoosterType.BOMB] ?: 0
            prefs[Keys.BOOSTER_LASER] = state.boosters[BoosterType.LASER] ?: 0
            prefs[Keys.BOOSTER_PAINT] = state.boosters[BoosterType.PAINT] ?: 0
            prefs[Keys.MUSIC_VOL] = state.musicVol
            prefs[Keys.SFX_VOL] = state.sfxVol
            prefs[Keys.MUSIC_MUTED] = state.musicMuted
            prefs[Keys.SFX_MUTED] = state.sfxMuted
            prefs[Keys.LAST_LOGIN] = state.lastLogin
            prefs[Keys.LAST_DAILY_BONUS_DATE] = state.lastDailyBonusDate
            prefs[Keys.LAST_DAILY_BONUS_DAY_IDX] = state.lastDailyBonusDayIdx
            prefs[Keys.DAILY_LOGIN_STREAK] = state.dailyLoginStreak
            prefs[Keys.TOP_SCORES] = encodeLeaderboard(state.topScores)
        }
    }

    suspend fun resetAllKeepingSettings(current: SaveState): SaveState {
        val fresh = SaveState(
            musicVol = current.musicVol,
            sfxVol = current.sfxVol,
            musicMuted = current.musicMuted,
            sfxMuted = current.sfxMuted,
            lastLogin = current.lastLogin,
            lastDailyBonusDate = current.lastDailyBonusDate,
            lastDailyBonusDayIdx = current.lastDailyBonusDayIdx,
            dailyLoginStreak = current.dailyLoginStreak
        )
        save(fresh)
        return fresh
    }

    private fun encodeIntMap(map: Map<Int, Int>): String =
        map.entries.joinToString(",") { "${it.key}:${it.value}" }

    private fun decodeIntMap(raw: String?): Map<Int, Int> {
        if (raw.isNullOrBlank()) return emptyMap()
        val result = HashMap<Int, Int>()
        raw.split(",").forEach { token ->
            val parts = token.split(":")
            if (parts.size == 2) {
                val k = parts[0].toIntOrNull()
                val v = parts[1].toIntOrNull()
                if (k != null && v != null) result[k] = v
            }
        }
        return result
    }

    fun encodeLeaderboard(entries: List<LeaderboardEntry>): String =
        entries.take(5).joinToString("|") { "${it.score}:${it.levelId}:${it.timestamp}" }

    fun decodeLeaderboard(raw: String?): List<LeaderboardEntry> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split("|").mapNotNull { token ->
            val parts = token.split(":")
            if (parts.size == 3) {
                val score = parts[0].toIntOrNull()
                val lvl = parts[1].toIntOrNull()
                val ts = parts[2].toLongOrNull()
                if (score != null && lvl != null && ts != null) {
                    LeaderboardEntry(score = score, levelId = lvl, timestamp = ts)
                } else null
            } else null
        }.sortedWith(compareByDescending<LeaderboardEntry> { it.score }.thenByDescending { it.timestamp })
            .take(5)
    }
}
