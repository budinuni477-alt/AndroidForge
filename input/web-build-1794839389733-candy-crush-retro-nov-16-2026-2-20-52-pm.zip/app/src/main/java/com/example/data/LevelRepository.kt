package com.example.data

import com.example.model.FruitType
import com.example.model.LevelDef
import com.example.model.LevelLayout
import com.example.model.ObjectiveType
import kotlin.math.max
import kotlin.math.min

object LevelRepository {

    val WORLD_NAMES = listOf(
        "Neon Arcade",
        "Pixel Palms",
        "Cyber Citrus",
        "Starlight Synth",
        "Retro Championship"
    )

    private val ADJECTIVES = listOf(
        "1UP", "Turbo", "Neon", "Pixel", "Hyper", "Retro", "Laser", "Cosmic", "Synth", "Super",
        "Mega", "Ultra", "Arcade", "Electric", "Flash", "Crystal", "Star", "Prism", "Chrome", "Boss"
    )

    private val NOUNS = listOf(
        "Warmup", "Cascade", "Rush", "Juice", "Blaster", "Matrix", "Orbit", "Freeze", "Spark", "Challenge",
        "Grid", "Burst", "Frenzy", "Wave", "Tower", "Vault", "Pulse", "Storm", "Gauntlet", "Showdown"
    )

    private fun buildPattern(patternId: Int, levelNum: Int): LevelLayout {
        val ice = Array(8) { IntArray(8) }
        val cage = Array(8) { IntArray(8) }
        val stone = Array(8) { IntArray(8) }

        val iceLvl = if (levelNum > 45) 2 else 1

        when (patternId % 12) {
            0 -> Unit // Clean classic 8x8 board
            1 -> {
                for (r in 3..4) for (c in 3..4) ice[r][c] = iceLvl
            }
            2 -> {
                listOf(1 to 1, 1 to 6, 6 to 1, 6 to 6, 2 to 2, 2 to 5, 5 to 2, 5 to 5)
                    .forEach { (r, c) -> ice[r][c] = 1 }
            }
            3 -> {
                for (r in 2..5) {
                    ice[r][2] = iceLvl
                    ice[r][5] = iceLvl
                }
            }
            4 -> {
                listOf(2 to 3, 2 to 4, 3 to 2, 3 to 5, 4 to 2, 4 to 5, 5 to 3, 5 to 4)
                    .forEach { (r, c) -> cage[r][c] = 1 }
            }
            5 -> {
                stone[3][2] = 1; stone[4][2] = 1; stone[3][5] = 1; stone[4][5] = 1
                ice[3][3] = iceLvl; ice[3][4] = iceLvl; ice[4][3] = iceLvl; ice[4][4] = iceLvl
            }
            6 -> {
                for (r in 2..5) for (c in 2..5) {
                    if ((r + c) % 2 == 0) ice[r][c] = iceLvl
                }
            }
            7 -> {
                for (c in 1..6) ice[6][c] = iceLvl
                stone[5][2] = 1; stone[5][5] = 1
                cage[4][3] = 1; cage[4][4] = 1
            }
            8 -> {
                for (i in 1..6) {
                    ice[i][3] = 1
                    ice[3][i] = 1
                }
                stone[3][3] = 2
            }
            9 -> {
                stone[2][2] = 1; stone[2][5] = 1; stone[5][2] = 1; stone[5][5] = 1
                cage[2][3] = 1; cage[2][4] = 1; cage[5][3] = 1; cage[5][4] = 1
            }
            10 -> {
                for (r in 3..4) for (c in 1..6) {
                    ice[r][c] = if (c == 3 || c == 4) 2 else 1
                }
            }
            11 -> {
                stone[2][1] = 2; stone[2][6] = 2; stone[4][3] = 2; stone[4][4] = 2
                for (c in 1..6) ice[6][c] = 2
                cage[3][2] = 1; cage[3][5] = 1; cage[5][2] = 1; cage[5][5] = 1
            }
        }

        var iceCount = 0
        for (r in 0..7) for (c in 0..7) if (ice[r][c] > 0) iceCount++
        return LevelLayout(ice = ice, cage = cage, stone = stone, iceCount = iceCount)
    }

    val LEVELS: List<LevelDef> = (1..100).map { id ->
        val idx = id - 1
        val world = idx / 20
        val isBoss = id % 10 == 0

        // Progressive fruit complexity: starts at 4 fruits and scales up to 8 distinct 3D fruits
        val fruitCount = when {
            id <= 10 -> 4
            id <= 25 -> 5
            id <= 50 -> 6
            id <= 75 -> 7
            else -> 8
        }

        // Progressive move limit reduction: starts generous at 28 and tightens down to 12-13 by Level 100
        val baseMoves = 28 - ((id - 1) * 16) / 99
        val bossBonus = if (isBoss && id >= 20) 1 else 0
        val moves = max(12, baseMoves + bossBonus)

        val difficultyLabel = when {
            id <= 15 -> "Easy"
            id <= 35 -> "Medium"
            id <= 60 -> "Hard"
            id <= 85 -> "Expert"
            else -> "Master"
        }

        val patternId = when {
            isBoss -> 11
            id == 1 || id == 2 -> 0
            id == 3 -> 1
            id == 4 -> 4
            else -> ((id * 7 + world * 3) % 10) + 1
        }
        val layout = buildPattern(patternId, id)

        val objType = when {
            id == 1 -> ObjectiveType.SCORE
            id == 2 -> ObjectiveType.COLLECT
            layout.iceCount > 0 && id % 3 == 0 -> ObjectiveType.ICE
            layout.iceCount > 0 && isBoss -> ObjectiveType.MIXED
            id % 2 == 0 -> ObjectiveType.COLLECT
            layout.iceCount > 0 -> ObjectiveType.ICE
            else -> ObjectiveType.SCORE
        }

        val targetScore = 1000 + id * 120 + if (isBoss) 900 else 0
        val starScores = Triple(
            targetScore,
            (targetScore * 1.40f).toInt(),
            (targetScore * 1.85f).toInt()
        )

        val collectTargets = LinkedHashMap<FruitType, Int>()
        if (objType == ObjectiveType.COLLECT || objType == ObjectiveType.MIXED) {
            // Prioritize newly unlocked, complex fruits as targets in higher levels
            val primaryIdx = max(0, fruitCount - 1 - (id % 3))
            val secondaryIdx = (primaryIdx + 2) % fruitCount
            val tertiaryIdx = (primaryIdx + 4) % fruitCount

            val qtyBase = when {
                id <= 15 -> 10 + (id / 3)
                id <= 50 -> 11 + ((id - 15) / 6)
                else -> 10 + ((id - 50) / 10)
            }
            collectTargets[FruitType.fromId(primaryIdx)] = min(20, qtyBase)
            if (id >= 11 && secondaryIdx != primaryIdx) {
                collectTargets[FruitType.fromId(secondaryIdx)] = min(18, max(8, qtyBase - 2))
            }
            if (id >= 51 && tertiaryIdx != primaryIdx && tertiaryIdx != secondaryIdx) {
                collectTargets[FruitType.fromId(tertiaryIdx)] = min(15, max(7, qtyBase - 4))
            }
        }

        val adj = if (isBoss) "BOSS" else ADJECTIVES[(id * 3 + world) % ADJECTIVES.size]
        val noun = if (isBoss) "SHOWDOWN" else NOUNS[(id * 5 + world * 2) % NOUNS.size]

        LevelDef(
            id = id,
            world = world,
            worldName = WORLD_NAMES[world],
            isBoss = isBoss,
            title = "$adj $noun",
            fruitCount = fruitCount,
            moves = moves,
            objType = objType,
            targetScore = targetScore,
            starScores = starScores,
            collectTargets = collectTargets,
            layout = layout,
            difficultyLabel = difficultyLabel
        )
    }

    fun getLevel(id: Int): LevelDef = LEVELS[(id - 1).coerceIn(0, LEVELS.lastIndex)]
}
