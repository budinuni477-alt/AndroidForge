package com.example

import com.example.data.LevelRepository
import com.example.game.DailyBonusManager
import com.example.game.GameViewModel
import com.example.model.LeaderboardEntry
import com.example.model.SaveState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone
import kotlin.random.Random

class ExampleUnitTest {
    @Test
    fun all100Levels_areValidAndSequential() {
        assertEquals(100, LevelRepository.LEVELS.size)
        LevelRepository.LEVELS.forEachIndexed { index, level ->
            assertEquals(index + 1, level.id)
            assertTrue(level.fruitCount in 4..8)
            assertTrue(level.moves >= 12)
            assertTrue(level.starScores.first <= level.starScores.second)
            assertTrue(level.starScores.second <= level.starScores.third)
        }
        assertTrue(LevelRepository.getLevel(10).isBoss)
        assertTrue(LevelRepository.getLevel(100).isBoss)
    }

    @Test
    fun levelProgression_reducesMovesAndIncreasesFruitComplexity() {
        val worldAvgMoves = (0..4).map { worldIdx ->
            LevelRepository.LEVELS
                .filter { it.world == worldIdx }
                .map { it.moves }
                .average()
        }
        for (w in 1 until worldAvgMoves.size) {
            assertTrue(
                "Expected world ${w + 1} avg moves (${worldAvgMoves[w]}) < world $w avg moves (${worldAvgMoves[w - 1]})",
                worldAvgMoves[w] < worldAvgMoves[w - 1]
            )
        }

        val lvl1 = LevelRepository.getLevel(1)
        val lvl50 = LevelRepository.getLevel(50)
        val lvl100 = LevelRepository.getLevel(100)

        assertTrue(lvl100.moves < lvl50.moves)
        assertTrue(lvl50.moves < lvl1.moves)

        assertEquals(4, lvl1.fruitCount)
        assertEquals(6, lvl50.fruitCount)
        assertEquals(8, lvl100.fruitCount)
        assertEquals("Easy", lvl1.difficultyLabel)
        assertEquals("Hard", lvl50.difficultyLabel)
        assertEquals("Master", lvl100.difficultyLabel)

        val collectLevels = LevelRepository.LEVELS.filter { it.collectTargets.isNotEmpty() }
        assertTrue(collectLevels.first().collectTargets.size == 1)
        assertTrue(collectLevels.last().collectTargets.size == 3)
    }

    @Test
    fun checkDailyBonus_comparesLastLoginTimestamp_andGrantsRandomBoostersOncePerDay() {
        val tz = TimeZone.getTimeZone("UTC")
        val day1Morning = Calendar.getInstance(tz).apply { set(2026, Calendar.NOVEMBER, 16, 10, 0, 0) }.timeInMillis
        val day1Night = Calendar.getInstance(tz).apply { set(2026, Calendar.NOVEMBER, 16, 23, 30, 0) }.timeInMillis
        val day2Morning = Calendar.getInstance(tz).apply { set(2026, Calendar.NOVEMBER, 17, 8, 15, 0) }.timeInMillis
        val day4Morning = Calendar.getInstance(tz).apply { set(2026, Calendar.NOVEMBER, 19, 9, 0, 0) }.timeInMillis

        val initial = SaveState()
        assertEquals(0L, initial.lastLogin)

        // First login -> new day, generates random boosters
        val check1 = DailyBonusManager.checkDailyBonus(initial, day1Morning, tz, Random(42))
        assertTrue(check1.canClaim)
        assertEquals(1, check1.activeDay)
        assertTrue(check1.todayRewards.isNotEmpty())

        // Claim Day 1 -> updates lastLogin timestamp and credits random boosters
        val (afterDay1, claimedInfo1) = DailyBonusManager.applyClaim(
            save = initial,
            precomputedRewards = check1.todayRewards,
            nowMillis = day1Morning,
            timeZone = tz,
            random = Random(42)
        )
        assertFalse(claimedInfo1.canClaim)
        assertEquals(day1Morning, afterDay1.lastLogin)
        assertEquals(1, afterDay1.dailyLoginStreak)
        val initialTotalBoosters = initial.boosters.values.sum()
        val gainedDay1 = check1.todayRewards.values.sum()
        assertEquals(initialTotalBoosters + gainedDay1, afterDay1.boosters.values.sum())

        // Same day later -> lastLogin matches current date -> blocked
        val checkSameDay = DailyBonusManager.checkDailyBonus(afterDay1, day1Night, tz, Random(99))
        assertFalse(checkSameDay.canClaim)
        val (sameDayAttempt, _) = DailyBonusManager.applyClaim(afterDay1, nowMillis = day1Night, timeZone = tz)
        assertEquals(afterDay1, sameDayAttempt)

        // Next consecutive day -> new day compared to lastLogin -> Day 2 random boosters
        val check2 = DailyBonusManager.checkDailyBonus(afterDay1, day2Morning, tz, Random(7))
        assertTrue(check2.canClaim)
        assertEquals(2, check2.activeDay)
        assertTrue(check2.todayRewards.isNotEmpty())
        val (afterDay2, _) = DailyBonusManager.applyClaim(
            save = afterDay1,
            precomputedRewards = check2.todayRewards,
            nowMillis = day2Morning,
            timeZone = tz
        )
        assertEquals(day2Morning, afterDay2.lastLogin)
        assertEquals(afterDay1.boosters.values.sum() + check2.todayRewards.values.sum(), afterDay2.boosters.values.sum())

        // Skip a day -> streak resets to Day 1
        val check4 = DailyBonusManager.checkDailyBonus(afterDay2, day4Morning, tz, Random(11))
        assertTrue(check4.canClaim)
        assertEquals(1, check4.activeDay)
    }

    @Test
    fun updateLeaderboard_keepsTop5SortedDescending() {
        var board = emptyList<LeaderboardEntry>()
        board = GameViewModel.updateLeaderboard(board, 1200, 1, 100L)
        board = GameViewModel.updateLeaderboard(board, 3500, 3, 200L)
        board = GameViewModel.updateLeaderboard(board, 900, 2, 300L)
        board = GameViewModel.updateLeaderboard(board, 5200, 5, 400L)
        board = GameViewModel.updateLeaderboard(board, 2800, 4, 500L)
        board = GameViewModel.updateLeaderboard(board, 4100, 6, 600L)
        board = GameViewModel.updateLeaderboard(board, 0, 1, 700L)

        assertEquals(5, board.size)
        assertEquals(listOf(5200, 4100, 3500, 2800, 1200), board.map { it.score })
    }
}
